<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmsalidas

Inherits LibreriaModeloMantenimiento.ModeloMantenimiento

'Form reemplaza a Dispose para limpiar la lista de componentes.
<System.Diagnostics.DebuggerNonUserCode()> _
Protected Overrides Sub Dispose(ByVal disposing As Boolean)
Try
If disposing AndAlso components IsNot Nothing Then
components.Dispose()
End If
Finally
MyBase.Dispose(disposing)
End Try
End Sub

'Requerido por el Diseñador de Windows Forms
Private components As System.ComponentModel.IContainer

'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
'Se puede modificar usando el Diseñador de Windows Forms.
'No lo modifique con el editor de código.
<System.Diagnostics.DebuggerStepThrough()> _
Private Sub InitializeComponent()
 Me.components = New System.ComponentModel.Container()
Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmsalidas))
 Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
 Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
 Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
Me.PanelSuperior = New System.Windows.Forms.Panel()
Me.CmdSalir = New System.Windows.Forms.Button()
Me.PanelCentral = New System.Windows.Forms.Panel()
Me.TabCabecera = New System.Windows.Forms.TabControl()
Me.TP00 = New System.Windows.Forms.TabPage()
Me.TP01 = New System.Windows.Forms.TabPage()
Me.TP02 = New System.Windows.Forms.TabPage()
Me.TP03 = New System.Windows.Forms.TabPage()
Me.TP04 = New System.Windows.Forms.TabPage()
Me.TP05 = New System.Windows.Forms.TabPage()
Me.TP06 = New System.Windows.Forms.TabPage()
Me.TP07 = New System.Windows.Forms.TabPage()
Me.TP08 = New System.Windows.Forms.TabPage()
Me.TP09 = New System.Windows.Forms.TabPage()
Me.CnTabla01 = New CnTabla.CnTabla()
Me.CnTabla02 = New CnTabla.CnTabla()
Me.CnTabla03 = New CnTabla.CnTabla()
Me.GridTabla02 = New System.Windows.Forms.DataGridView()
Me.GridTabla03 = New System.Windows.Forms.DataGridView()
Me.Lbl001 = New System.Windows.Forms.Label()
Me.TxtDatos001 = New System.Windows.Forms.TextBox()
Me.CnEdicion001 = New CnEdicion.CnEdicion()
Me.Lbl002 = New System.Windows.Forms.Label()
Me.TxtDatos002 = New System.Windows.Forms.TextBox()
Me.CnEdicion002 = New CnEdicion.CnEdicion()
Me.Lbl003 = New System.Windows.Forms.Label()
Me.TxtDatos003 = New System.Windows.Forms.TextBox()
Me.CnEdicion003 = New CnEdicion.CnEdicion()
Me.Lbl004 = New System.Windows.Forms.Label()
Me.TxtDatos004 = New System.Windows.Forms.TextBox()
Me.CnEdicion004 = New CnEdicion.CnEdicion()
Me.Lbl005 = New System.Windows.Forms.Label()
Me.TxtDatos005 = New System.Windows.Forms.TextBox()
Me.CnEdicion005 = New CnEdicion.CnEdicion()
Me.Lbl006 = New System.Windows.Forms.Label()
Me.TxtDatos006 = New System.Windows.Forms.TextBox()
Me.CnEdicion006 = New CnEdicion.CnEdicion()
Me.Lbl007 = New System.Windows.Forms.Label()
Me.TxtDatos007 = New System.Windows.Forms.TextBox()
Me.CnEdicion007 = New CnEdicion.CnEdicion()
Me.Lbl008 = New System.Windows.Forms.Label()
Me.TxtDatos008 = New System.Windows.Forms.TextBox()
Me.CnEdicion008 = New CnEdicion.CnEdicion()
Me.CmdGrid008 = New System.Windows.Forms.Button()
Me.TxtLookup0081 = New System.Windows.Forms.TextBox()
Me.Lbl009 = New System.Windows.Forms.Label()
Me.TxtDatos009 = New System.Windows.Forms.TextBox()
Me.CnEdicion009 = New CnEdicion.CnEdicion()
Me.CmdGrid009 = New System.Windows.Forms.Button()
Me.TxtLookup0091 = New System.Windows.Forms.TextBox()
Me.Lbl010 = New System.Windows.Forms.Label()
Me.TxtDatos010 = New System.Windows.Forms.TextBox()
Me.CnEdicion010 = New CnEdicion.CnEdicion()
Me.CmdGrid010 = New System.Windows.Forms.Button()
Me.TxtLookup0101 = New System.Windows.Forms.TextBox()
Me.Lbl011 = New System.Windows.Forms.Label()
Me.TxtDatos011 = New System.Windows.Forms.TextBox()
Me.CnEdicion011 = New CnEdicion.CnEdicion()
Me.CmdCombo011 = New System.Windows.Forms.Button()
Me.Lbl012 = New System.Windows.Forms.Label()
Me.TxtDatos012 = New System.Windows.Forms.TextBox()
Me.CnEdicion012 = New CnEdicion.CnEdicion()
Me.CmdGrid012 = New System.Windows.Forms.Button()
Me.TxtLookup0121 = New System.Windows.Forms.TextBox()
Me.Lbl013 = New System.Windows.Forms.Label()
Me.TxtDatos013 = New System.Windows.Forms.TextBox()
Me.CnEdicion013 = New CnEdicion.CnEdicion()
Me.Lbl014 = New System.Windows.Forms.Label()
Me.TxtDatos014 = New System.Windows.Forms.TextBox()
Me.CnEdicion014 = New CnEdicion.CnEdicion()
Me.Lbl015 = New System.Windows.Forms.Label()
Me.TxtDatos015 = New System.Windows.Forms.TextBox()
Me.CnEdicion015 = New CnEdicion.CnEdicion()
Me.Lbl016 = New System.Windows.Forms.Label()
Me.TxtDatos016 = New System.Windows.Forms.TextBox()
Me.CnEdicion016 = New CnEdicion.CnEdicion()
Me.Lbl017 = New System.Windows.Forms.Label()
Me.TxtDatos017 = New System.Windows.Forms.TextBox()
Me.CnEdicion017 = New CnEdicion.CnEdicion()
Me.Lbl018 = New System.Windows.Forms.Label()
Me.TxtDatos018 = New System.Windows.Forms.TextBox()
Me.CnEdicion018 = New CnEdicion.CnEdicion()
Me.Lbl019 = New System.Windows.Forms.Label()
Me.TxtDatos019 = New System.Windows.Forms.TextBox()
Me.CnEdicion019 = New CnEdicion.CnEdicion()
Me.Lbl020 = New System.Windows.Forms.Label()
Me.TxtDatos020 = New System.Windows.Forms.TextBox()
Me.CnEdicion020 = New CnEdicion.CnEdicion()
Me.Lbl021 = New System.Windows.Forms.Label()
Me.TxtDatos021 = New System.Windows.Forms.TextBox()
Me.CnEdicion021 = New CnEdicion.CnEdicion()
Me.CmdGrid021 = New System.Windows.Forms.Button()
Me.TxtLookup0211 = New System.Windows.Forms.TextBox()
Me.Lbl022 = New System.Windows.Forms.Label()
Me.TxtDatos022 = New System.Windows.Forms.TextBox()
Me.CnEdicion022 = New CnEdicion.CnEdicion()
Me.CmdGrid022 = New System.Windows.Forms.Button()
Me.TxtLookup0221 = New System.Windows.Forms.TextBox()
Me.Lbl023 = New System.Windows.Forms.Label()
Me.TxtDatos023 = New System.Windows.Forms.TextBox()
Me.CnEdicion023 = New CnEdicion.CnEdicion()
Me.Lbl024 = New System.Windows.Forms.Label()
Me.TxtDatos024 = New System.Windows.Forms.TextBox()
Me.CnEdicion024 = New CnEdicion.CnEdicion()
Me.CmdGrid024 = New System.Windows.Forms.Button()
Me.TxtLookup0241 = New System.Windows.Forms.TextBox()
Me.TxtLookup0242 = New System.Windows.Forms.TextBox()
Me.Lbl025 = New System.Windows.Forms.Label()
Me.TxtDatos025 = New System.Windows.Forms.TextBox()
Me.CnEdicion025 = New CnEdicion.CnEdicion()
Me.Lbl026 = New System.Windows.Forms.Label()
Me.TxtDatos026 = New System.Windows.Forms.TextBox()
Me.CnEdicion026 = New CnEdicion.CnEdicion()
Me.CmdGrid026 = New System.Windows.Forms.Button()
Me.TxtLookup0261 = New System.Windows.Forms.TextBox()
Me.Lbl027 = New System.Windows.Forms.Label()
Me.TxtDatos027 = New System.Windows.Forms.TextBox()
Me.CnEdicion027 = New CnEdicion.CnEdicion()
Me.Lbl028 = New System.Windows.Forms.Label()
Me.TxtDatos028 = New System.Windows.Forms.TextBox()
Me.CnEdicion028 = New CnEdicion.CnEdicion()
Me.Lbl029 = New System.Windows.Forms.Label()
Me.TxtDatos029 = New System.Windows.Forms.TextBox()
Me.CnEdicion029 = New CnEdicion.CnEdicion()
Me.Lbl030 = New System.Windows.Forms.Label()
Me.TxtDatos030 = New System.Windows.Forms.TextBox()
Me.CnEdicion030 = New CnEdicion.CnEdicion()
Me.Lbl031 = New System.Windows.Forms.Label()
Me.TxtDatos031 = New System.Windows.Forms.TextBox()
Me.CnEdicion031 = New CnEdicion.CnEdicion()
Me.Lbl032 = New System.Windows.Forms.Label()
Me.TxtDatos032 = New System.Windows.Forms.TextBox()
Me.CnEdicion032 = New CnEdicion.CnEdicion()
Me.CmdGrid032 = New System.Windows.Forms.Button()
Me.TxtLookup0321 = New System.Windows.Forms.TextBox()
Me.Lbl033 = New System.Windows.Forms.Label()
Me.TxtDatos033 = New System.Windows.Forms.TextBox()
Me.CnEdicion033 = New CnEdicion.CnEdicion()
Me.CmdGrid033 = New System.Windows.Forms.Button()
Me.TxtLookup0331 = New System.Windows.Forms.TextBox()
Me.Lbl034 = New System.Windows.Forms.Label()
Me.TxtDatos034 = New System.Windows.Forms.TextBox()
Me.CnEdicion034 = New CnEdicion.CnEdicion()
Me.CmdGrid034 = New System.Windows.Forms.Button()
Me.TxtLookup0341 = New System.Windows.Forms.TextBox()
Me.Lbl035 = New System.Windows.Forms.Label()
Me.TxtDatos035 = New System.Windows.Forms.TextBox()
Me.CnEdicion035 = New CnEdicion.CnEdicion()
Me.CmdCombo035 = New System.Windows.Forms.Button()
Me.CmdGrid035 = New System.Windows.Forms.Button()
Me.TxtLookup0351 = New System.Windows.Forms.TextBox()
Me.Lbl036 = New System.Windows.Forms.Label()
Me.TxtDatos036 = New System.Windows.Forms.TextBox()
Me.CnEdicion036 = New CnEdicion.CnEdicion()
Me.Lbl037 = New System.Windows.Forms.Label()
Me.TxtDatos037 = New System.Windows.Forms.TextBox()
Me.CnEdicion037 = New CnEdicion.CnEdicion()
Me.CmdFecha037 = New System.Windows.Forms.Button()
Me.Lbl038 = New System.Windows.Forms.Label()
Me.TxtDatos038 = New System.Windows.Forms.TextBox()
Me.CnEdicion038 = New CnEdicion.CnEdicion()
Me.CmdGrid038 = New System.Windows.Forms.Button()
Me.TxtLookup0381 = New System.Windows.Forms.TextBox()
Me.Lbl039 = New System.Windows.Forms.Label()
Me.TxtDatos039 = New System.Windows.Forms.TextBox()
Me.CnEdicion039 = New CnEdicion.CnEdicion()
Me.CmdGrid039 = New System.Windows.Forms.Button()
Me.TxtLookup0391 = New System.Windows.Forms.TextBox()
Me.Lbl040 = New System.Windows.Forms.Label()
Me.TxtDatos040 = New System.Windows.Forms.TextBox()
Me.CnEdicion040 = New CnEdicion.CnEdicion()
Me.CmdGrid040 = New System.Windows.Forms.Button()
Me.TxtLookup0401 = New System.Windows.Forms.TextBox()
Me.Lbl041 = New System.Windows.Forms.Label()
Me.TxtDatos041 = New System.Windows.Forms.TextBox()
Me.CnEdicion041 = New CnEdicion.CnEdicion()
Me.Lbl042 = New System.Windows.Forms.Label()
Me.TxtDatos042 = New System.Windows.Forms.TextBox()
Me.CnEdicion042 = New CnEdicion.CnEdicion()
Me.Lbl043 = New System.Windows.Forms.Label()
Me.TxtDatos043 = New System.Windows.Forms.TextBox()
Me.CnEdicion043 = New CnEdicion.CnEdicion()
Me.CnEdicion044 = New CnEdicion.CnEdicion()
Me.CnEdicion045 = New CnEdicion.CnEdicion()
Me.CnEdicion046 = New CnEdicion.CnEdicion()
Me.CnEdicion047 = New CnEdicion.CnEdicion()
Me.CnEdicion048 = New CnEdicion.CnEdicion()
Me.CnEdicion049 = New CnEdicion.CnEdicion()
Me.CnEdicion050 = New CnEdicion.CnEdicion()
Me.CnEdicion051 = New CnEdicion.CnEdicion()
Me.CnEdicion052 = New CnEdicion.CnEdicion()
Me.CnEdicion053 = New CnEdicion.CnEdicion()
Me.CnEdicion054 = New CnEdicion.CnEdicion()
Me.CnEdicion055 = New CnEdicion.CnEdicion()
Me.CnEdicion056 = New CnEdicion.CnEdicion()
Me.CnEdicion057 = New CnEdicion.CnEdicion()
Me.Lbl058 = New System.Windows.Forms.Label()
Me.TxtDatos058 = New System.Windows.Forms.TextBox()
Me.CnEdicion058 = New CnEdicion.CnEdicion()
Me.CmdGrid058 = New System.Windows.Forms.Button()
Me.TxtLookup0581 = New System.Windows.Forms.TextBox()
Me.Lbl059 = New System.Windows.Forms.Label()
Me.TxtDatos059 = New System.Windows.Forms.TextBox()
Me.CnEdicion059 = New CnEdicion.CnEdicion()
Me.CmdGrid059 = New System.Windows.Forms.Button()
Me.TxtLookup0591 = New System.Windows.Forms.TextBox()
Me.Lbl060 = New System.Windows.Forms.Label()
Me.TxtDatos060 = New System.Windows.Forms.TextBox()
Me.CnEdicion060 = New CnEdicion.CnEdicion()
Me.CmdGrid060 = New System.Windows.Forms.Button()
Me.TxtLookup0601 = New System.Windows.Forms.TextBox()
Me.Lbl061 = New System.Windows.Forms.Label()
Me.TxtDatos061 = New System.Windows.Forms.TextBox()
Me.CnEdicion061 = New CnEdicion.CnEdicion()
Me.CmdCombo061 = New System.Windows.Forms.Button()
Me.Lbl062 = New System.Windows.Forms.Label()
Me.TxtDatos062 = New System.Windows.Forms.TextBox()
Me.CnEdicion062 = New CnEdicion.CnEdicion()
Me.Lbl063 = New System.Windows.Forms.Label()
Me.TxtDatos063 = New System.Windows.Forms.TextBox()
Me.CnEdicion063 = New CnEdicion.CnEdicion()
Me.CnEdicion064 = New CnEdicion.CnEdicion()
Me.CnEdicion065 = New CnEdicion.CnEdicion()
Me.CnEdicion066 = New CnEdicion.CnEdicion()
Me.CnEdicion067 = New CnEdicion.CnEdicion()
Me.CnEdicion068 = New CnEdicion.CnEdicion()
Me.CnEdicion069 = New CnEdicion.CnEdicion()
Me.CnEdicion070 = New CnEdicion.CnEdicion()
Me.CnEdicion071 = New CnEdicion.CnEdicion()
Me.CnEdicion072 = New CnEdicion.CnEdicion()
Me.LblDuplicado0441 = New System.Windows.Forms.Label()
Me.TxtDuplicado0441 = New System.Windows.Forms.TextBox()
Me.TabGeneral = New System.Windows.Forms.TabControl()
Me.TabPage00 = New System.Windows.Forms.TabPage()
Me.TabPage01 = New System.Windows.Forms.TabPage()
Me.TabPage02 = New System.Windows.Forms.TabPage()
Me.TabPage03 = New System.Windows.Forms.TabPage()
Me.TabPage04 = New System.Windows.Forms.TabPage()
Me.TabPage05 = New System.Windows.Forms.TabPage()
Me.TabPage06 = New System.Windows.Forms.TabPage()
Me.TabPage07 = New System.Windows.Forms.TabPage()
Me.TabPage08 = New System.Windows.Forms.TabPage()
Me.TabPage09 = New System.Windows.Forms.TabPage()
 Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
Me.PanelInferior = New System.Windows.Forms.Panel()
Me.PanelSuperior.SuspendLayout()
Me.PanelCentral.SuspendLayout()
Me.TabCabecera.SuspendLayout()
Me.TP01.SuspendLayout()
Me.TP00.SuspendLayout()
Me.TabGeneral.SuspendLayout()
Me.TabPage02.SuspendLayout()
Me.TabPage01.SuspendLayout()
Me.TabPage00.SuspendLayout()
CType(Me.GridTabla03, System.ComponentModel.ISupportInitialize).BeginInit()
CType(Me.GridTabla02, System.ComponentModel.ISupportInitialize).BeginInit()
Me.SuspendLayout()
'
'PanelSuperior
'
Me.PanelSuperior.Controls.Add(Me.CnEdicion043)
Me.PanelSuperior.Controls.Add(Me.TxtDatos043)
Me.PanelSuperior.Controls.Add(Me.Lbl043)
Me.PanelSuperior.Controls.Add(Me.CnEdicion042)
Me.PanelSuperior.Controls.Add(Me.TxtDatos042)
Me.PanelSuperior.Controls.Add(Me.Lbl042)
Me.PanelSuperior.Controls.Add(Me.CnEdicion041)
Me.PanelSuperior.Controls.Add(Me.TxtDatos041)
Me.PanelSuperior.Controls.Add(Me.Lbl041)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0401)
Me.PanelSuperior.Controls.Add(Me.CmdGrid040)
Me.PanelSuperior.Controls.Add(Me.CnEdicion040)
Me.PanelSuperior.Controls.Add(Me.TxtDatos040)
Me.PanelSuperior.Controls.Add(Me.Lbl040)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0391)
Me.PanelSuperior.Controls.Add(Me.CmdGrid039)
Me.PanelSuperior.Controls.Add(Me.CnEdicion039)
Me.PanelSuperior.Controls.Add(Me.TxtDatos039)
Me.PanelSuperior.Controls.Add(Me.Lbl039)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0381)
Me.PanelSuperior.Controls.Add(Me.CmdGrid038)
Me.PanelSuperior.Controls.Add(Me.CnEdicion038)
Me.PanelSuperior.Controls.Add(Me.TxtDatos038)
Me.PanelSuperior.Controls.Add(Me.Lbl038)
Me.PanelSuperior.Controls.Add(Me.CmdFecha037)
Me.PanelSuperior.Controls.Add(Me.CnEdicion037)
Me.PanelSuperior.Controls.Add(Me.TxtDatos037)
Me.PanelSuperior.Controls.Add(Me.Lbl037)
Me.PanelSuperior.Controls.Add(Me.CnEdicion036)
Me.PanelSuperior.Controls.Add(Me.TxtDatos036)
Me.PanelSuperior.Controls.Add(Me.Lbl036)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0351)
Me.PanelSuperior.Controls.Add(Me.CmdGrid035)
Me.PanelSuperior.Controls.Add(Me.CmdCombo035)
Me.PanelSuperior.Controls.Add(Me.CnEdicion035)
Me.PanelSuperior.Controls.Add(Me.TxtDatos035)
Me.PanelSuperior.Controls.Add(Me.Lbl035)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0341)
Me.PanelSuperior.Controls.Add(Me.CmdGrid034)
Me.PanelSuperior.Controls.Add(Me.CnEdicion034)
Me.PanelSuperior.Controls.Add(Me.TxtDatos034)
Me.PanelSuperior.Controls.Add(Me.Lbl034)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0331)
Me.PanelSuperior.Controls.Add(Me.CmdGrid033)
Me.PanelSuperior.Controls.Add(Me.CnEdicion033)
Me.PanelSuperior.Controls.Add(Me.TxtDatos033)
Me.PanelSuperior.Controls.Add(Me.Lbl033)
Me.PanelSuperior.Controls.Add(Me.TxtLookup0321)
Me.PanelSuperior.Controls.Add(Me.CmdGrid032)
Me.PanelSuperior.Controls.Add(Me.CnEdicion032)
Me.PanelSuperior.Controls.Add(Me.TxtDatos032)
Me.PanelSuperior.Controls.Add(Me.Lbl032)
Me.PanelSuperior.Controls.Add(Me.CnTabla01)
Me.PanelSuperior.BackColor = System.Drawing.SystemColors.Control
Me.PanelSuperior.Controls.Add(Me.CmdSalir)
Me.PanelSuperior.Dock = System.Windows.Forms.DockStyle.Top
Me.PanelSuperior.Location = New System.Drawing.Point(0, 0)
Me.PanelSuperior.Name = "PanelSuperior"
Me.PanelSuperior.Size = New System.Drawing.Size(1184, 223)
Me.PanelSuperior.TabIndex = 9999
Me.PanelSuperior.CausesValidation = False
'
'CnTabla01
'
Me.CnTabla01.Autosize = True
Me.CnTabla01.BackColor = System.Drawing.SystemColors.Control
Me.CnTabla01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.CnTabla01.CargaAlInicio = True
Me.CnTabla01.CausesValidation = False
Me.CnTabla01.EnlaceATablaPadre = -1
Me.CnTabla01.Estado = CnTabla.CnTabla.EstadoCnTabla.Inactivo
Me.CnTabla01.Formato = CnTabla.CnTabla.FormatoCnTabla.TablaPrincipalSuperior
Me.CnTabla01.HayBorrado = True
Me.CnTabla01.HayCreacion = True
Me.CnTabla01.HayDesplegar = True
Me.CnTabla01.HayModificacion = True
Me.CnTabla01.HaySeleccion = True
Me.CnTabla01.HaySiguienteAnterior = True
Me.CnTabla01.Location = New System.Drawing.Point(3,0)
Me.CnTabla01.Margin = New System.Windows.Forms.Padding(0)
Me.CnTabla01.Name = "CnTabla01"
Me.CnTabla01.Size = New System.Drawing.Size(550, 48)
Me.CnTabla01.TabIndex = 10000
Me.CnTabla01.TabStop = False
Me.CnTabla01.Tabla = "cabeceras_salida"
'
'Lbl032
'
Me.Lbl032.AutoSize = True
Me.Lbl032.Location = New System.Drawing.Point(627,14)
Me.Lbl032.Name = "Lbl032"
Me.Lbl032.Size = New System.Drawing.Size(41, 13)
Me.Lbl032.Tabindex = 9999
Me.Lbl032.Text = "Empresa:"
'
'TxtDatos032
'
Me.TxtDatos032.Location = New System.Drawing.Point(680,12)
Me.TxtDatos032.Name = "TxtDatos032"
Me.TxtDatos032.ReadOnly = True
Me.TxtDatos032.Size = New System.Drawing.Size(160, 20)
Me.TxtDatos032.Tabindex = 9999
'
'CnEdicion032
'
Me.CnEdicion032.AceptaEspacios = True
Me.CnEdicion032.AceptaMayusculas = True
Me.CnEdicion032.AceptaMayusculasAcentuadas = False
Me.CnEdicion032.AceptaMinusculas = False
Me.CnEdicion032.AceptaMinusculasAcentuadas = False
Me.CnEdicion032.AceptaNumeros = True
Me.CnEdicion032.AceptaSimbolos = True
Me.CnEdicion032.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion032.ConvierteAMayusculas = True
Me.CnEdicion032.ConvierteAMinusculas = False
Me.CnEdicion032.EsFechaHoraCreacion = False
Me.CnEdicion032.EsFechaHoraModificacion = False
Me.CnEdicion032.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion032.ColorFondo = System.Drawing.Color.White
Me.CnEdicion032.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion032.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion032.Campo = "empresa"
Me.CnEdicion032.CampoEnlacesLookup1 = "razon_social"
Me.CnEdicion032.CampoEnlacesLookup2 = Nothing
Me.CnEdicion032.CampoEnlacesLookup3 = Nothing
Me.CnEdicion032.EdicionEnGrid = False
Me.CnEdicion032.TituloParaGrid = Nothing
Me.CnEdicion032.AnchoColumnaGrid = 0
Me.CnEdicion032.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion032.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion032.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion032.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion032.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion032.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion032.EnCreacionSoloLectura = False
Me.CnEdicion032.EnCreacionOculto = False
Me.CnEdicion032.SiempreSoloLectura = False
Me.CnEdicion032.SiempreOculto = False
Me.CnEdicion032.EnlacesLookup1 = 31172
Me.CnEdicion032.EnlacesLookup2 = 0
Me.CnEdicion032.EnlacesLookup3 = 0
Me.CnEdicion032.EnModificacionSoloLectura = False
Me.CnEdicion032.EnModificacionOculto = False
Me.CnEdicion032.Fuente = Nothing
Me.CnEdicion032.HayMascaraEspecial = False
Me.CnEdicion032.HayValorDefecto = False
Me.CnEdicion032.NumeroParametroValorDefecto = 0
Me.CnEdicion032.ValorDefecto = ""
Me.CnEdicion032.HayValorFijo = True
Me.CnEdicion032.NumeroParametroValorFijo = 1
Me.CnEdicion032.ValorFijo = ""
Me.CnEdicion032.HayValorFijoCreacion = False
Me.CnEdicion032.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion032.ValorFijoCreacion = ""
Me.CnEdicion032.Location = New System.Drawing.Point(684,12)
Me.CnEdicion032.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion032.MascaraEspecial = ""
Me.CnEdicion032.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion032.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion032.MaximoNumero = 999999999999999.0R
Me.CnEdicion032.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion032.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion032.MinimoNumero = -999999999999999.0R
Me.CnEdicion032.Name = "CnEdicion032"
Me.CnEdicion032.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion032.TabIndex = 9999
Me.CnEdicion032.Tabla = "cabeceras_salida"
'
'CmdGrid032
'
Me.CmdGrid032.Image = CType(Resources.GetObject("CmdGrid032.Image"), System.Drawing.Image)
Me.CmdGrid032.Location = New System.Drawing.Point(841,12)
Me.CmdGrid032.Name = "CmdGrid032"
Me.CmdGrid032.Size = New System.Drawing.Size(24,22)
Me.CmdGrid032.UseVisualStyleBackColor = True
Me.CmdGrid032.Tabindex = 9999
'
'TxtLookup0321
'
Me.TxtLookup0321.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0321.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0321.Location = New System.Drawing.Point(875,15)
Me.TxtLookup0321.Name = "TxtLookup0321"
Me.TxtLookup0321.ReadOnly = True
Me.TxtLookup0321.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0321.Tabindex = 9999
'
'Lbl033
'
Me.Lbl033.AutoSize = True
Me.Lbl033.Location = New System.Drawing.Point(629,35)
Me.Lbl033.Name = "Lbl033"
Me.Lbl033.Size = New System.Drawing.Size(41, 13)
Me.Lbl033.Tabindex = 9999
Me.Lbl033.Text = "Ejercicio:"
'
'TxtDatos033
'
Me.TxtDatos033.Location = New System.Drawing.Point(680,33)
Me.TxtDatos033.Name = "TxtDatos033"
Me.TxtDatos033.ReadOnly = True
Me.TxtDatos033.Size = New System.Drawing.Size(120, 20)
Me.TxtDatos033.Tabindex = 9999
'
'CnEdicion033
'
Me.CnEdicion033.AceptaEspacios = True
Me.CnEdicion033.AceptaMayusculas = True
Me.CnEdicion033.AceptaMayusculasAcentuadas = False
Me.CnEdicion033.AceptaMinusculas = False
Me.CnEdicion033.AceptaMinusculasAcentuadas = False
Me.CnEdicion033.AceptaNumeros = True
Me.CnEdicion033.AceptaSimbolos = True
Me.CnEdicion033.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion033.ConvierteAMayusculas = True
Me.CnEdicion033.ConvierteAMinusculas = False
Me.CnEdicion033.EsFechaHoraCreacion = False
Me.CnEdicion033.EsFechaHoraModificacion = False
Me.CnEdicion033.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion033.ColorFondo = System.Drawing.Color.White
Me.CnEdicion033.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion033.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion033.Campo = "ejercicio"
Me.CnEdicion033.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion033.CampoEnlacesLookup2 = Nothing
Me.CnEdicion033.CampoEnlacesLookup3 = Nothing
Me.CnEdicion033.EdicionEnGrid = False
Me.CnEdicion033.TituloParaGrid = Nothing
Me.CnEdicion033.AnchoColumnaGrid = 0
Me.CnEdicion033.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion033.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion033.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion033.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion033.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion033.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion033.EnCreacionSoloLectura = False
Me.CnEdicion033.EnCreacionOculto = False
Me.CnEdicion033.SiempreSoloLectura = False
Me.CnEdicion033.SiempreOculto = False
Me.CnEdicion033.EnlacesLookup1 = 31183
Me.CnEdicion033.EnlacesLookup2 = 0
Me.CnEdicion033.EnlacesLookup3 = 0
Me.CnEdicion033.EnModificacionSoloLectura = False
Me.CnEdicion033.EnModificacionOculto = False
Me.CnEdicion033.Fuente = Nothing
Me.CnEdicion033.HayMascaraEspecial = False
Me.CnEdicion033.HayValorDefecto = False
Me.CnEdicion033.NumeroParametroValorDefecto = 0
Me.CnEdicion033.ValorDefecto = ""
Me.CnEdicion033.HayValorFijo = True
Me.CnEdicion033.NumeroParametroValorFijo = 3
Me.CnEdicion033.ValorFijo = ""
Me.CnEdicion033.HayValorFijoCreacion = False
Me.CnEdicion033.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion033.ValorFijoCreacion = ""
Me.CnEdicion033.Location = New System.Drawing.Point(684,33)
Me.CnEdicion033.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion033.MascaraEspecial = ""
Me.CnEdicion033.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion033.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion033.MaximoNumero = 999999999999999.0R
Me.CnEdicion033.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion033.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion033.MinimoNumero = -999999999999999.0R
Me.CnEdicion033.Name = "CnEdicion033"
Me.CnEdicion033.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion033.TabIndex = 9999
Me.CnEdicion033.Tabla = "cabeceras_salida"
'
'CmdGrid033
'
Me.CmdGrid033.Image = CType(Resources.GetObject("CmdGrid033.Image"), System.Drawing.Image)
Me.CmdGrid033.Location = New System.Drawing.Point(801,33)
Me.CmdGrid033.Name = "CmdGrid033"
Me.CmdGrid033.Size = New System.Drawing.Size(24,22)
Me.CmdGrid033.UseVisualStyleBackColor = True
Me.CmdGrid033.Tabindex = 9999
'
'TxtLookup0331
'
Me.TxtLookup0331.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0331.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0331.Location = New System.Drawing.Point(835,36)
Me.TxtLookup0331.Name = "TxtLookup0331"
Me.TxtLookup0331.ReadOnly = True
Me.TxtLookup0331.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0331.Tabindex = 9999
'
'Lbl034
'
Me.Lbl034.AutoSize = True
Me.Lbl034.Location = New System.Drawing.Point(78,56)
Me.Lbl034.Name = "Lbl034"
Me.Lbl034.Size = New System.Drawing.Size(41, 13)
Me.Lbl034.Tabindex = 9999
Me.Lbl034.Text = "Serie:"
'
'TxtDatos034
'
Me.TxtDatos034.Location = New System.Drawing.Point(114,54)
Me.TxtDatos034.Name = "TxtDatos034"
Me.TxtDatos034.ReadOnly = True
Me.TxtDatos034.Size = New System.Drawing.Size(64, 20)
Me.TxtDatos034.Tabindex = 9999
'
'CnEdicion034
'
Me.CnEdicion034.AceptaEspacios = True
Me.CnEdicion034.AceptaMayusculas = True
Me.CnEdicion034.AceptaMayusculasAcentuadas = False
Me.CnEdicion034.AceptaMinusculas = False
Me.CnEdicion034.AceptaMinusculasAcentuadas = False
Me.CnEdicion034.AceptaNumeros = True
Me.CnEdicion034.AceptaSimbolos = True
Me.CnEdicion034.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion034.ConvierteAMayusculas = True
Me.CnEdicion034.ConvierteAMinusculas = False
Me.CnEdicion034.EsFechaHoraCreacion = False
Me.CnEdicion034.EsFechaHoraModificacion = False
Me.CnEdicion034.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion034.ColorFondo = System.Drawing.Color.White
Me.CnEdicion034.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion034.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion034.Campo = "serie"
Me.CnEdicion034.CampoEnlacesLookup1 = "descripcion_serie"
Me.CnEdicion034.CampoEnlacesLookup2 = Nothing
Me.CnEdicion034.CampoEnlacesLookup3 = Nothing
Me.CnEdicion034.EdicionEnGrid = False
Me.CnEdicion034.TituloParaGrid = Nothing
Me.CnEdicion034.AnchoColumnaGrid = 0
Me.CnEdicion034.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion034.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion034.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion034.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion034.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion034.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion034.EnCreacionSoloLectura = False
Me.CnEdicion034.EnCreacionOculto = False
Me.CnEdicion034.SiempreSoloLectura = False
Me.CnEdicion034.SiempreOculto = False
Me.CnEdicion034.EnlacesLookup1 = 32142
Me.CnEdicion034.EnlacesLookup2 = 0
Me.CnEdicion034.EnlacesLookup3 = 0
Me.CnEdicion034.EnModificacionSoloLectura = False
Me.CnEdicion034.EnModificacionOculto = False
Me.CnEdicion034.Fuente = Nothing
Me.CnEdicion034.HayMascaraEspecial = False
Me.CnEdicion034.HayValorDefecto = True
Me.CnEdicion034.NumeroParametroValorDefecto = 0
Me.CnEdicion034.ValorDefecto = "A"
Me.CnEdicion034.HayValorFijo = False
Me.CnEdicion034.NumeroParametroValorFijo = 0
Me.CnEdicion034.ValorFijo = ""
Me.CnEdicion034.HayValorFijoCreacion = False
Me.CnEdicion034.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion034.ValorFijoCreacion = ""
Me.CnEdicion034.Location = New System.Drawing.Point(118,54)
Me.CnEdicion034.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion034.MascaraEspecial = ""
Me.CnEdicion034.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion034.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion034.MaximoNumero = 999999999999999.0R
Me.CnEdicion034.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion034.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion034.MinimoNumero = -999999999999999.0R
Me.CnEdicion034.Name = "CnEdicion034"
Me.CnEdicion034.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion034.TabIndex = 9999
Me.CnEdicion034.Tabla = "cabeceras_salida"
'
'CmdGrid034
'
Me.CmdGrid034.Image = CType(Resources.GetObject("CmdGrid034.Image"), System.Drawing.Image)
Me.CmdGrid034.Location = New System.Drawing.Point(179,54)
Me.CmdGrid034.Name = "CmdGrid034"
Me.CmdGrid034.Size = New System.Drawing.Size(24,22)
Me.CmdGrid034.UseVisualStyleBackColor = True
Me.CmdGrid034.Tabindex = 9999
'
'TxtLookup0341
'
Me.TxtLookup0341.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0341.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0341.Location = New System.Drawing.Point(213,57)
Me.TxtLookup0341.Name = "TxtLookup0341"
Me.TxtLookup0341.ReadOnly = True
Me.TxtLookup0341.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0341.Tabindex = 9999
'
'Lbl035
'
Me.Lbl035.AutoSize = True
Me.Lbl035.Location = New System.Drawing.Point(11,77)
Me.Lbl035.Name = "Lbl035"
Me.Lbl035.Size = New System.Drawing.Size(41, 13)
Me.Lbl035.Tabindex = 9999
Me.Lbl035.Text = "Tipo de documento:"
'
'TxtDatos035
'
Me.TxtDatos035.Location = New System.Drawing.Point(114,75)
Me.TxtDatos035.Name = "TxtDatos035"
Me.TxtDatos035.ReadOnly = True
Me.TxtDatos035.Size = New System.Drawing.Size(88, 20)
Me.TxtDatos035.Tabindex = 9999
'
'CnEdicion035
'
Me.CnEdicion035.AceptaEspacios = True
Me.CnEdicion035.AceptaMayusculas = True
Me.CnEdicion035.AceptaMayusculasAcentuadas = False
Me.CnEdicion035.AceptaMinusculas = False
Me.CnEdicion035.AceptaMinusculasAcentuadas = False
Me.CnEdicion035.AceptaNumeros = True
Me.CnEdicion035.AceptaSimbolos = True
Me.CnEdicion035.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion035.ConvierteAMayusculas = True
Me.CnEdicion035.ConvierteAMinusculas = False
Me.CnEdicion035.EsFechaHoraCreacion = False
Me.CnEdicion035.EsFechaHoraModificacion = False
Me.CnEdicion035.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion035.ColorFondo = System.Drawing.Color.White
Me.CnEdicion035.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion035.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion035.Campo = "tipo_documento"
Me.CnEdicion035.CampoEnlacesLookup1 = "descripcion_tipo"
Me.CnEdicion035.CampoEnlacesLookup2 = Nothing
Me.CnEdicion035.CampoEnlacesLookup3 = Nothing
Me.CnEdicion035.EdicionEnGrid = False
Me.CnEdicion035.TituloParaGrid = Nothing
Me.CnEdicion035.AnchoColumnaGrid = 0
Me.CnEdicion035.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion035.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion035.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion035.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion035.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion035.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion035.EnCreacionSoloLectura = False
Me.CnEdicion035.EnCreacionOculto = False
Me.CnEdicion035.SiempreSoloLectura = False
Me.CnEdicion035.SiempreOculto = False
Me.CnEdicion035.EnlacesLookup1 = 31179
Me.CnEdicion035.EnlacesLookup2 = 0
Me.CnEdicion035.EnlacesLookup3 = 0
Me.CnEdicion035.EnModificacionSoloLectura = False
Me.CnEdicion035.EnModificacionOculto = False
Me.CnEdicion035.Fuente = Nothing
Me.CnEdicion035.HayMascaraEspecial = False
Me.CnEdicion035.HayValorDefecto = True
Me.CnEdicion035.NumeroParametroValorDefecto = 0
Me.CnEdicion035.ValorDefecto = "A"
Me.CnEdicion035.HayValorFijo = False
Me.CnEdicion035.NumeroParametroValorFijo = 0
Me.CnEdicion035.ValorFijo = ""
Me.CnEdicion035.HayValorFijoCreacion = False
Me.CnEdicion035.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion035.ValorFijoCreacion = ""
Me.CnEdicion035.Location = New System.Drawing.Point(118,75)
Me.CnEdicion035.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion035.MascaraEspecial = ""
Me.CnEdicion035.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion035.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion035.MaximoNumero = 999999999999999.0R
Me.CnEdicion035.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion035.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion035.MinimoNumero = -999999999999999.0R
Me.CnEdicion035.Name = "CnEdicion035"
Me.CnEdicion035.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion035.TabIndex = 9999
Me.CnEdicion035.Tabla = "cabeceras_salida"
'
'CmdCombo035
'
Me.CmdCombo035.Image = CType(Resources.GetObject("CmdCombo035.Image"), System.Drawing.Image)
Me.CmdCombo035.Location = New System.Drawing.Point(203,75)
Me.CmdCombo035.Name = "CmdCombo035"
Me.CmdCombo035.Size = New System.Drawing.Size(24,22)
Me.CmdCombo035.UseVisualStyleBackColor = True
Me.CmdCombo035.Tabindex = 9999
'
'CmdGrid035
'
Me.CmdGrid035.Image = CType(Resources.GetObject("CmdGrid035.Image"), System.Drawing.Image)
Me.CmdGrid035.Location = New System.Drawing.Point(228,75)
Me.CmdGrid035.Name = "CmdGrid035"
Me.CmdGrid035.Size = New System.Drawing.Size(24,22)
Me.CmdGrid035.UseVisualStyleBackColor = True
Me.CmdGrid035.Tabindex = 9999
'
'TxtLookup0351
'
Me.TxtLookup0351.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0351.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0351.Location = New System.Drawing.Point(262,78)
Me.TxtLookup0351.Name = "TxtLookup0351"
Me.TxtLookup0351.ReadOnly = True
Me.TxtLookup0351.Size = New System.Drawing.Size(240, 13)
Me.TxtLookup0351.Tabindex = 9999
'
'Lbl036
'
Me.Lbl036.AutoSize = True
Me.Lbl036.Location = New System.Drawing.Point(24,98)
Me.Lbl036.Name = "Lbl036"
Me.Lbl036.Size = New System.Drawing.Size(41, 13)
Me.Lbl036.Tabindex = 9999
Me.Lbl036.Text = "Núm.documento:"
'
'TxtDatos036
'
Me.TxtDatos036.Location = New System.Drawing.Point(114,96)
Me.TxtDatos036.Name = "TxtDatos036"
Me.TxtDatos036.ReadOnly = True
Me.TxtDatos036.Size = New System.Drawing.Size(120, 20)
Me.TxtDatos036.Tabindex = 9999
'
'CnEdicion036
'
Me.CnEdicion036.AceptaEspacios = True
Me.CnEdicion036.AceptaMayusculas = True
Me.CnEdicion036.AceptaMayusculasAcentuadas = False
Me.CnEdicion036.AceptaMinusculas = False
Me.CnEdicion036.AceptaMinusculasAcentuadas = False
Me.CnEdicion036.AceptaNumeros = True
Me.CnEdicion036.AceptaSimbolos = True
Me.CnEdicion036.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion036.ConvierteAMayusculas = True
Me.CnEdicion036.ConvierteAMinusculas = False
Me.CnEdicion036.EsFechaHoraCreacion = False
Me.CnEdicion036.EsFechaHoraModificacion = False
Me.CnEdicion036.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion036.ColorFondo = System.Drawing.Color.White
Me.CnEdicion036.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion036.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion036.Campo = "numero_documento"
Me.CnEdicion036.CampoEnlacesLookup1 = Nothing
Me.CnEdicion036.CampoEnlacesLookup2 = Nothing
Me.CnEdicion036.CampoEnlacesLookup3 = Nothing
Me.CnEdicion036.EdicionEnGrid = False
Me.CnEdicion036.TituloParaGrid = Nothing
Me.CnEdicion036.AnchoColumnaGrid = 0
Me.CnEdicion036.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion036.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion036.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion036.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion036.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion036.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion036.EnCreacionSoloLectura = False
Me.CnEdicion036.EnCreacionOculto = False
Me.CnEdicion036.SiempreSoloLectura = False
Me.CnEdicion036.SiempreOculto = False
Me.CnEdicion036.EnlacesLookup1 = 0
Me.CnEdicion036.EnlacesLookup2 = 0
Me.CnEdicion036.EnlacesLookup3 = 0
Me.CnEdicion036.EnModificacionSoloLectura = False
Me.CnEdicion036.EnModificacionOculto = False
Me.CnEdicion036.Fuente = Nothing
Me.CnEdicion036.HayMascaraEspecial = False
Me.CnEdicion036.HayValorDefecto = False
Me.CnEdicion036.NumeroParametroValorDefecto = 0
Me.CnEdicion036.ValorDefecto = ""
Me.CnEdicion036.HayValorFijo = False
Me.CnEdicion036.NumeroParametroValorFijo = 0
Me.CnEdicion036.ValorFijo = ""
Me.CnEdicion036.HayValorFijoCreacion = False
Me.CnEdicion036.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion036.ValorFijoCreacion = ""
Me.CnEdicion036.Location = New System.Drawing.Point(118,96)
Me.CnEdicion036.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion036.MascaraEspecial = ""
Me.CnEdicion036.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion036.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion036.MaximoNumero = 999999999999999.0R
Me.CnEdicion036.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion036.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion036.MinimoNumero = -999999999999999.0R
Me.CnEdicion036.Name = "CnEdicion036"
Me.CnEdicion036.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion036.TabIndex = 9999
Me.CnEdicion036.Tabla = "cabeceras_salida"
'
'Lbl037
'
Me.Lbl037.AutoSize = True
Me.Lbl037.Location = New System.Drawing.Point(397,98)
Me.Lbl037.Name = "Lbl037"
Me.Lbl037.Size = New System.Drawing.Size(41, 13)
Me.Lbl037.Tabindex = 9999
Me.Lbl037.Text = "Fecha documento:"
'
'TxtDatos037
'
Me.TxtDatos037.Location = New System.Drawing.Point(494,96)
Me.TxtDatos037.Name = "TxtDatos037"
Me.TxtDatos037.ReadOnly = True
Me.TxtDatos037.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos037.Tabindex = 9999
'
'CnEdicion037
'
Me.CnEdicion037.AceptaEspacios = True
Me.CnEdicion037.AceptaMayusculas = True
Me.CnEdicion037.AceptaMayusculasAcentuadas = True
Me.CnEdicion037.AceptaMinusculas = True
Me.CnEdicion037.AceptaMinusculasAcentuadas = True
Me.CnEdicion037.AceptaNumeros = True
Me.CnEdicion037.AceptaSimbolos = False
Me.CnEdicion037.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion037.ConvierteAMayusculas = False
Me.CnEdicion037.ConvierteAMinusculas = False
Me.CnEdicion037.EsFechaHoraCreacion = False
Me.CnEdicion037.EsFechaHoraModificacion = False
Me.CnEdicion037.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion037.ColorFondo = System.Drawing.Color.White
Me.CnEdicion037.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion037.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion037.Campo = "fecha_documento"
Me.CnEdicion037.CampoEnlacesLookup1 = Nothing
Me.CnEdicion037.CampoEnlacesLookup2 = Nothing
Me.CnEdicion037.CampoEnlacesLookup3 = Nothing
Me.CnEdicion037.EdicionEnGrid = False
Me.CnEdicion037.TituloParaGrid = Nothing
Me.CnEdicion037.AnchoColumnaGrid = 0
Me.CnEdicion037.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion037.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion037.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion037.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion037.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion037.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion037.EnCreacionSoloLectura = False
Me.CnEdicion037.EnCreacionOculto = False
Me.CnEdicion037.SiempreSoloLectura = False
Me.CnEdicion037.SiempreOculto = False
Me.CnEdicion037.EnlacesLookup1 = 0
Me.CnEdicion037.EnlacesLookup2 = 0
Me.CnEdicion037.EnlacesLookup3 = 0
Me.CnEdicion037.EnModificacionSoloLectura = False
Me.CnEdicion037.EnModificacionOculto = False
Me.CnEdicion037.Fuente = Nothing
Me.CnEdicion037.HayMascaraEspecial = False
Me.CnEdicion037.HayValorDefecto = False
Me.CnEdicion037.NumeroParametroValorDefecto = 0
Me.CnEdicion037.ValorDefecto = ""
Me.CnEdicion037.HayValorFijo = False
Me.CnEdicion037.NumeroParametroValorFijo = 0
Me.CnEdicion037.ValorFijo = ""
Me.CnEdicion037.HayValorFijoCreacion = False
Me.CnEdicion037.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion037.ValorFijoCreacion = ""
Me.CnEdicion037.Location = New System.Drawing.Point(498,96)
Me.CnEdicion037.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion037.MascaraEspecial = ""
Me.CnEdicion037.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion037.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion037.MaximoNumero = 999999999999999.0R
Me.CnEdicion037.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion037.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion037.MinimoNumero = -999999999999999.0R
Me.CnEdicion037.Name = "CnEdicion037"
Me.CnEdicion037.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion037.TabIndex = 9999
Me.CnEdicion037.Tabla = "cabeceras_salida"
'
'CmdFecha037
'
Me.CmdFecha037.Image = CType(Resources.GetObject("CmdFecha037.Image"), System.Drawing.Image)
Me.CmdFecha037.Location = New System.Drawing.Point(595,96)
Me.CmdFecha037.Name = "CmdFecha037"
Me.CmdFecha037.Size = New System.Drawing.Size(24,22)
Me.CmdFecha037.UseVisualStyleBackColor = True
Me.CmdFecha037.Tabindex = 9999
'
'Lbl038
'
Me.Lbl038.AutoSize = True
Me.Lbl038.Location = New System.Drawing.Point(20,119)
Me.Lbl038.Name = "Lbl038"
Me.Lbl038.Size = New System.Drawing.Size(41, 13)
Me.Lbl038.Tabindex = 9999
Me.Lbl038.Text = "Código clave opa:"
'
'TxtDatos038
'
Me.TxtDatos038.Location = New System.Drawing.Point(114,117)
Me.TxtDatos038.Name = "TxtDatos038"
Me.TxtDatos038.ReadOnly = True
Me.TxtDatos038.Size = New System.Drawing.Size(20, 20)
Me.TxtDatos038.Tabindex = 9999
'
'CnEdicion038
'
Me.CnEdicion038.AceptaEspacios = True
Me.CnEdicion038.AceptaMayusculas = True
Me.CnEdicion038.AceptaMayusculasAcentuadas = False
Me.CnEdicion038.AceptaMinusculas = False
Me.CnEdicion038.AceptaMinusculasAcentuadas = False
Me.CnEdicion038.AceptaNumeros = True
Me.CnEdicion038.AceptaSimbolos = True
Me.CnEdicion038.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion038.ConvierteAMayusculas = True
Me.CnEdicion038.ConvierteAMinusculas = False
Me.CnEdicion038.EsFechaHoraCreacion = False
Me.CnEdicion038.EsFechaHoraModificacion = False
Me.CnEdicion038.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion038.ColorFondo = System.Drawing.Color.White
Me.CnEdicion038.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion038.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion038.Campo = "codigo_clave"
Me.CnEdicion038.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion038.CampoEnlacesLookup2 = Nothing
Me.CnEdicion038.CampoEnlacesLookup3 = Nothing
Me.CnEdicion038.EdicionEnGrid = False
Me.CnEdicion038.TituloParaGrid = Nothing
Me.CnEdicion038.AnchoColumnaGrid = 0
Me.CnEdicion038.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion038.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion038.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion038.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion038.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion038.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion038.EnCreacionSoloLectura = False
Me.CnEdicion038.EnCreacionOculto = False
Me.CnEdicion038.SiempreSoloLectura = False
Me.CnEdicion038.SiempreOculto = False
Me.CnEdicion038.EnlacesLookup1 = 31176
Me.CnEdicion038.EnlacesLookup2 = 0
Me.CnEdicion038.EnlacesLookup3 = 0
Me.CnEdicion038.EnModificacionSoloLectura = False
Me.CnEdicion038.EnModificacionOculto = False
Me.CnEdicion038.Fuente = Nothing
Me.CnEdicion038.HayMascaraEspecial = False
Me.CnEdicion038.HayValorDefecto = False
Me.CnEdicion038.NumeroParametroValorDefecto = 0
Me.CnEdicion038.ValorDefecto = ""
Me.CnEdicion038.HayValorFijo = False
Me.CnEdicion038.NumeroParametroValorFijo = 0
Me.CnEdicion038.ValorFijo = ""
Me.CnEdicion038.HayValorFijoCreacion = False
Me.CnEdicion038.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion038.ValorFijoCreacion = ""
Me.CnEdicion038.Location = New System.Drawing.Point(118,117)
Me.CnEdicion038.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion038.MascaraEspecial = ""
Me.CnEdicion038.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion038.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion038.MaximoNumero = 999999999999999.0R
Me.CnEdicion038.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion038.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion038.MinimoNumero = -999999999999999.0R
Me.CnEdicion038.Name = "CnEdicion038"
Me.CnEdicion038.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion038.TabIndex = 9999
Me.CnEdicion038.Tabla = "cabeceras_salida"
'
'CmdGrid038
'
Me.CmdGrid038.Image = CType(Resources.GetObject("CmdGrid038.Image"), System.Drawing.Image)
Me.CmdGrid038.Location = New System.Drawing.Point(135,117)
Me.CmdGrid038.Name = "CmdGrid038"
Me.CmdGrid038.Size = New System.Drawing.Size(24,22)
Me.CmdGrid038.UseVisualStyleBackColor = True
Me.CmdGrid038.Tabindex = 9999
'
'TxtLookup0381
'
Me.TxtLookup0381.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0381.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0381.Location = New System.Drawing.Point(169,120)
Me.TxtLookup0381.Name = "TxtLookup0381"
Me.TxtLookup0381.ReadOnly = True
Me.TxtLookup0381.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0381.Tabindex = 9999
'
'Lbl039
'
Me.Lbl039.AutoSize = True
Me.Lbl039.Location = New System.Drawing.Point(35,140)
Me.Lbl039.Name = "Lbl039"
Me.Lbl039.Size = New System.Drawing.Size(41, 13)
Me.Lbl039.Tabindex = 9999
Me.Lbl039.Text = "Código cliente:"
'
'TxtDatos039
'
Me.TxtDatos039.Location = New System.Drawing.Point(114,138)
Me.TxtDatos039.Name = "TxtDatos039"
Me.TxtDatos039.ReadOnly = True
Me.TxtDatos039.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos039.Tabindex = 9999
'
'CnEdicion039
'
Me.CnEdicion039.AceptaEspacios = True
Me.CnEdicion039.AceptaMayusculas = True
Me.CnEdicion039.AceptaMayusculasAcentuadas = True
Me.CnEdicion039.AceptaMinusculas = True
Me.CnEdicion039.AceptaMinusculasAcentuadas = True
Me.CnEdicion039.AceptaNumeros = True
Me.CnEdicion039.AceptaSimbolos = False
Me.CnEdicion039.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion039.ConvierteAMayusculas = False
Me.CnEdicion039.ConvierteAMinusculas = False
Me.CnEdicion039.EsFechaHoraCreacion = False
Me.CnEdicion039.EsFechaHoraModificacion = False
Me.CnEdicion039.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion039.ColorFondo = System.Drawing.Color.White
Me.CnEdicion039.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion039.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion039.Campo = "codigo_cliente"
Me.CnEdicion039.CampoEnlacesLookup1 = "nombre_cliente"
Me.CnEdicion039.CampoEnlacesLookup2 = Nothing
Me.CnEdicion039.CampoEnlacesLookup3 = Nothing
Me.CnEdicion039.EdicionEnGrid = False
Me.CnEdicion039.TituloParaGrid = Nothing
Me.CnEdicion039.AnchoColumnaGrid = 0
Me.CnEdicion039.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion039.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion039.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion039.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion039.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion039.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion039.EnCreacionSoloLectura = False
Me.CnEdicion039.EnCreacionOculto = False
Me.CnEdicion039.SiempreSoloLectura = False
Me.CnEdicion039.SiempreOculto = False
Me.CnEdicion039.EnlacesLookup1 = 32959
Me.CnEdicion039.EnlacesLookup2 = 0
Me.CnEdicion039.EnlacesLookup3 = 0
Me.CnEdicion039.EnModificacionSoloLectura = False
Me.CnEdicion039.EnModificacionOculto = False
Me.CnEdicion039.Fuente = Nothing
Me.CnEdicion039.HayMascaraEspecial = False
Me.CnEdicion039.HayValorDefecto = False
Me.CnEdicion039.NumeroParametroValorDefecto = 0
Me.CnEdicion039.ValorDefecto = ""
Me.CnEdicion039.HayValorFijo = False
Me.CnEdicion039.NumeroParametroValorFijo = 0
Me.CnEdicion039.ValorFijo = ""
Me.CnEdicion039.HayValorFijoCreacion = False
Me.CnEdicion039.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion039.ValorFijoCreacion = ""
Me.CnEdicion039.Location = New System.Drawing.Point(118,138)
Me.CnEdicion039.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion039.MascaraEspecial = ""
Me.CnEdicion039.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion039.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion039.MaximoNumero = 999999999999999.0R
Me.CnEdicion039.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion039.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion039.MinimoNumero = -999999999999999.0R
Me.CnEdicion039.Name = "CnEdicion039"
Me.CnEdicion039.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion039.TabIndex = 9999
Me.CnEdicion039.Tabla = "cabeceras_salida"
'
'CmdGrid039
'
Me.CmdGrid039.Image = CType(Resources.GetObject("CmdGrid039.Image"), System.Drawing.Image)
Me.CmdGrid039.Location = New System.Drawing.Point(215,138)
Me.CmdGrid039.Name = "CmdGrid039"
Me.CmdGrid039.Size = New System.Drawing.Size(24,22)
Me.CmdGrid039.UseVisualStyleBackColor = True
Me.CmdGrid039.Tabindex = 9999
'
'TxtLookup0391
'
Me.TxtLookup0391.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0391.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0391.Location = New System.Drawing.Point(249,141)
Me.TxtLookup0391.Name = "TxtLookup0391"
Me.TxtLookup0391.ReadOnly = True
Me.TxtLookup0391.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0391.Tabindex = 9999
'
'Lbl040
'
Me.Lbl040.AutoSize = True
Me.Lbl040.Location = New System.Drawing.Point(44,161)
Me.Lbl040.Name = "Lbl040"
Me.Lbl040.Size = New System.Drawing.Size(41, 13)
Me.Lbl040.Tabindex = 9999
Me.Lbl040.Text = "Destinatario:"
'
'TxtDatos040
'
Me.TxtDatos040.Location = New System.Drawing.Point(114,159)
Me.TxtDatos040.Name = "TxtDatos040"
Me.TxtDatos040.ReadOnly = True
Me.TxtDatos040.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos040.Tabindex = 9999
'
'CnEdicion040
'
Me.CnEdicion040.AceptaEspacios = True
Me.CnEdicion040.AceptaMayusculas = True
Me.CnEdicion040.AceptaMayusculasAcentuadas = True
Me.CnEdicion040.AceptaMinusculas = True
Me.CnEdicion040.AceptaMinusculasAcentuadas = True
Me.CnEdicion040.AceptaNumeros = True
Me.CnEdicion040.AceptaSimbolos = False
Me.CnEdicion040.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion040.ConvierteAMayusculas = False
Me.CnEdicion040.ConvierteAMinusculas = False
Me.CnEdicion040.EsFechaHoraCreacion = False
Me.CnEdicion040.EsFechaHoraModificacion = False
Me.CnEdicion040.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion040.ColorFondo = System.Drawing.Color.White
Me.CnEdicion040.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion040.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion040.Campo = "destinatario"
Me.CnEdicion040.CampoEnlacesLookup1 = "nombre_dest"
Me.CnEdicion040.CampoEnlacesLookup2 = Nothing
Me.CnEdicion040.CampoEnlacesLookup3 = Nothing
Me.CnEdicion040.EdicionEnGrid = False
Me.CnEdicion040.TituloParaGrid = Nothing
Me.CnEdicion040.AnchoColumnaGrid = 0
Me.CnEdicion040.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion040.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion040.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion040.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion040.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion040.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion040.EnCreacionSoloLectura = False
Me.CnEdicion040.EnCreacionOculto = False
Me.CnEdicion040.SiempreSoloLectura = False
Me.CnEdicion040.SiempreOculto = False
Me.CnEdicion040.EnlacesLookup1 = 32960
Me.CnEdicion040.EnlacesLookup2 = 0
Me.CnEdicion040.EnlacesLookup3 = 0
Me.CnEdicion040.EnModificacionSoloLectura = False
Me.CnEdicion040.EnModificacionOculto = False
Me.CnEdicion040.Fuente = Nothing
Me.CnEdicion040.HayMascaraEspecial = False
Me.CnEdicion040.HayValorDefecto = False
Me.CnEdicion040.NumeroParametroValorDefecto = 0
Me.CnEdicion040.ValorDefecto = ""
Me.CnEdicion040.HayValorFijo = False
Me.CnEdicion040.NumeroParametroValorFijo = 0
Me.CnEdicion040.ValorFijo = ""
Me.CnEdicion040.HayValorFijoCreacion = False
Me.CnEdicion040.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion040.ValorFijoCreacion = ""
Me.CnEdicion040.Location = New System.Drawing.Point(118,159)
Me.CnEdicion040.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion040.MascaraEspecial = ""
Me.CnEdicion040.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion040.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion040.MaximoNumero = 999999999999999.0R
Me.CnEdicion040.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion040.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion040.MinimoNumero = -999999999999999.0R
Me.CnEdicion040.Name = "CnEdicion040"
Me.CnEdicion040.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion040.TabIndex = 9999
Me.CnEdicion040.Tabla = "cabeceras_salida"
'
'CmdGrid040
'
Me.CmdGrid040.Image = CType(Resources.GetObject("CmdGrid040.Image"), System.Drawing.Image)
Me.CmdGrid040.Location = New System.Drawing.Point(215,159)
Me.CmdGrid040.Name = "CmdGrid040"
Me.CmdGrid040.Size = New System.Drawing.Size(24,22)
Me.CmdGrid040.UseVisualStyleBackColor = True
Me.CmdGrid040.Tabindex = 9999
'
'TxtLookup0401
'
Me.TxtLookup0401.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0401.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0401.Location = New System.Drawing.Point(249,162)
Me.TxtLookup0401.Name = "TxtLookup0401"
Me.TxtLookup0401.ReadOnly = True
Me.TxtLookup0401.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0401.Tabindex = 9999
'
'Lbl041
'
Me.Lbl041.AutoSize = True
Me.Lbl041.Location = New System.Drawing.Point(0,182)
Me.Lbl041.Name = "Lbl041"
Me.Lbl041.Size = New System.Drawing.Size(41, 13)
Me.Lbl041.Tabindex = 9999
Me.Lbl041.Text = "Nombre transportista:"
'
'TxtDatos041
'
Me.TxtDatos041.Location = New System.Drawing.Point(114,180)
Me.TxtDatos041.Name = "TxtDatos041"
Me.TxtDatos041.ReadOnly = True
Me.TxtDatos041.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos041.Tabindex = 9999
'
'CnEdicion041
'
Me.CnEdicion041.AceptaEspacios = True
Me.CnEdicion041.AceptaMayusculas = True
Me.CnEdicion041.AceptaMayusculasAcentuadas = False
Me.CnEdicion041.AceptaMinusculas = False
Me.CnEdicion041.AceptaMinusculasAcentuadas = False
Me.CnEdicion041.AceptaNumeros = True
Me.CnEdicion041.AceptaSimbolos = True
Me.CnEdicion041.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion041.ConvierteAMayusculas = True
Me.CnEdicion041.ConvierteAMinusculas = False
Me.CnEdicion041.EsFechaHoraCreacion = False
Me.CnEdicion041.EsFechaHoraModificacion = False
Me.CnEdicion041.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion041.ColorFondo = System.Drawing.Color.White
Me.CnEdicion041.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion041.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion041.Campo = "nombre_trans"
Me.CnEdicion041.CampoEnlacesLookup1 = Nothing
Me.CnEdicion041.CampoEnlacesLookup2 = Nothing
Me.CnEdicion041.CampoEnlacesLookup3 = Nothing
Me.CnEdicion041.EdicionEnGrid = False
Me.CnEdicion041.TituloParaGrid = Nothing
Me.CnEdicion041.AnchoColumnaGrid = 0
Me.CnEdicion041.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion041.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion041.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion041.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion041.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion041.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion041.EnCreacionSoloLectura = False
Me.CnEdicion041.EnCreacionOculto = False
Me.CnEdicion041.SiempreSoloLectura = False
Me.CnEdicion041.SiempreOculto = False
Me.CnEdicion041.EnlacesLookup1 = 0
Me.CnEdicion041.EnlacesLookup2 = 0
Me.CnEdicion041.EnlacesLookup3 = 0
Me.CnEdicion041.EnModificacionSoloLectura = False
Me.CnEdicion041.EnModificacionOculto = False
Me.CnEdicion041.Fuente = Nothing
Me.CnEdicion041.HayMascaraEspecial = False
Me.CnEdicion041.HayValorDefecto = False
Me.CnEdicion041.NumeroParametroValorDefecto = 0
Me.CnEdicion041.ValorDefecto = ""
Me.CnEdicion041.HayValorFijo = False
Me.CnEdicion041.NumeroParametroValorFijo = 0
Me.CnEdicion041.ValorFijo = ""
Me.CnEdicion041.HayValorFijoCreacion = False
Me.CnEdicion041.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion041.ValorFijoCreacion = ""
Me.CnEdicion041.Location = New System.Drawing.Point(118,180)
Me.CnEdicion041.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion041.MascaraEspecial = ""
Me.CnEdicion041.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion041.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion041.MaximoNumero = 999999999999999.0R
Me.CnEdicion041.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion041.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion041.MinimoNumero = -999999999999999.0R
Me.CnEdicion041.Name = "CnEdicion041"
Me.CnEdicion041.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion041.TabIndex = 9999
Me.CnEdicion041.Tabla = "cabeceras_salida"
'
'Lbl042
'
Me.Lbl042.AutoSize = True
Me.Lbl042.Location = New System.Drawing.Point(422,182)
Me.Lbl042.Name = "Lbl042"
Me.Lbl042.Size = New System.Drawing.Size(41, 13)
Me.Lbl042.Tabindex = 9999
Me.Lbl042.Text = "Naturane Sn:"
'
'TxtDatos042
'
Me.TxtDatos042.Location = New System.Drawing.Point(494,180)
Me.TxtDatos042.Name = "TxtDatos042"
Me.TxtDatos042.ReadOnly = True
Me.TxtDatos042.Size = New System.Drawing.Size(20, 20)
Me.TxtDatos042.Tabindex = 9999
'
'CnEdicion042
'
Me.CnEdicion042.AceptaEspacios = True
Me.CnEdicion042.AceptaMayusculas = True
Me.CnEdicion042.AceptaMayusculasAcentuadas = False
Me.CnEdicion042.AceptaMinusculas = False
Me.CnEdicion042.AceptaMinusculasAcentuadas = False
Me.CnEdicion042.AceptaNumeros = True
Me.CnEdicion042.AceptaSimbolos = True
Me.CnEdicion042.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion042.ConvierteAMayusculas = True
Me.CnEdicion042.ConvierteAMinusculas = False
Me.CnEdicion042.EsFechaHoraCreacion = False
Me.CnEdicion042.EsFechaHoraModificacion = False
Me.CnEdicion042.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion042.ColorFondo = System.Drawing.Color.White
Me.CnEdicion042.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion042.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion042.Campo = "naturane_sn"
Me.CnEdicion042.CampoEnlacesLookup1 = Nothing
Me.CnEdicion042.CampoEnlacesLookup2 = Nothing
Me.CnEdicion042.CampoEnlacesLookup3 = Nothing
Me.CnEdicion042.EdicionEnGrid = False
Me.CnEdicion042.TituloParaGrid = Nothing
Me.CnEdicion042.AnchoColumnaGrid = 0
Me.CnEdicion042.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion042.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion042.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion042.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion042.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion042.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion042.EnCreacionSoloLectura = False
Me.CnEdicion042.EnCreacionOculto = False
Me.CnEdicion042.SiempreSoloLectura = False
Me.CnEdicion042.SiempreOculto = False
Me.CnEdicion042.EnlacesLookup1 = 0
Me.CnEdicion042.EnlacesLookup2 = 0
Me.CnEdicion042.EnlacesLookup3 = 0
Me.CnEdicion042.EnModificacionSoloLectura = False
Me.CnEdicion042.EnModificacionOculto = False
Me.CnEdicion042.Fuente = Nothing
Me.CnEdicion042.HayMascaraEspecial = False
Me.CnEdicion042.HayValorDefecto = True
Me.CnEdicion042.NumeroParametroValorDefecto = 0
Me.CnEdicion042.ValorDefecto = "N"
Me.CnEdicion042.HayValorFijo = False
Me.CnEdicion042.NumeroParametroValorFijo = 0
Me.CnEdicion042.ValorFijo = ""
Me.CnEdicion042.HayValorFijoCreacion = False
Me.CnEdicion042.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion042.ValorFijoCreacion = ""
Me.CnEdicion042.Location = New System.Drawing.Point(498,180)
Me.CnEdicion042.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion042.MascaraEspecial = ""
Me.CnEdicion042.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion042.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion042.MaximoNumero = 999999999999999.0R
Me.CnEdicion042.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion042.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion042.MinimoNumero = -999999999999999.0R
Me.CnEdicion042.Name = "CnEdicion042"
Me.CnEdicion042.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion042.TabIndex = 9999
Me.CnEdicion042.Tabla = "cabeceras_salida"
'
'Lbl043
'
Me.Lbl043.AutoSize = True
Me.Lbl043.Location = New System.Drawing.Point(59,203)
Me.Lbl043.Name = "Lbl043"
Me.Lbl043.Size = New System.Drawing.Size(41, 13)
Me.Lbl043.Tabindex = 9999
Me.Lbl043.Text = "Matrícula:"
'
'TxtDatos043
'
Me.TxtDatos043.Location = New System.Drawing.Point(114,201)
Me.TxtDatos043.Name = "TxtDatos043"
Me.TxtDatos043.ReadOnly = True
Me.TxtDatos043.Size = New System.Drawing.Size(200, 20)
Me.TxtDatos043.Tabindex = 9999
'
'CnEdicion043
'
Me.CnEdicion043.AceptaEspacios = True
Me.CnEdicion043.AceptaMayusculas = True
Me.CnEdicion043.AceptaMayusculasAcentuadas = False
Me.CnEdicion043.AceptaMinusculas = False
Me.CnEdicion043.AceptaMinusculasAcentuadas = False
Me.CnEdicion043.AceptaNumeros = True
Me.CnEdicion043.AceptaSimbolos = True
Me.CnEdicion043.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion043.ConvierteAMayusculas = True
Me.CnEdicion043.ConvierteAMinusculas = False
Me.CnEdicion043.EsFechaHoraCreacion = False
Me.CnEdicion043.EsFechaHoraModificacion = False
Me.CnEdicion043.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion043.ColorFondo = System.Drawing.Color.White
Me.CnEdicion043.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion043.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion043.Campo = "matricula"
Me.CnEdicion043.CampoEnlacesLookup1 = Nothing
Me.CnEdicion043.CampoEnlacesLookup2 = Nothing
Me.CnEdicion043.CampoEnlacesLookup3 = Nothing
Me.CnEdicion043.EdicionEnGrid = False
Me.CnEdicion043.TituloParaGrid = Nothing
Me.CnEdicion043.AnchoColumnaGrid = 0
Me.CnEdicion043.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion043.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion043.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion043.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion043.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion043.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion043.EnCreacionSoloLectura = False
Me.CnEdicion043.EnCreacionOculto = False
Me.CnEdicion043.SiempreSoloLectura = False
Me.CnEdicion043.SiempreOculto = False
Me.CnEdicion043.EnlacesLookup1 = 0
Me.CnEdicion043.EnlacesLookup2 = 0
Me.CnEdicion043.EnlacesLookup3 = 0
Me.CnEdicion043.EnModificacionSoloLectura = False
Me.CnEdicion043.EnModificacionOculto = False
Me.CnEdicion043.Fuente = Nothing
Me.CnEdicion043.HayMascaraEspecial = False
Me.CnEdicion043.HayValorDefecto = False
Me.CnEdicion043.NumeroParametroValorDefecto = 0
Me.CnEdicion043.ValorDefecto = ""
Me.CnEdicion043.HayValorFijo = False
Me.CnEdicion043.NumeroParametroValorFijo = 0
Me.CnEdicion043.ValorFijo = ""
Me.CnEdicion043.HayValorFijoCreacion = False
Me.CnEdicion043.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion043.ValorFijoCreacion = ""
Me.CnEdicion043.Location = New System.Drawing.Point(118,201)
Me.CnEdicion043.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion043.MascaraEspecial = ""
Me.CnEdicion043.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion043.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion043.MaximoNumero = 999999999999999.0R
Me.CnEdicion043.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion043.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion043.MinimoNumero = -999999999999999.0R
Me.CnEdicion043.Name = "CnEdicion043"
Me.CnEdicion043.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion043.TabIndex = 9999
Me.CnEdicion043.Tabla = "cabeceras_salida"
'
'CmdSalir
'
Me.CmdSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.CmdSalir.Image = CType(resources.GetObject("CmdSalir.Image"), System.Drawing.Image)
Me.CmdSalir.Location = New System.Drawing.Point(1126, 6)
Me.CmdSalir.Name = "CmdSalir"
Me.CmdSalir.Size = New System.Drawing.Size(54, 48)
Me.CmdSalir.TabIndex = 9999
Me.CmdSalir.TabStop = False
Me.CmdSalir.UseVisualStyleBackColor = True
Me.CmdSalir.CausesValidation = False
'
'PanelCentral
'
Me.PanelCentral.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
Or System.Windows.Forms.AnchorStyles.Left) _
Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.PanelCentral.BackColor = System.Drawing.SystemColors.Control
Me.PanelCentral.Controls.Add(Me.TabCabecera)
Me.PanelCentral.Controls.Add(Me.TabGeneral)
Me.PanelCentral.Location = New System.Drawing.Point(0, 227)
Me.PanelCentral.Name = "PanelCentral"
Me.PanelCentral.Size = New System.Drawing.Size(1184, 701)
Me.PanelCentral.TabIndex = 9999
Me.PanelCentral.CausesValidation = False
'
'TabCabecera
'
Me.TabCabecera.Alignment = System.Windows.Forms.TabAlignment.Right
Me.TabCabecera.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.TabCabecera.Controls.Add(Me.TP00)
Me.TabCabecera.Controls.Add(Me.TP01)
Me.TabCabecera.Controls.Add(Me.TP02)
Me.TabCabecera.Controls.Add(Me.TP03)
Me.TabCabecera.Controls.Add(Me.TP04)
Me.TabCabecera.Controls.Add(Me.TP05)
Me.TabCabecera.Controls.Add(Me.TP06)
Me.TabCabecera.Controls.Add(Me.TP07)
Me.TabCabecera.Controls.Add(Me.TP08)
Me.TabCabecera.Controls.Add(Me.TP09)
Me.TabCabecera.ItemSize = New System.Drawing.Size(20, 20) '0, 1
Me.TabCabecera.Location = New System.Drawing.Point(2, 0)
Me.TabCabecera.Margin = New System.Windows.Forms.Padding(0)
Me.TabCabecera.Name = "TabCabecera"
Me.TabCabecera.SelectedIndex = 0
Me.TabCabecera.Size = New System.Drawing.Size(1180, 83)
Me.TabCabecera.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
Me.TabCabecera.TabIndex = 9999
Me.TabCabecera.CausesValidation = False
'
'TP00
'
Me.TP00.Controls.Add(Me.CnEdicion006)
Me.TP00.Controls.Add(Me.TxtDatos006)
Me.TP00.Controls.Add(Me.Lbl006)
Me.TP00.Controls.Add(Me.CnEdicion005)
Me.TP00.Controls.Add(Me.TxtDatos005)
Me.TP00.Controls.Add(Me.Lbl005)
Me.TP00.Controls.Add(Me.CnEdicion004)
Me.TP00.Controls.Add(Me.TxtDatos004)
Me.TP00.Controls.Add(Me.Lbl004)
Me.TP00.Controls.Add(Me.CnEdicion003)
Me.TP00.Controls.Add(Me.TxtDatos003)
Me.TP00.Controls.Add(Me.Lbl003)
Me.TP00.Controls.Add(Me.CnEdicion002)
Me.TP00.Controls.Add(Me.TxtDatos002)
Me.TP00.Controls.Add(Me.Lbl002)
Me.TP00.Controls.Add(Me.CnEdicion001)
Me.TP00.Controls.Add(Me.TxtDatos001)
Me.TP00.Controls.Add(Me.Lbl001)
Me.TP00.Location = New System.Drawing.Point(4, 5)
Me.TP00.Margin = New System.Windows.Forms.Padding(0)
Me.TP00.Name = "TP00"
Me.TP00.Size = New System.Drawing.Size(1172, 69)
Me.TP00.TabIndex = 1
Me.TP00.Text = "0"
Me.TP00.UseVisualStyleBackColor = True
Me.TP00.CausesValidation = False
'
'Lbl001
'
Me.Lbl001.AutoSize = True
Me.Lbl001.Location = New System.Drawing.Point(31,10)
Me.Lbl001.Name = "Lbl001"
Me.Lbl001.Size = New System.Drawing.Size(41, 13)
Me.Lbl001.Tabindex = 9999
Me.Lbl001.Text = "Nombre cliente:"
'
'TxtDatos001
'
Me.TxtDatos001.Location = New System.Drawing.Point(114,8)
Me.TxtDatos001.Name = "TxtDatos001"
Me.TxtDatos001.ReadOnly = True
Me.TxtDatos001.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos001.Tabindex = 9999
'
'CnEdicion001
'
Me.CnEdicion001.AceptaEspacios = True
Me.CnEdicion001.AceptaMayusculas = True
Me.CnEdicion001.AceptaMayusculasAcentuadas = False
Me.CnEdicion001.AceptaMinusculas = False
Me.CnEdicion001.AceptaMinusculasAcentuadas = False
Me.CnEdicion001.AceptaNumeros = True
Me.CnEdicion001.AceptaSimbolos = True
Me.CnEdicion001.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion001.ConvierteAMayusculas = True
Me.CnEdicion001.ConvierteAMinusculas = False
Me.CnEdicion001.EsFechaHoraCreacion = False
Me.CnEdicion001.EsFechaHoraModificacion = False
Me.CnEdicion001.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion001.ColorFondo = System.Drawing.Color.White
Me.CnEdicion001.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion001.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion001.Campo = "nombre_cliente"
Me.CnEdicion001.CampoEnlacesLookup1 = Nothing
Me.CnEdicion001.CampoEnlacesLookup2 = Nothing
Me.CnEdicion001.CampoEnlacesLookup3 = Nothing
Me.CnEdicion001.EdicionEnGrid = False
Me.CnEdicion001.TituloParaGrid = Nothing
Me.CnEdicion001.AnchoColumnaGrid = 0
Me.CnEdicion001.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion001.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion001.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion001.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion001.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion001.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion001.EnCreacionSoloLectura = False
Me.CnEdicion001.EnCreacionOculto = False
Me.CnEdicion001.SiempreSoloLectura = False
Me.CnEdicion001.SiempreOculto = False
Me.CnEdicion001.EnlacesLookup1 = 0
Me.CnEdicion001.EnlacesLookup2 = 0
Me.CnEdicion001.EnlacesLookup3 = 0
Me.CnEdicion001.EnModificacionSoloLectura = False
Me.CnEdicion001.EnModificacionOculto = False
Me.CnEdicion001.Fuente = Nothing
Me.CnEdicion001.HayMascaraEspecial = False
Me.CnEdicion001.HayValorDefecto = False
Me.CnEdicion001.NumeroParametroValorDefecto = 0
Me.CnEdicion001.ValorDefecto = ""
Me.CnEdicion001.HayValorFijo = False
Me.CnEdicion001.NumeroParametroValorFijo = 0
Me.CnEdicion001.ValorFijo = ""
Me.CnEdicion001.HayValorFijoCreacion = False
Me.CnEdicion001.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion001.ValorFijoCreacion = ""
Me.CnEdicion001.Location = New System.Drawing.Point(118,8)
Me.CnEdicion001.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion001.MascaraEspecial = ""
Me.CnEdicion001.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion001.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion001.MaximoNumero = 999999999999999.0R
Me.CnEdicion001.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion001.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion001.MinimoNumero = -999999999999999.0R
Me.CnEdicion001.Name = "CnEdicion001"
Me.CnEdicion001.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion001.TabIndex = 9999
Me.CnEdicion001.Tabla = "cabeceras_salida"
'
'Lbl002
'
Me.Lbl002.AutoSize = True
Me.Lbl002.Location = New System.Drawing.Point(433,10)
Me.Lbl002.Name = "Lbl002"
Me.Lbl002.Size = New System.Drawing.Size(41, 13)
Me.Lbl002.Tabindex = 9999
Me.Lbl002.Text = "Nif Cliente:"
'
'TxtDatos002
'
Me.TxtDatos002.Location = New System.Drawing.Point(494,8)
Me.TxtDatos002.Name = "TxtDatos002"
Me.TxtDatos002.ReadOnly = True
Me.TxtDatos002.Size = New System.Drawing.Size(144, 20)
Me.TxtDatos002.Tabindex = 9999
'
'CnEdicion002
'
Me.CnEdicion002.AceptaEspacios = True
Me.CnEdicion002.AceptaMayusculas = True
Me.CnEdicion002.AceptaMayusculasAcentuadas = False
Me.CnEdicion002.AceptaMinusculas = False
Me.CnEdicion002.AceptaMinusculasAcentuadas = False
Me.CnEdicion002.AceptaNumeros = True
Me.CnEdicion002.AceptaSimbolos = True
Me.CnEdicion002.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion002.ConvierteAMayusculas = True
Me.CnEdicion002.ConvierteAMinusculas = False
Me.CnEdicion002.EsFechaHoraCreacion = False
Me.CnEdicion002.EsFechaHoraModificacion = False
Me.CnEdicion002.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion002.ColorFondo = System.Drawing.Color.White
Me.CnEdicion002.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion002.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion002.Campo = "nif_cliente"
Me.CnEdicion002.CampoEnlacesLookup1 = Nothing
Me.CnEdicion002.CampoEnlacesLookup2 = Nothing
Me.CnEdicion002.CampoEnlacesLookup3 = Nothing
Me.CnEdicion002.EdicionEnGrid = False
Me.CnEdicion002.TituloParaGrid = Nothing
Me.CnEdicion002.AnchoColumnaGrid = 0
Me.CnEdicion002.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion002.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion002.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion002.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion002.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion002.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion002.EnCreacionSoloLectura = False
Me.CnEdicion002.EnCreacionOculto = False
Me.CnEdicion002.SiempreSoloLectura = False
Me.CnEdicion002.SiempreOculto = False
Me.CnEdicion002.EnlacesLookup1 = 0
Me.CnEdicion002.EnlacesLookup2 = 0
Me.CnEdicion002.EnlacesLookup3 = 0
Me.CnEdicion002.EnModificacionSoloLectura = False
Me.CnEdicion002.EnModificacionOculto = False
Me.CnEdicion002.Fuente = Nothing
Me.CnEdicion002.HayMascaraEspecial = False
Me.CnEdicion002.HayValorDefecto = False
Me.CnEdicion002.NumeroParametroValorDefecto = 0
Me.CnEdicion002.ValorDefecto = ""
Me.CnEdicion002.HayValorFijo = False
Me.CnEdicion002.NumeroParametroValorFijo = 0
Me.CnEdicion002.ValorFijo = ""
Me.CnEdicion002.HayValorFijoCreacion = False
Me.CnEdicion002.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion002.ValorFijoCreacion = ""
Me.CnEdicion002.Location = New System.Drawing.Point(498,8)
Me.CnEdicion002.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion002.MascaraEspecial = ""
Me.CnEdicion002.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion002.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion002.MaximoNumero = 999999999999999.0R
Me.CnEdicion002.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion002.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion002.MinimoNumero = -999999999999999.0R
Me.CnEdicion002.Name = "CnEdicion002"
Me.CnEdicion002.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion002.TabIndex = 9999
Me.CnEdicion002.Tabla = "cabeceras_salida"
'
'Lbl003
'
Me.Lbl003.AutoSize = True
Me.Lbl003.Location = New System.Drawing.Point(62,31)
Me.Lbl003.Name = "Lbl003"
Me.Lbl003.Size = New System.Drawing.Size(41, 13)
Me.Lbl003.Tabindex = 9999
Me.Lbl003.Text = "Domicilio:"
'
'TxtDatos003
'
Me.TxtDatos003.Location = New System.Drawing.Point(114,29)
Me.TxtDatos003.Name = "TxtDatos003"
Me.TxtDatos003.ReadOnly = True
Me.TxtDatos003.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos003.Tabindex = 9999
'
'CnEdicion003
'
Me.CnEdicion003.AceptaEspacios = True
Me.CnEdicion003.AceptaMayusculas = True
Me.CnEdicion003.AceptaMayusculasAcentuadas = False
Me.CnEdicion003.AceptaMinusculas = False
Me.CnEdicion003.AceptaMinusculasAcentuadas = False
Me.CnEdicion003.AceptaNumeros = True
Me.CnEdicion003.AceptaSimbolos = True
Me.CnEdicion003.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion003.ConvierteAMayusculas = True
Me.CnEdicion003.ConvierteAMinusculas = False
Me.CnEdicion003.EsFechaHoraCreacion = False
Me.CnEdicion003.EsFechaHoraModificacion = False
Me.CnEdicion003.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion003.ColorFondo = System.Drawing.Color.White
Me.CnEdicion003.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion003.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion003.Campo = "domicilio"
Me.CnEdicion003.CampoEnlacesLookup1 = Nothing
Me.CnEdicion003.CampoEnlacesLookup2 = Nothing
Me.CnEdicion003.CampoEnlacesLookup3 = Nothing
Me.CnEdicion003.EdicionEnGrid = False
Me.CnEdicion003.TituloParaGrid = Nothing
Me.CnEdicion003.AnchoColumnaGrid = 0
Me.CnEdicion003.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion003.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion003.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion003.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion003.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion003.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion003.EnCreacionSoloLectura = False
Me.CnEdicion003.EnCreacionOculto = False
Me.CnEdicion003.SiempreSoloLectura = False
Me.CnEdicion003.SiempreOculto = False
Me.CnEdicion003.EnlacesLookup1 = 0
Me.CnEdicion003.EnlacesLookup2 = 0
Me.CnEdicion003.EnlacesLookup3 = 0
Me.CnEdicion003.EnModificacionSoloLectura = False
Me.CnEdicion003.EnModificacionOculto = False
Me.CnEdicion003.Fuente = Nothing
Me.CnEdicion003.HayMascaraEspecial = False
Me.CnEdicion003.HayValorDefecto = False
Me.CnEdicion003.NumeroParametroValorDefecto = 0
Me.CnEdicion003.ValorDefecto = ""
Me.CnEdicion003.HayValorFijo = False
Me.CnEdicion003.NumeroParametroValorFijo = 0
Me.CnEdicion003.ValorFijo = ""
Me.CnEdicion003.HayValorFijoCreacion = False
Me.CnEdicion003.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion003.ValorFijoCreacion = ""
Me.CnEdicion003.Location = New System.Drawing.Point(118,29)
Me.CnEdicion003.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion003.MascaraEspecial = ""
Me.CnEdicion003.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion003.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion003.MaximoNumero = 999999999999999.0R
Me.CnEdicion003.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion003.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion003.MinimoNumero = -999999999999999.0R
Me.CnEdicion003.Name = "CnEdicion003"
Me.CnEdicion003.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion003.TabIndex = 9999
Me.CnEdicion003.Tabla = "cabeceras_salida"
'
'Lbl004
'
Me.Lbl004.AutoSize = True
Me.Lbl004.Location = New System.Drawing.Point(425,31)
Me.Lbl004.Name = "Lbl004"
Me.Lbl004.Size = New System.Drawing.Size(41, 13)
Me.Lbl004.Tabindex = 9999
Me.Lbl004.Text = "Domicilio (2):"
'
'TxtDatos004
'
Me.TxtDatos004.Location = New System.Drawing.Point(494,29)
Me.TxtDatos004.Name = "TxtDatos004"
Me.TxtDatos004.ReadOnly = True
Me.TxtDatos004.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos004.Tabindex = 9999
'
'CnEdicion004
'
Me.CnEdicion004.AceptaEspacios = True
Me.CnEdicion004.AceptaMayusculas = True
Me.CnEdicion004.AceptaMayusculasAcentuadas = False
Me.CnEdicion004.AceptaMinusculas = False
Me.CnEdicion004.AceptaMinusculasAcentuadas = False
Me.CnEdicion004.AceptaNumeros = True
Me.CnEdicion004.AceptaSimbolos = True
Me.CnEdicion004.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion004.ConvierteAMayusculas = True
Me.CnEdicion004.ConvierteAMinusculas = False
Me.CnEdicion004.EsFechaHoraCreacion = False
Me.CnEdicion004.EsFechaHoraModificacion = False
Me.CnEdicion004.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion004.ColorFondo = System.Drawing.Color.White
Me.CnEdicion004.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion004.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion004.Campo = "domicilio_2"
Me.CnEdicion004.CampoEnlacesLookup1 = Nothing
Me.CnEdicion004.CampoEnlacesLookup2 = Nothing
Me.CnEdicion004.CampoEnlacesLookup3 = Nothing
Me.CnEdicion004.EdicionEnGrid = False
Me.CnEdicion004.TituloParaGrid = Nothing
Me.CnEdicion004.AnchoColumnaGrid = 0
Me.CnEdicion004.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion004.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion004.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion004.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion004.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion004.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion004.EnCreacionSoloLectura = False
Me.CnEdicion004.EnCreacionOculto = False
Me.CnEdicion004.SiempreSoloLectura = False
Me.CnEdicion004.SiempreOculto = False
Me.CnEdicion004.EnlacesLookup1 = 0
Me.CnEdicion004.EnlacesLookup2 = 0
Me.CnEdicion004.EnlacesLookup3 = 0
Me.CnEdicion004.EnModificacionSoloLectura = False
Me.CnEdicion004.EnModificacionOculto = False
Me.CnEdicion004.Fuente = Nothing
Me.CnEdicion004.HayMascaraEspecial = False
Me.CnEdicion004.HayValorDefecto = False
Me.CnEdicion004.NumeroParametroValorDefecto = 0
Me.CnEdicion004.ValorDefecto = ""
Me.CnEdicion004.HayValorFijo = False
Me.CnEdicion004.NumeroParametroValorFijo = 0
Me.CnEdicion004.ValorFijo = ""
Me.CnEdicion004.HayValorFijoCreacion = False
Me.CnEdicion004.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion004.ValorFijoCreacion = ""
Me.CnEdicion004.Location = New System.Drawing.Point(498,29)
Me.CnEdicion004.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion004.MascaraEspecial = ""
Me.CnEdicion004.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion004.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion004.MaximoNumero = 999999999999999.0R
Me.CnEdicion004.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion004.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion004.MinimoNumero = -999999999999999.0R
Me.CnEdicion004.Name = "CnEdicion004"
Me.CnEdicion004.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion004.TabIndex = 9999
Me.CnEdicion004.Tabla = "cabeceras_salida"
'
'Lbl005
'
Me.Lbl005.AutoSize = True
Me.Lbl005.Location = New System.Drawing.Point(37,52)
Me.Lbl005.Name = "Lbl005"
Me.Lbl005.Size = New System.Drawing.Size(41, 13)
Me.Lbl005.Tabindex = 9999
Me.Lbl005.Text = "Código postal:"
'
'TxtDatos005
'
Me.TxtDatos005.Location = New System.Drawing.Point(114,50)
Me.TxtDatos005.Name = "TxtDatos005"
Me.TxtDatos005.ReadOnly = True
Me.TxtDatos005.Size = New System.Drawing.Size(64, 20)
Me.TxtDatos005.Tabindex = 9999
'
'CnEdicion005
'
Me.CnEdicion005.AceptaEspacios = True
Me.CnEdicion005.AceptaMayusculas = True
Me.CnEdicion005.AceptaMayusculasAcentuadas = False
Me.CnEdicion005.AceptaMinusculas = False
Me.CnEdicion005.AceptaMinusculasAcentuadas = False
Me.CnEdicion005.AceptaNumeros = True
Me.CnEdicion005.AceptaSimbolos = True
Me.CnEdicion005.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion005.ConvierteAMayusculas = True
Me.CnEdicion005.ConvierteAMinusculas = False
Me.CnEdicion005.EsFechaHoraCreacion = False
Me.CnEdicion005.EsFechaHoraModificacion = False
Me.CnEdicion005.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion005.ColorFondo = System.Drawing.Color.White
Me.CnEdicion005.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion005.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion005.Campo = "codigo_postal"
Me.CnEdicion005.CampoEnlacesLookup1 = Nothing
Me.CnEdicion005.CampoEnlacesLookup2 = Nothing
Me.CnEdicion005.CampoEnlacesLookup3 = Nothing
Me.CnEdicion005.EdicionEnGrid = False
Me.CnEdicion005.TituloParaGrid = Nothing
Me.CnEdicion005.AnchoColumnaGrid = 0
Me.CnEdicion005.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion005.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion005.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion005.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion005.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion005.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion005.EnCreacionSoloLectura = False
Me.CnEdicion005.EnCreacionOculto = False
Me.CnEdicion005.SiempreSoloLectura = False
Me.CnEdicion005.SiempreOculto = False
Me.CnEdicion005.EnlacesLookup1 = 0
Me.CnEdicion005.EnlacesLookup2 = 0
Me.CnEdicion005.EnlacesLookup3 = 0
Me.CnEdicion005.EnModificacionSoloLectura = False
Me.CnEdicion005.EnModificacionOculto = False
Me.CnEdicion005.Fuente = Nothing
Me.CnEdicion005.HayMascaraEspecial = False
Me.CnEdicion005.HayValorDefecto = False
Me.CnEdicion005.NumeroParametroValorDefecto = 0
Me.CnEdicion005.ValorDefecto = ""
Me.CnEdicion005.HayValorFijo = False
Me.CnEdicion005.NumeroParametroValorFijo = 0
Me.CnEdicion005.ValorFijo = ""
Me.CnEdicion005.HayValorFijoCreacion = False
Me.CnEdicion005.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion005.ValorFijoCreacion = ""
Me.CnEdicion005.Location = New System.Drawing.Point(118,50)
Me.CnEdicion005.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion005.MascaraEspecial = ""
Me.CnEdicion005.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion005.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion005.MaximoNumero = 999999999999999.0R
Me.CnEdicion005.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion005.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion005.MinimoNumero = -999999999999999.0R
Me.CnEdicion005.Name = "CnEdicion005"
Me.CnEdicion005.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion005.TabIndex = 9999
Me.CnEdicion005.Tabla = "cabeceras_salida"
'
'Lbl006
'
Me.Lbl006.AutoSize = True
Me.Lbl006.Location = New System.Drawing.Point(437,52)
Me.Lbl006.Name = "Lbl006"
Me.Lbl006.Size = New System.Drawing.Size(41, 13)
Me.Lbl006.Tabindex = 9999
Me.Lbl006.Text = "Población:"
'
'TxtDatos006
'
Me.TxtDatos006.Location = New System.Drawing.Point(494,50)
Me.TxtDatos006.Name = "TxtDatos006"
Me.TxtDatos006.ReadOnly = True
Me.TxtDatos006.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos006.Tabindex = 9999
'
'CnEdicion006
'
Me.CnEdicion006.AceptaEspacios = True
Me.CnEdicion006.AceptaMayusculas = True
Me.CnEdicion006.AceptaMayusculasAcentuadas = False
Me.CnEdicion006.AceptaMinusculas = False
Me.CnEdicion006.AceptaMinusculasAcentuadas = False
Me.CnEdicion006.AceptaNumeros = True
Me.CnEdicion006.AceptaSimbolos = True
Me.CnEdicion006.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion006.ConvierteAMayusculas = True
Me.CnEdicion006.ConvierteAMinusculas = False
Me.CnEdicion006.EsFechaHoraCreacion = False
Me.CnEdicion006.EsFechaHoraModificacion = False
Me.CnEdicion006.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion006.ColorFondo = System.Drawing.Color.White
Me.CnEdicion006.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion006.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion006.Campo = "poblacion"
Me.CnEdicion006.CampoEnlacesLookup1 = Nothing
Me.CnEdicion006.CampoEnlacesLookup2 = Nothing
Me.CnEdicion006.CampoEnlacesLookup3 = Nothing
Me.CnEdicion006.EdicionEnGrid = False
Me.CnEdicion006.TituloParaGrid = Nothing
Me.CnEdicion006.AnchoColumnaGrid = 0
Me.CnEdicion006.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion006.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion006.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion006.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion006.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion006.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion006.EnCreacionSoloLectura = False
Me.CnEdicion006.EnCreacionOculto = False
Me.CnEdicion006.SiempreSoloLectura = False
Me.CnEdicion006.SiempreOculto = False
Me.CnEdicion006.EnlacesLookup1 = 0
Me.CnEdicion006.EnlacesLookup2 = 0
Me.CnEdicion006.EnlacesLookup3 = 0
Me.CnEdicion006.EnModificacionSoloLectura = False
Me.CnEdicion006.EnModificacionOculto = False
Me.CnEdicion006.Fuente = Nothing
Me.CnEdicion006.HayMascaraEspecial = False
Me.CnEdicion006.HayValorDefecto = False
Me.CnEdicion006.NumeroParametroValorDefecto = 0
Me.CnEdicion006.ValorDefecto = ""
Me.CnEdicion006.HayValorFijo = False
Me.CnEdicion006.NumeroParametroValorFijo = 0
Me.CnEdicion006.ValorFijo = ""
Me.CnEdicion006.HayValorFijoCreacion = False
Me.CnEdicion006.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion006.ValorFijoCreacion = ""
Me.CnEdicion006.Location = New System.Drawing.Point(498,50)
Me.CnEdicion006.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion006.MascaraEspecial = ""
Me.CnEdicion006.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion006.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion006.MaximoNumero = 999999999999999.0R
Me.CnEdicion006.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion006.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion006.MinimoNumero = -999999999999999.0R
Me.CnEdicion006.Name = "CnEdicion006"
Me.CnEdicion006.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion006.TabIndex = 9999
Me.CnEdicion006.Tabla = "cabeceras_salida"
Me.TP00.Text = "cabeceras_salida"
'
'TP01
'
Me.TP01.Controls.Add(Me.TxtDuplicado0441)
Me.TP01.Controls.Add(Me.LblDuplicado0441)
Me.TP01.Controls.Add(Me.CnTabla02)
Me.TP01.Location = New System.Drawing.Point(4, 5)
Me.TP01.Name = "TP01"
Me.TP01.Size = New System.Drawing.Size(1172, 69)
Me.TP01.TabIndex = 9
Me.TP01.Text = "1"
Me.TP01.UseVisualStyleBackColor = True
Me.TP01.CausesValidation = False
'
'CnTabla02
'
Me.CnTabla02.Autosize = True
Me.CnTabla02.BackColor = System.Drawing.SystemColors.Control
Me.CnTabla02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.CnTabla02.CargaAlInicio = True
Me.CnTabla02.CausesValidation = False
Me.CnTabla02.EnlaceATablaPadre = 31189
Me.CnTabla02.Estado = CnTabla.CnTabla.EstadoCnTabla.Inactivo
Me.CnTabla02.Formato = CnTabla.CnTabla.FormatoCnTabla.TablaSecundariaSuperior
Me.CnTabla02.HayBorrado = True
Me.CnTabla02.HayCreacion = True
Me.CnTabla02.HayDesplegar = True
Me.CnTabla02.HayModificacion = True
Me.CnTabla02.HaySeleccion = True
Me.CnTabla02.HaySiguienteAnterior = True
Me.CnTabla02.Location = New System.Drawing.Point(116,0)
Me.CnTabla02.Margin = New System.Windows.Forms.Padding(0)
Me.CnTabla02.Name = "CnTabla02"
Me.CnTabla02.Size = New System.Drawing.Size(550, 48)
Me.CnTabla02.TabIndex = 10000
Me.CnTabla02.TabStop = False
Me.CnTabla02.Tabla = "lineas_salida"
'
'LblDuplicado0441
'
Me.LblDuplicado0441.AutoSize = True
Me.LblDuplicado0441.Location = New System.Drawing.Point(75,52)
Me.LblDuplicado0441.Name = "LblDuplicado0441"
Me.LblDuplicado0441.Size = New System.Drawing.Size(41, 13)
Me.LblDuplicado0441.Tabindex = 9999
Me.LblDuplicado0441.Text = "Línea"
'
'TxtDuplicado0441
Me.TxtDuplicado0441.BackColor = System.Drawing.Color.Beige
Me.TxtDuplicado0441.TabStop = true
Me.TxtDuplicado0441.TabStop = true
Me.TxtDuplicado0441.Location = New System.Drawing.Point(114,50)
Me.TxtDuplicado0441.Name = "TxtDuplicado0441"
Me.TxtDuplicado0441.ReadOnly = True
Me.TxtDuplicado0441.Size = New System.Drawing.Size(100, 20)
Me.TxtDuplicado0441.Tabindex = 9999
Me.TP01.Text = "lineas_salida"
'
'TP02
'
Me.TP02.Location = New System.Drawing.Point(4, 5)
Me.TP02.Name = "TP02"
Me.TP02.Size = New System.Drawing.Size(1172, 69)
Me.TP02.TabIndex = 2
Me.TP02.Text = "2"
Me.TP02.UseVisualStyleBackColor = True
Me.TP02.CausesValidation = False
'
'TP03
'
Me.TP03.Location = New System.Drawing.Point(4, 5)
Me.TP03.Name = "TP03"
Me.TP03.Size = New System.Drawing.Size(1172, 69)
Me.TP03.TabIndex = 10
Me.TP03.Text = "3"
Me.TP03.UseVisualStyleBackColor = True
Me.TP03.CausesValidation = False
'
'TP04
'
Me.TP04.Location = New System.Drawing.Point(4, 5)
Me.TP04.Name = "TP04"
Me.TP04.Size = New System.Drawing.Size(1172, 69)
Me.TP04.TabIndex = 3
Me.TP04.Text = "4"
Me.TP04.UseVisualStyleBackColor = True
Me.TP04.CausesValidation = False
'
'TP05
'
Me.TP05.Location = New System.Drawing.Point(4, 5)
Me.TP05.Name = "TP05"
Me.TP05.Size = New System.Drawing.Size(1172, 69)
Me.TP05.TabIndex = 4
Me.TP05.Text = "5"
Me.TP05.UseVisualStyleBackColor = True
Me.TP05.CausesValidation = False
'
'TP06
'
Me.TP06.Location = New System.Drawing.Point(4, 5)
Me.TP06.Name = "TP06"
Me.TP06.Size = New System.Drawing.Size(1172, 69)
Me.TP06.TabIndex = 5
Me.TP06.Text = "6"
Me.TP06.UseVisualStyleBackColor = True
Me.TP06.CausesValidation = False
'
'TP07
'
Me.TP07.Location = New System.Drawing.Point(4, 5)
Me.TP07.Name = "TP07"
Me.TP07.Size = New System.Drawing.Size(1172, 69)
Me.TP07.TabIndex = 6
Me.TP07.Text = "7"
Me.TP07.UseVisualStyleBackColor = True
Me.TP07.CausesValidation = False
'
'TP08
'
Me.TP08.Location = New System.Drawing.Point(4, 5)
Me.TP08.Name = "TP08"
Me.TP08.Size = New System.Drawing.Size(1172, 69)
Me.TP08.TabIndex = 7
Me.TP08.Text = "8"
Me.TP08.UseVisualStyleBackColor = True
Me.TP08.CausesValidation = False
'
'TP09
'
Me.TP09.Location = New System.Drawing.Point(4, 5)
Me.TP09.Name = "TP09"
Me.TP09.Size = New System.Drawing.Size(1172, 69)
Me.TP09.TabIndex = 8
Me.TP09.Text = "9"
Me.TP09.UseVisualStyleBackColor = True
Me.TP09.CausesValidation = False
'
'TabGeneral
'
Me.TabGeneral.Alignment = System.Windows.Forms.TabAlignment.Bottom
Me.TabGeneral.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
Or System.Windows.Forms.AnchorStyles.Left) _
Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
Me.TabGeneral.CausesValidation = False
Me.TabGeneral.Controls.Add(Me.TabPage00)
Me.TabGeneral.Controls.Add(Me.TabPage01)
Me.TabGeneral.Controls.Add(Me.TabPage02)
Me.TabGeneral.Controls.Add(Me.TabPage03)
Me.TabGeneral.Controls.Add(Me.TabPage04)
Me.TabGeneral.Controls.Add(Me.TabPage05)
Me.TabGeneral.Controls.Add(Me.TabPage06)
Me.TabGeneral.Controls.Add(Me.TabPage07)
Me.TabGeneral.Controls.Add(Me.TabPage08)
Me.TabGeneral.Controls.Add(Me.TabPage09)
Me.TabGeneral.Location = New System.Drawing.Point(2, 85)
Me.TabGeneral.Margin = New System.Windows.Forms.Padding(0)
Me.TabGeneral.Name = "TabGeneral"
Me.TabGeneral.SelectedIndex = 0
Me.TabGeneral.Size = New System.Drawing.Size(1184, 614)
Me.TabGeneral.TabIndex = 0
Me.TabGeneral.CausesValidation = False
'
'TabPage00
'
Me.TabPage00.Controls.Add(Me.CnEdicion031)
Me.TabPage00.Controls.Add(Me.TxtDatos031)
Me.TabPage00.Controls.Add(Me.Lbl031)
Me.TabPage00.Controls.Add(Me.CnEdicion030)
Me.TabPage00.Controls.Add(Me.TxtDatos030)
Me.TabPage00.Controls.Add(Me.Lbl030)
Me.TabPage00.Controls.Add(Me.CnEdicion029)
Me.TabPage00.Controls.Add(Me.TxtDatos029)
Me.TabPage00.Controls.Add(Me.Lbl029)
Me.TabPage00.Controls.Add(Me.CnEdicion028)
Me.TabPage00.Controls.Add(Me.TxtDatos028)
Me.TabPage00.Controls.Add(Me.Lbl028)
Me.TabPage00.Controls.Add(Me.CnEdicion027)
Me.TabPage00.Controls.Add(Me.TxtDatos027)
Me.TabPage00.Controls.Add(Me.Lbl027)
Me.TabPage00.Controls.Add(Me.TxtLookup0261)
Me.TabPage00.Controls.Add(Me.CmdGrid026)
Me.TabPage00.Controls.Add(Me.CnEdicion026)
Me.TabPage00.Controls.Add(Me.TxtDatos026)
Me.TabPage00.Controls.Add(Me.Lbl026)
Me.TabPage00.Controls.Add(Me.CnEdicion025)
Me.TabPage00.Controls.Add(Me.TxtDatos025)
Me.TabPage00.Controls.Add(Me.Lbl025)
Me.TabPage00.Controls.Add(Me.TxtLookup0242)
Me.TabPage00.Controls.Add(Me.TxtLookup0241)
Me.TabPage00.Controls.Add(Me.CmdGrid024)
Me.TabPage00.Controls.Add(Me.CnEdicion024)
Me.TabPage00.Controls.Add(Me.TxtDatos024)
Me.TabPage00.Controls.Add(Me.Lbl024)
Me.TabPage00.Controls.Add(Me.CnEdicion023)
Me.TabPage00.Controls.Add(Me.TxtDatos023)
Me.TabPage00.Controls.Add(Me.Lbl023)
Me.TabPage00.Controls.Add(Me.TxtLookup0221)
Me.TabPage00.Controls.Add(Me.CmdGrid022)
Me.TabPage00.Controls.Add(Me.CnEdicion022)
Me.TabPage00.Controls.Add(Me.TxtDatos022)
Me.TabPage00.Controls.Add(Me.Lbl022)
Me.TabPage00.Controls.Add(Me.TxtLookup0211)
Me.TabPage00.Controls.Add(Me.CmdGrid021)
Me.TabPage00.Controls.Add(Me.CnEdicion021)
Me.TabPage00.Controls.Add(Me.TxtDatos021)
Me.TabPage00.Controls.Add(Me.Lbl021)
Me.TabPage00.Controls.Add(Me.CnEdicion020)
Me.TabPage00.Controls.Add(Me.TxtDatos020)
Me.TabPage00.Controls.Add(Me.Lbl020)
Me.TabPage00.Controls.Add(Me.CnEdicion019)
Me.TabPage00.Controls.Add(Me.TxtDatos019)
Me.TabPage00.Controls.Add(Me.Lbl019)
Me.TabPage00.Controls.Add(Me.CnEdicion018)
Me.TabPage00.Controls.Add(Me.TxtDatos018)
Me.TabPage00.Controls.Add(Me.Lbl018)
Me.TabPage00.Controls.Add(Me.CnEdicion017)
Me.TabPage00.Controls.Add(Me.TxtDatos017)
Me.TabPage00.Controls.Add(Me.Lbl017)
Me.TabPage00.Controls.Add(Me.CnEdicion016)
Me.TabPage00.Controls.Add(Me.TxtDatos016)
Me.TabPage00.Controls.Add(Me.Lbl016)
Me.TabPage00.Controls.Add(Me.CnEdicion015)
Me.TabPage00.Controls.Add(Me.TxtDatos015)
Me.TabPage00.Controls.Add(Me.Lbl015)
Me.TabPage00.Controls.Add(Me.CnEdicion014)
Me.TabPage00.Controls.Add(Me.TxtDatos014)
Me.TabPage00.Controls.Add(Me.Lbl014)
Me.TabPage00.Controls.Add(Me.CnEdicion013)
Me.TabPage00.Controls.Add(Me.TxtDatos013)
Me.TabPage00.Controls.Add(Me.Lbl013)
Me.TabPage00.Controls.Add(Me.TxtLookup0121)
Me.TabPage00.Controls.Add(Me.CmdGrid012)
Me.TabPage00.Controls.Add(Me.CnEdicion012)
Me.TabPage00.Controls.Add(Me.TxtDatos012)
Me.TabPage00.Controls.Add(Me.Lbl012)
Me.TabPage00.Controls.Add(Me.CmdCombo011)
Me.TabPage00.Controls.Add(Me.CnEdicion011)
Me.TabPage00.Controls.Add(Me.TxtDatos011)
Me.TabPage00.Controls.Add(Me.Lbl011)
Me.TabPage00.Controls.Add(Me.TxtLookup0101)
Me.TabPage00.Controls.Add(Me.CmdGrid010)
Me.TabPage00.Controls.Add(Me.CnEdicion010)
Me.TabPage00.Controls.Add(Me.TxtDatos010)
Me.TabPage00.Controls.Add(Me.Lbl010)
Me.TabPage00.Controls.Add(Me.TxtLookup0091)
Me.TabPage00.Controls.Add(Me.CmdGrid009)
Me.TabPage00.Controls.Add(Me.CnEdicion009)
Me.TabPage00.Controls.Add(Me.TxtDatos009)
Me.TabPage00.Controls.Add(Me.Lbl009)
Me.TabPage00.Controls.Add(Me.TxtLookup0081)
Me.TabPage00.Controls.Add(Me.CmdGrid008)
Me.TabPage00.Controls.Add(Me.CnEdicion008)
Me.TabPage00.Controls.Add(Me.TxtDatos008)
Me.TabPage00.Controls.Add(Me.Lbl008)
Me.TabPage00.Controls.Add(Me.CnEdicion007)
Me.TabPage00.Controls.Add(Me.TxtDatos007)
Me.TabPage00.Controls.Add(Me.Lbl007)
Me.TabPage00.Location = New System.Drawing.Point(4, 4)
Me.TabPage00.Name = "TabPage00"
Me.TabPage00.Padding = New System.Windows.Forms.Padding(3)
Me.TabPage00.Size = New System.Drawing.Size(1172, 762)
Me.TabPage00.TabIndex = 0
Me.TabPage00.Text = "0"
Me.TabPage00.UseVisualStyleBackColor = True
Me.Tabpage00.CausesValidation = False
'
'Lbl007
'
Me.Lbl007.AutoSize = True
Me.Lbl007.Location = New System.Drawing.Point(40,10)
Me.Lbl007.Name = "Lbl007"
Me.Lbl007.Size = New System.Drawing.Size(41, 13)
Me.Lbl007.Tabindex = 9999
Me.Lbl007.Text = "Población (2):"
'
'TxtDatos007
'
Me.TxtDatos007.Location = New System.Drawing.Point(114,8)
Me.TxtDatos007.Name = "TxtDatos007"
Me.TxtDatos007.ReadOnly = True
Me.TxtDatos007.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos007.Tabindex = 9999
'
'CnEdicion007
'
Me.CnEdicion007.AceptaEspacios = True
Me.CnEdicion007.AceptaMayusculas = True
Me.CnEdicion007.AceptaMayusculasAcentuadas = False
Me.CnEdicion007.AceptaMinusculas = False
Me.CnEdicion007.AceptaMinusculasAcentuadas = False
Me.CnEdicion007.AceptaNumeros = True
Me.CnEdicion007.AceptaSimbolos = True
Me.CnEdicion007.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion007.ConvierteAMayusculas = True
Me.CnEdicion007.ConvierteAMinusculas = False
Me.CnEdicion007.EsFechaHoraCreacion = False
Me.CnEdicion007.EsFechaHoraModificacion = False
Me.CnEdicion007.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion007.ColorFondo = System.Drawing.Color.White
Me.CnEdicion007.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion007.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion007.Campo = "poblacion_2"
Me.CnEdicion007.CampoEnlacesLookup1 = Nothing
Me.CnEdicion007.CampoEnlacesLookup2 = Nothing
Me.CnEdicion007.CampoEnlacesLookup3 = Nothing
Me.CnEdicion007.EdicionEnGrid = False
Me.CnEdicion007.TituloParaGrid = Nothing
Me.CnEdicion007.AnchoColumnaGrid = 0
Me.CnEdicion007.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion007.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion007.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion007.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion007.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion007.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion007.EnCreacionSoloLectura = False
Me.CnEdicion007.EnCreacionOculto = False
Me.CnEdicion007.SiempreSoloLectura = False
Me.CnEdicion007.SiempreOculto = False
Me.CnEdicion007.EnlacesLookup1 = 0
Me.CnEdicion007.EnlacesLookup2 = 0
Me.CnEdicion007.EnlacesLookup3 = 0
Me.CnEdicion007.EnModificacionSoloLectura = False
Me.CnEdicion007.EnModificacionOculto = False
Me.CnEdicion007.Fuente = Nothing
Me.CnEdicion007.HayMascaraEspecial = False
Me.CnEdicion007.HayValorDefecto = False
Me.CnEdicion007.NumeroParametroValorDefecto = 0
Me.CnEdicion007.ValorDefecto = ""
Me.CnEdicion007.HayValorFijo = False
Me.CnEdicion007.NumeroParametroValorFijo = 0
Me.CnEdicion007.ValorFijo = ""
Me.CnEdicion007.HayValorFijoCreacion = False
Me.CnEdicion007.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion007.ValorFijoCreacion = ""
Me.CnEdicion007.Location = New System.Drawing.Point(118,8)
Me.CnEdicion007.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion007.MascaraEspecial = ""
Me.CnEdicion007.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion007.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion007.MaximoNumero = 999999999999999.0R
Me.CnEdicion007.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion007.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion007.MinimoNumero = -999999999999999.0R
Me.CnEdicion007.Name = "CnEdicion007"
Me.CnEdicion007.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion007.TabIndex = 9999
Me.CnEdicion007.Tabla = "cabeceras_salida"
'
'Lbl008
'
Me.Lbl008.AutoSize = True
Me.Lbl008.Location = New System.Drawing.Point(59,31)
Me.Lbl008.Name = "Lbl008"
Me.Lbl008.Size = New System.Drawing.Size(41, 13)
Me.Lbl008.Tabindex = 9999
Me.Lbl008.Text = "Provincia:"
'
'TxtDatos008
'
Me.TxtDatos008.Location = New System.Drawing.Point(114,29)
Me.TxtDatos008.Name = "TxtDatos008"
Me.TxtDatos008.ReadOnly = True
Me.TxtDatos008.Size = New System.Drawing.Size(40, 20)
Me.TxtDatos008.Tabindex = 9999
'
'CnEdicion008
'
Me.CnEdicion008.AceptaEspacios = True
Me.CnEdicion008.AceptaMayusculas = True
Me.CnEdicion008.AceptaMayusculasAcentuadas = False
Me.CnEdicion008.AceptaMinusculas = False
Me.CnEdicion008.AceptaMinusculasAcentuadas = False
Me.CnEdicion008.AceptaNumeros = True
Me.CnEdicion008.AceptaSimbolos = True
Me.CnEdicion008.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion008.ConvierteAMayusculas = True
Me.CnEdicion008.ConvierteAMinusculas = False
Me.CnEdicion008.EsFechaHoraCreacion = False
Me.CnEdicion008.EsFechaHoraModificacion = False
Me.CnEdicion008.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion008.ColorFondo = System.Drawing.Color.White
Me.CnEdicion008.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion008.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion008.Campo = "provincia"
Me.CnEdicion008.CampoEnlacesLookup1 = "nombre_provincia"
Me.CnEdicion008.CampoEnlacesLookup2 = Nothing
Me.CnEdicion008.CampoEnlacesLookup3 = Nothing
Me.CnEdicion008.EdicionEnGrid = False
Me.CnEdicion008.TituloParaGrid = Nothing
Me.CnEdicion008.AnchoColumnaGrid = 0
Me.CnEdicion008.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion008.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion008.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion008.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion008.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion008.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion008.EnCreacionSoloLectura = False
Me.CnEdicion008.EnCreacionOculto = False
Me.CnEdicion008.SiempreSoloLectura = False
Me.CnEdicion008.SiempreOculto = False
Me.CnEdicion008.EnlacesLookup1 = 31177
Me.CnEdicion008.EnlacesLookup2 = 0
Me.CnEdicion008.EnlacesLookup3 = 0
Me.CnEdicion008.EnModificacionSoloLectura = False
Me.CnEdicion008.EnModificacionOculto = False
Me.CnEdicion008.Fuente = Nothing
Me.CnEdicion008.HayMascaraEspecial = False
Me.CnEdicion008.HayValorDefecto = False
Me.CnEdicion008.NumeroParametroValorDefecto = 0
Me.CnEdicion008.ValorDefecto = ""
Me.CnEdicion008.HayValorFijo = False
Me.CnEdicion008.NumeroParametroValorFijo = 0
Me.CnEdicion008.ValorFijo = ""
Me.CnEdicion008.HayValorFijoCreacion = False
Me.CnEdicion008.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion008.ValorFijoCreacion = ""
Me.CnEdicion008.Location = New System.Drawing.Point(118,29)
Me.CnEdicion008.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion008.MascaraEspecial = ""
Me.CnEdicion008.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion008.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion008.MaximoNumero = 999999999999999.0R
Me.CnEdicion008.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion008.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion008.MinimoNumero = -999999999999999.0R
Me.CnEdicion008.Name = "CnEdicion008"
Me.CnEdicion008.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion008.TabIndex = 9999
Me.CnEdicion008.Tabla = "cabeceras_salida"
'
'CmdGrid008
'
Me.CmdGrid008.Image = CType(Resources.GetObject("CmdGrid008.Image"), System.Drawing.Image)
Me.CmdGrid008.Location = New System.Drawing.Point(155,29)
Me.CmdGrid008.Name = "CmdGrid008"
Me.CmdGrid008.Size = New System.Drawing.Size(24,22)
Me.CmdGrid008.UseVisualStyleBackColor = True
Me.CmdGrid008.Tabindex = 9999
'
'TxtLookup0081
'
Me.TxtLookup0081.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0081.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0081.Location = New System.Drawing.Point(189,32)
Me.TxtLookup0081.Name = "TxtLookup0081"
Me.TxtLookup0081.ReadOnly = True
Me.TxtLookup0081.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0081.Tabindex = 9999
'
'Lbl009
'
Me.Lbl009.AutoSize = True
Me.Lbl009.Location = New System.Drawing.Point(83,52)
Me.Lbl009.Name = "Lbl009"
Me.Lbl009.Size = New System.Drawing.Size(41, 13)
Me.Lbl009.Tabindex = 9999
Me.Lbl009.Text = "Pais:"
'
'TxtDatos009
'
Me.TxtDatos009.Location = New System.Drawing.Point(114,50)
Me.TxtDatos009.Name = "TxtDatos009"
Me.TxtDatos009.ReadOnly = True
Me.TxtDatos009.Size = New System.Drawing.Size(30, 20)
Me.TxtDatos009.Tabindex = 9999
'
'CnEdicion009
'
Me.CnEdicion009.AceptaEspacios = True
Me.CnEdicion009.AceptaMayusculas = True
Me.CnEdicion009.AceptaMayusculasAcentuadas = False
Me.CnEdicion009.AceptaMinusculas = False
Me.CnEdicion009.AceptaMinusculasAcentuadas = False
Me.CnEdicion009.AceptaNumeros = True
Me.CnEdicion009.AceptaSimbolos = True
Me.CnEdicion009.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion009.ConvierteAMayusculas = True
Me.CnEdicion009.ConvierteAMinusculas = False
Me.CnEdicion009.EsFechaHoraCreacion = False
Me.CnEdicion009.EsFechaHoraModificacion = False
Me.CnEdicion009.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion009.ColorFondo = System.Drawing.Color.White
Me.CnEdicion009.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion009.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion009.Campo = "pais"
Me.CnEdicion009.CampoEnlacesLookup1 = "nombre_pais"
Me.CnEdicion009.CampoEnlacesLookup2 = Nothing
Me.CnEdicion009.CampoEnlacesLookup3 = Nothing
Me.CnEdicion009.EdicionEnGrid = False
Me.CnEdicion009.TituloParaGrid = Nothing
Me.CnEdicion009.AnchoColumnaGrid = 0
Me.CnEdicion009.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion009.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion009.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion009.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion009.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion009.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion009.EnCreacionSoloLectura = False
Me.CnEdicion009.EnCreacionOculto = False
Me.CnEdicion009.SiempreSoloLectura = False
Me.CnEdicion009.SiempreOculto = False
Me.CnEdicion009.EnlacesLookup1 = 31175
Me.CnEdicion009.EnlacesLookup2 = 0
Me.CnEdicion009.EnlacesLookup3 = 0
Me.CnEdicion009.EnModificacionSoloLectura = False
Me.CnEdicion009.EnModificacionOculto = False
Me.CnEdicion009.Fuente = Nothing
Me.CnEdicion009.HayMascaraEspecial = False
Me.CnEdicion009.HayValorDefecto = False
Me.CnEdicion009.NumeroParametroValorDefecto = 0
Me.CnEdicion009.ValorDefecto = ""
Me.CnEdicion009.HayValorFijo = False
Me.CnEdicion009.NumeroParametroValorFijo = 0
Me.CnEdicion009.ValorFijo = ""
Me.CnEdicion009.HayValorFijoCreacion = False
Me.CnEdicion009.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion009.ValorFijoCreacion = ""
Me.CnEdicion009.Location = New System.Drawing.Point(118,50)
Me.CnEdicion009.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion009.MascaraEspecial = ""
Me.CnEdicion009.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion009.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion009.MaximoNumero = 999999999999999.0R
Me.CnEdicion009.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion009.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion009.MinimoNumero = -999999999999999.0R
Me.CnEdicion009.Name = "CnEdicion009"
Me.CnEdicion009.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion009.TabIndex = 9999
Me.CnEdicion009.Tabla = "cabeceras_salida"
'
'CmdGrid009
'
Me.CmdGrid009.Image = CType(Resources.GetObject("CmdGrid009.Image"), System.Drawing.Image)
Me.CmdGrid009.Location = New System.Drawing.Point(145,50)
Me.CmdGrid009.Name = "CmdGrid009"
Me.CmdGrid009.Size = New System.Drawing.Size(24,22)
Me.CmdGrid009.UseVisualStyleBackColor = True
Me.CmdGrid009.Tabindex = 9999
'
'TxtLookup0091
'
Me.TxtLookup0091.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0091.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0091.Location = New System.Drawing.Point(179,53)
Me.TxtLookup0091.Name = "TxtLookup0091"
Me.TxtLookup0091.ReadOnly = True
Me.TxtLookup0091.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0091.Tabindex = 9999
'
'Lbl010
'
Me.Lbl010.AutoSize = True
Me.Lbl010.Location = New System.Drawing.Point(44,73)
Me.Lbl010.Name = "Lbl010"
Me.Lbl010.Size = New System.Drawing.Size(41, 13)
Me.Lbl010.Tabindex = 9999
Me.Lbl010.Text = "Tabla I.V.A.:"
'
'TxtDatos010
'
Me.TxtDatos010.Location = New System.Drawing.Point(114,71)
Me.TxtDatos010.Name = "TxtDatos010"
Me.TxtDatos010.ReadOnly = True
Me.TxtDatos010.Size = New System.Drawing.Size(80, 20)
Me.TxtDatos010.Tabindex = 9999
'
'CnEdicion010
'
Me.CnEdicion010.AceptaEspacios = True
Me.CnEdicion010.AceptaMayusculas = True
Me.CnEdicion010.AceptaMayusculasAcentuadas = False
Me.CnEdicion010.AceptaMinusculas = False
Me.CnEdicion010.AceptaMinusculasAcentuadas = False
Me.CnEdicion010.AceptaNumeros = True
Me.CnEdicion010.AceptaSimbolos = True
Me.CnEdicion010.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion010.ConvierteAMayusculas = True
Me.CnEdicion010.ConvierteAMinusculas = False
Me.CnEdicion010.EsFechaHoraCreacion = False
Me.CnEdicion010.EsFechaHoraModificacion = False
Me.CnEdicion010.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion010.ColorFondo = System.Drawing.Color.White
Me.CnEdicion010.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion010.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion010.Campo = "tabla_iva_clientes"
Me.CnEdicion010.CampoEnlacesLookup1 = "nombre_tabla"
Me.CnEdicion010.CampoEnlacesLookup2 = Nothing
Me.CnEdicion010.CampoEnlacesLookup3 = Nothing
Me.CnEdicion010.EdicionEnGrid = False
Me.CnEdicion010.TituloParaGrid = Nothing
Me.CnEdicion010.AnchoColumnaGrid = 0
Me.CnEdicion010.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion010.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion010.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion010.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion010.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion010.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion010.EnCreacionSoloLectura = False
Me.CnEdicion010.EnCreacionOculto = False
Me.CnEdicion010.SiempreSoloLectura = False
Me.CnEdicion010.SiempreOculto = False
Me.CnEdicion010.EnlacesLookup1 = 31181
Me.CnEdicion010.EnlacesLookup2 = 0
Me.CnEdicion010.EnlacesLookup3 = 0
Me.CnEdicion010.EnModificacionSoloLectura = False
Me.CnEdicion010.EnModificacionOculto = False
Me.CnEdicion010.Fuente = Nothing
Me.CnEdicion010.HayMascaraEspecial = False
Me.CnEdicion010.HayValorDefecto = False
Me.CnEdicion010.NumeroParametroValorDefecto = 0
Me.CnEdicion010.ValorDefecto = ""
Me.CnEdicion010.HayValorFijo = False
Me.CnEdicion010.NumeroParametroValorFijo = 0
Me.CnEdicion010.ValorFijo = ""
Me.CnEdicion010.HayValorFijoCreacion = False
Me.CnEdicion010.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion010.ValorFijoCreacion = ""
Me.CnEdicion010.Location = New System.Drawing.Point(118,71)
Me.CnEdicion010.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion010.MascaraEspecial = ""
Me.CnEdicion010.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion010.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion010.MaximoNumero = 999999999999999.0R
Me.CnEdicion010.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion010.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion010.MinimoNumero = -999999999999999.0R
Me.CnEdicion010.Name = "CnEdicion010"
Me.CnEdicion010.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion010.TabIndex = 9999
Me.CnEdicion010.Tabla = "cabeceras_salida"
'
'CmdGrid010
'
Me.CmdGrid010.Image = CType(Resources.GetObject("CmdGrid010.Image"), System.Drawing.Image)
Me.CmdGrid010.Location = New System.Drawing.Point(195,71)
Me.CmdGrid010.Name = "CmdGrid010"
Me.CmdGrid010.Size = New System.Drawing.Size(24,22)
Me.CmdGrid010.UseVisualStyleBackColor = True
Me.CmdGrid010.Tabindex = 9999
'
'TxtLookup0101
'
Me.TxtLookup0101.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0101.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0101.Location = New System.Drawing.Point(229,74)
Me.TxtLookup0101.Name = "TxtLookup0101"
Me.TxtLookup0101.ReadOnly = True
Me.TxtLookup0101.Size = New System.Drawing.Size(240, 13)
Me.TxtLookup0101.Tabindex = 9999
'
'Lbl011
'
Me.Lbl011.AutoSize = True
Me.Lbl011.Location = New System.Drawing.Point(43,94)
Me.Lbl011.Name = "Lbl011"
Me.Lbl011.Size = New System.Drawing.Size(41, 13)
Me.Lbl011.Tabindex = 9999
Me.Lbl011.Text = "Req.eq. S/N:"
'
'TxtDatos011
'
Me.TxtDatos011.Location = New System.Drawing.Point(114,92)
Me.TxtDatos011.Name = "TxtDatos011"
Me.TxtDatos011.ReadOnly = True
Me.TxtDatos011.Size = New System.Drawing.Size(40, 20)
Me.TxtDatos011.Tabindex = 9999
'
'CnEdicion011
'
Me.CnEdicion011.AceptaEspacios = True
Me.CnEdicion011.AceptaMayusculas = True
Me.CnEdicion011.AceptaMayusculasAcentuadas = False
Me.CnEdicion011.AceptaMinusculas = False
Me.CnEdicion011.AceptaMinusculasAcentuadas = False
Me.CnEdicion011.AceptaNumeros = True
Me.CnEdicion011.AceptaSimbolos = True
Me.CnEdicion011.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion011.ConvierteAMayusculas = True
Me.CnEdicion011.ConvierteAMinusculas = False
Me.CnEdicion011.EsFechaHoraCreacion = False
Me.CnEdicion011.EsFechaHoraModificacion = False
Me.CnEdicion011.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion011.ColorFondo = System.Drawing.Color.White
Me.CnEdicion011.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion011.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion011.Campo = "recargo_sn"
Me.CnEdicion011.CampoEnlacesLookup1 = Nothing
Me.CnEdicion011.CampoEnlacesLookup2 = Nothing
Me.CnEdicion011.CampoEnlacesLookup3 = Nothing
Me.CnEdicion011.EdicionEnGrid = False
Me.CnEdicion011.TituloParaGrid = Nothing
Me.CnEdicion011.AnchoColumnaGrid = 0
Me.CnEdicion011.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion011.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion011.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion011.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion011.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion011.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion011.EnCreacionSoloLectura = False
Me.CnEdicion011.EnCreacionOculto = False
Me.CnEdicion011.SiempreSoloLectura = False
Me.CnEdicion011.SiempreOculto = False
Me.CnEdicion011.EnlacesLookup1 = 0
Me.CnEdicion011.EnlacesLookup2 = 0
Me.CnEdicion011.EnlacesLookup3 = 0
Me.CnEdicion011.EnModificacionSoloLectura = False
Me.CnEdicion011.EnModificacionOculto = False
Me.CnEdicion011.Fuente = Nothing
Me.CnEdicion011.HayMascaraEspecial = False
Me.CnEdicion011.HayValorDefecto = True
Me.CnEdicion011.NumeroParametroValorDefecto = 0
Me.CnEdicion011.ValorDefecto = "N"
Me.CnEdicion011.HayValorFijo = False
Me.CnEdicion011.NumeroParametroValorFijo = 0
Me.CnEdicion011.ValorFijo = ""
Me.CnEdicion011.HayValorFijoCreacion = False
Me.CnEdicion011.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion011.ValorFijoCreacion = ""
Me.CnEdicion011.Location = New System.Drawing.Point(118,92)
Me.CnEdicion011.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion011.MascaraEspecial = ""
Me.CnEdicion011.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion011.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion011.MaximoNumero = 999999999999999.0R
Me.CnEdicion011.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion011.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion011.MinimoNumero = -999999999999999.0R
Me.CnEdicion011.Name = "CnEdicion011"
Me.CnEdicion011.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion011.TabIndex = 9999
Me.CnEdicion011.Tabla = "cabeceras_salida"
'
'CmdCombo011
'
Me.CmdCombo011.Image = CType(Resources.GetObject("CmdCombo011.Image"), System.Drawing.Image)
Me.CmdCombo011.Location = New System.Drawing.Point(155,92)
Me.CmdCombo011.Name = "CmdCombo011"
Me.CmdCombo011.Size = New System.Drawing.Size(24,22)
Me.CmdCombo011.UseVisualStyleBackColor = True
Me.CmdCombo011.Tabindex = 9999
'
'Lbl012
'
Me.Lbl012.AutoSize = True
Me.Lbl012.Location = New System.Drawing.Point(73,115)
Me.Lbl012.Name = "Lbl012"
Me.Lbl012.Size = New System.Drawing.Size(41, 13)
Me.Lbl012.Tabindex = 9999
Me.Lbl012.Text = "Marca:"
'
'TxtDatos012
'
Me.TxtDatos012.Location = New System.Drawing.Point(114,113)
Me.TxtDatos012.Name = "TxtDatos012"
Me.TxtDatos012.ReadOnly = True
Me.TxtDatos012.Size = New System.Drawing.Size(64, 20)
Me.TxtDatos012.Tabindex = 9999
'
'CnEdicion012
'
Me.CnEdicion012.AceptaEspacios = True
Me.CnEdicion012.AceptaMayusculas = True
Me.CnEdicion012.AceptaMayusculasAcentuadas = False
Me.CnEdicion012.AceptaMinusculas = False
Me.CnEdicion012.AceptaMinusculasAcentuadas = False
Me.CnEdicion012.AceptaNumeros = True
Me.CnEdicion012.AceptaSimbolos = True
Me.CnEdicion012.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion012.ConvierteAMayusculas = True
Me.CnEdicion012.ConvierteAMinusculas = False
Me.CnEdicion012.EsFechaHoraCreacion = False
Me.CnEdicion012.EsFechaHoraModificacion = False
Me.CnEdicion012.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion012.ColorFondo = System.Drawing.Color.White
Me.CnEdicion012.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion012.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion012.Campo = "marca"
Me.CnEdicion012.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion012.CampoEnlacesLookup2 = Nothing
Me.CnEdicion012.CampoEnlacesLookup3 = Nothing
Me.CnEdicion012.EdicionEnGrid = False
Me.CnEdicion012.TituloParaGrid = Nothing
Me.CnEdicion012.AnchoColumnaGrid = 0
Me.CnEdicion012.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion012.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion012.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion012.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion012.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion012.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion012.EnCreacionSoloLectura = False
Me.CnEdicion012.EnCreacionOculto = False
Me.CnEdicion012.SiempreSoloLectura = False
Me.CnEdicion012.SiempreOculto = False
Me.CnEdicion012.EnlacesLookup1 = 31182
Me.CnEdicion012.EnlacesLookup2 = 0
Me.CnEdicion012.EnlacesLookup3 = 0
Me.CnEdicion012.EnModificacionSoloLectura = False
Me.CnEdicion012.EnModificacionOculto = False
Me.CnEdicion012.Fuente = Nothing
Me.CnEdicion012.HayMascaraEspecial = False
Me.CnEdicion012.HayValorDefecto = False
Me.CnEdicion012.NumeroParametroValorDefecto = 0
Me.CnEdicion012.ValorDefecto = ""
Me.CnEdicion012.HayValorFijo = False
Me.CnEdicion012.NumeroParametroValorFijo = 0
Me.CnEdicion012.ValorFijo = ""
Me.CnEdicion012.HayValorFijoCreacion = False
Me.CnEdicion012.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion012.ValorFijoCreacion = ""
Me.CnEdicion012.Location = New System.Drawing.Point(118,113)
Me.CnEdicion012.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion012.MascaraEspecial = ""
Me.CnEdicion012.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion012.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion012.MaximoNumero = 999999999999999.0R
Me.CnEdicion012.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion012.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion012.MinimoNumero = -999999999999999.0R
Me.CnEdicion012.Name = "CnEdicion012"
Me.CnEdicion012.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion012.TabIndex = 9999
Me.CnEdicion012.Tabla = "cabeceras_salida"
'
'CmdGrid012
'
Me.CmdGrid012.Image = CType(Resources.GetObject("CmdGrid012.Image"), System.Drawing.Image)
Me.CmdGrid012.Location = New System.Drawing.Point(179,113)
Me.CmdGrid012.Name = "CmdGrid012"
Me.CmdGrid012.Size = New System.Drawing.Size(24,22)
Me.CmdGrid012.UseVisualStyleBackColor = True
Me.CmdGrid012.Tabindex = 9999
'
'TxtLookup0121
'
Me.TxtLookup0121.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0121.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0121.Location = New System.Drawing.Point(213,116)
Me.TxtLookup0121.Name = "TxtLookup0121"
Me.TxtLookup0121.ReadOnly = True
Me.TxtLookup0121.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0121.Tabindex = 9999
'
'Lbl013
'
Me.Lbl013.AutoSize = True
Me.Lbl013.Location = New System.Drawing.Point(51,136)
Me.Lbl013.Name = "Lbl013"
Me.Lbl013.Size = New System.Drawing.Size(41, 13)
Me.Lbl013.Tabindex = 9999
Me.Lbl013.Text = "Expedición:"
'
'TxtDatos013
'
Me.TxtDatos013.Location = New System.Drawing.Point(114,134)
Me.TxtDatos013.Name = "TxtDatos013"
Me.TxtDatos013.ReadOnly = True
Me.TxtDatos013.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos013.Tabindex = 9999
'
'CnEdicion013
'
Me.CnEdicion013.AceptaEspacios = True
Me.CnEdicion013.AceptaMayusculas = True
Me.CnEdicion013.AceptaMayusculasAcentuadas = True
Me.CnEdicion013.AceptaMinusculas = True
Me.CnEdicion013.AceptaMinusculasAcentuadas = True
Me.CnEdicion013.AceptaNumeros = True
Me.CnEdicion013.AceptaSimbolos = False
Me.CnEdicion013.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion013.ConvierteAMayusculas = False
Me.CnEdicion013.ConvierteAMinusculas = False
Me.CnEdicion013.EsFechaHoraCreacion = False
Me.CnEdicion013.EsFechaHoraModificacion = False
Me.CnEdicion013.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion013.ColorFondo = System.Drawing.Color.White
Me.CnEdicion013.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion013.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion013.Campo = "expedicion"
Me.CnEdicion013.CampoEnlacesLookup1 = Nothing
Me.CnEdicion013.CampoEnlacesLookup2 = Nothing
Me.CnEdicion013.CampoEnlacesLookup3 = Nothing
Me.CnEdicion013.EdicionEnGrid = False
Me.CnEdicion013.TituloParaGrid = Nothing
Me.CnEdicion013.AnchoColumnaGrid = 0
Me.CnEdicion013.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion013.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion013.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion013.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion013.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion013.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion013.EnCreacionSoloLectura = False
Me.CnEdicion013.EnCreacionOculto = False
Me.CnEdicion013.SiempreSoloLectura = False
Me.CnEdicion013.SiempreOculto = False
Me.CnEdicion013.EnlacesLookup1 = 0
Me.CnEdicion013.EnlacesLookup2 = 0
Me.CnEdicion013.EnlacesLookup3 = 0
Me.CnEdicion013.EnModificacionSoloLectura = False
Me.CnEdicion013.EnModificacionOculto = False
Me.CnEdicion013.Fuente = Nothing
Me.CnEdicion013.HayMascaraEspecial = False
Me.CnEdicion013.HayValorDefecto = True
Me.CnEdicion013.NumeroParametroValorDefecto = 0
Me.CnEdicion013.ValorDefecto = "0"
Me.CnEdicion013.HayValorFijo = False
Me.CnEdicion013.NumeroParametroValorFijo = 0
Me.CnEdicion013.ValorFijo = ""
Me.CnEdicion013.HayValorFijoCreacion = False
Me.CnEdicion013.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion013.ValorFijoCreacion = ""
Me.CnEdicion013.Location = New System.Drawing.Point(118,134)
Me.CnEdicion013.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion013.MascaraEspecial = ""
Me.CnEdicion013.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion013.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion013.MaximoNumero = 999999999999999.0R
Me.CnEdicion013.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion013.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion013.MinimoNumero = -999999999999999.0R
Me.CnEdicion013.Name = "CnEdicion013"
Me.CnEdicion013.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion013.TabIndex = 9999
Me.CnEdicion013.Tabla = "cabeceras_salida"
'
'Lbl014
'
Me.Lbl014.AutoSize = True
Me.Lbl014.Location = New System.Drawing.Point(5,157)
Me.Lbl014.Name = "Lbl014"
Me.Lbl014.Size = New System.Drawing.Size(41, 13)
Me.Lbl014.Tabindex = 9999
Me.Lbl014.Text = "Nombre destinatario:"
'
'TxtDatos014
'
Me.TxtDatos014.Location = New System.Drawing.Point(114,155)
Me.TxtDatos014.Name = "TxtDatos014"
Me.TxtDatos014.ReadOnly = True
Me.TxtDatos014.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos014.Tabindex = 9999
'
'CnEdicion014
'
Me.CnEdicion014.AceptaEspacios = True
Me.CnEdicion014.AceptaMayusculas = True
Me.CnEdicion014.AceptaMayusculasAcentuadas = False
Me.CnEdicion014.AceptaMinusculas = False
Me.CnEdicion014.AceptaMinusculasAcentuadas = False
Me.CnEdicion014.AceptaNumeros = True
Me.CnEdicion014.AceptaSimbolos = True
Me.CnEdicion014.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion014.ConvierteAMayusculas = True
Me.CnEdicion014.ConvierteAMinusculas = False
Me.CnEdicion014.EsFechaHoraCreacion = False
Me.CnEdicion014.EsFechaHoraModificacion = False
Me.CnEdicion014.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion014.ColorFondo = System.Drawing.Color.White
Me.CnEdicion014.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion014.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion014.Campo = "nombre_dest"
Me.CnEdicion014.CampoEnlacesLookup1 = Nothing
Me.CnEdicion014.CampoEnlacesLookup2 = Nothing
Me.CnEdicion014.CampoEnlacesLookup3 = Nothing
Me.CnEdicion014.EdicionEnGrid = False
Me.CnEdicion014.TituloParaGrid = Nothing
Me.CnEdicion014.AnchoColumnaGrid = 0
Me.CnEdicion014.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion014.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion014.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion014.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion014.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion014.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion014.EnCreacionSoloLectura = False
Me.CnEdicion014.EnCreacionOculto = False
Me.CnEdicion014.SiempreSoloLectura = False
Me.CnEdicion014.SiempreOculto = False
Me.CnEdicion014.EnlacesLookup1 = 0
Me.CnEdicion014.EnlacesLookup2 = 0
Me.CnEdicion014.EnlacesLookup3 = 0
Me.CnEdicion014.EnModificacionSoloLectura = False
Me.CnEdicion014.EnModificacionOculto = False
Me.CnEdicion014.Fuente = Nothing
Me.CnEdicion014.HayMascaraEspecial = False
Me.CnEdicion014.HayValorDefecto = False
Me.CnEdicion014.NumeroParametroValorDefecto = 0
Me.CnEdicion014.ValorDefecto = ""
Me.CnEdicion014.HayValorFijo = False
Me.CnEdicion014.NumeroParametroValorFijo = 0
Me.CnEdicion014.ValorFijo = ""
Me.CnEdicion014.HayValorFijoCreacion = False
Me.CnEdicion014.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion014.ValorFijoCreacion = ""
Me.CnEdicion014.Location = New System.Drawing.Point(118,155)
Me.CnEdicion014.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion014.MascaraEspecial = ""
Me.CnEdicion014.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion014.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion014.MaximoNumero = 999999999999999.0R
Me.CnEdicion014.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion014.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion014.MinimoNumero = -999999999999999.0R
Me.CnEdicion014.Name = "CnEdicion014"
Me.CnEdicion014.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion014.TabIndex = 9999
Me.CnEdicion014.Tabla = "cabeceras_salida"
'
'Lbl015
'
Me.Lbl015.AutoSize = True
Me.Lbl015.Location = New System.Drawing.Point(64,178)
Me.Lbl015.Name = "Lbl015"
Me.Lbl015.Size = New System.Drawing.Size(41, 13)
Me.Lbl015.Tabindex = 9999
Me.Lbl015.Text = "Nif Dest:"
'
'TxtDatos015
'
Me.TxtDatos015.Location = New System.Drawing.Point(114,176)
Me.TxtDatos015.Name = "TxtDatos015"
Me.TxtDatos015.ReadOnly = True
Me.TxtDatos015.Size = New System.Drawing.Size(144, 20)
Me.TxtDatos015.Tabindex = 9999
'
'CnEdicion015
'
Me.CnEdicion015.AceptaEspacios = True
Me.CnEdicion015.AceptaMayusculas = True
Me.CnEdicion015.AceptaMayusculasAcentuadas = False
Me.CnEdicion015.AceptaMinusculas = False
Me.CnEdicion015.AceptaMinusculasAcentuadas = False
Me.CnEdicion015.AceptaNumeros = True
Me.CnEdicion015.AceptaSimbolos = True
Me.CnEdicion015.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion015.ConvierteAMayusculas = True
Me.CnEdicion015.ConvierteAMinusculas = False
Me.CnEdicion015.EsFechaHoraCreacion = False
Me.CnEdicion015.EsFechaHoraModificacion = False
Me.CnEdicion015.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion015.ColorFondo = System.Drawing.Color.White
Me.CnEdicion015.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion015.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion015.Campo = "nif_dest"
Me.CnEdicion015.CampoEnlacesLookup1 = Nothing
Me.CnEdicion015.CampoEnlacesLookup2 = Nothing
Me.CnEdicion015.CampoEnlacesLookup3 = Nothing
Me.CnEdicion015.EdicionEnGrid = False
Me.CnEdicion015.TituloParaGrid = Nothing
Me.CnEdicion015.AnchoColumnaGrid = 0
Me.CnEdicion015.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion015.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion015.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion015.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion015.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion015.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion015.EnCreacionSoloLectura = False
Me.CnEdicion015.EnCreacionOculto = False
Me.CnEdicion015.SiempreSoloLectura = False
Me.CnEdicion015.SiempreOculto = False
Me.CnEdicion015.EnlacesLookup1 = 0
Me.CnEdicion015.EnlacesLookup2 = 0
Me.CnEdicion015.EnlacesLookup3 = 0
Me.CnEdicion015.EnModificacionSoloLectura = False
Me.CnEdicion015.EnModificacionOculto = False
Me.CnEdicion015.Fuente = Nothing
Me.CnEdicion015.HayMascaraEspecial = False
Me.CnEdicion015.HayValorDefecto = False
Me.CnEdicion015.NumeroParametroValorDefecto = 0
Me.CnEdicion015.ValorDefecto = ""
Me.CnEdicion015.HayValorFijo = False
Me.CnEdicion015.NumeroParametroValorFijo = 0
Me.CnEdicion015.ValorFijo = ""
Me.CnEdicion015.HayValorFijoCreacion = False
Me.CnEdicion015.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion015.ValorFijoCreacion = ""
Me.CnEdicion015.Location = New System.Drawing.Point(118,176)
Me.CnEdicion015.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion015.MascaraEspecial = ""
Me.CnEdicion015.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion015.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion015.MaximoNumero = 999999999999999.0R
Me.CnEdicion015.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion015.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion015.MinimoNumero = -999999999999999.0R
Me.CnEdicion015.Name = "CnEdicion015"
Me.CnEdicion015.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion015.TabIndex = 9999
Me.CnEdicion015.Tabla = "cabeceras_salida"
'
'Lbl016
'
Me.Lbl016.AutoSize = True
Me.Lbl016.Location = New System.Drawing.Point(24,199)
Me.Lbl016.Name = "Lbl016"
Me.Lbl016.Size = New System.Drawing.Size(41, 13)
Me.Lbl016.Tabindex = 9999
Me.Lbl016.Text = "Domicilio destino:"
'
'TxtDatos016
'
Me.TxtDatos016.Location = New System.Drawing.Point(114,197)
Me.TxtDatos016.Name = "TxtDatos016"
Me.TxtDatos016.ReadOnly = True
Me.TxtDatos016.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos016.Tabindex = 9999
'
'CnEdicion016
'
Me.CnEdicion016.AceptaEspacios = True
Me.CnEdicion016.AceptaMayusculas = True
Me.CnEdicion016.AceptaMayusculasAcentuadas = False
Me.CnEdicion016.AceptaMinusculas = False
Me.CnEdicion016.AceptaMinusculasAcentuadas = False
Me.CnEdicion016.AceptaNumeros = True
Me.CnEdicion016.AceptaSimbolos = True
Me.CnEdicion016.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion016.ConvierteAMayusculas = True
Me.CnEdicion016.ConvierteAMinusculas = False
Me.CnEdicion016.EsFechaHoraCreacion = False
Me.CnEdicion016.EsFechaHoraModificacion = False
Me.CnEdicion016.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion016.ColorFondo = System.Drawing.Color.White
Me.CnEdicion016.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion016.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion016.Campo = "domicilio_dest"
Me.CnEdicion016.CampoEnlacesLookup1 = Nothing
Me.CnEdicion016.CampoEnlacesLookup2 = Nothing
Me.CnEdicion016.CampoEnlacesLookup3 = Nothing
Me.CnEdicion016.EdicionEnGrid = False
Me.CnEdicion016.TituloParaGrid = Nothing
Me.CnEdicion016.AnchoColumnaGrid = 0
Me.CnEdicion016.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion016.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion016.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion016.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion016.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion016.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion016.EnCreacionSoloLectura = False
Me.CnEdicion016.EnCreacionOculto = False
Me.CnEdicion016.SiempreSoloLectura = False
Me.CnEdicion016.SiempreOculto = False
Me.CnEdicion016.EnlacesLookup1 = 0
Me.CnEdicion016.EnlacesLookup2 = 0
Me.CnEdicion016.EnlacesLookup3 = 0
Me.CnEdicion016.EnModificacionSoloLectura = False
Me.CnEdicion016.EnModificacionOculto = False
Me.CnEdicion016.Fuente = Nothing
Me.CnEdicion016.HayMascaraEspecial = False
Me.CnEdicion016.HayValorDefecto = False
Me.CnEdicion016.NumeroParametroValorDefecto = 0
Me.CnEdicion016.ValorDefecto = ""
Me.CnEdicion016.HayValorFijo = False
Me.CnEdicion016.NumeroParametroValorFijo = 0
Me.CnEdicion016.ValorFijo = ""
Me.CnEdicion016.HayValorFijoCreacion = False
Me.CnEdicion016.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion016.ValorFijoCreacion = ""
Me.CnEdicion016.Location = New System.Drawing.Point(118,197)
Me.CnEdicion016.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion016.MascaraEspecial = ""
Me.CnEdicion016.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion016.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion016.MaximoNumero = 999999999999999.0R
Me.CnEdicion016.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion016.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion016.MinimoNumero = -999999999999999.0R
Me.CnEdicion016.Name = "CnEdicion016"
Me.CnEdicion016.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion016.TabIndex = 9999
Me.CnEdicion016.Tabla = "cabeceras_salida"
'
'Lbl017
'
Me.Lbl017.AutoSize = True
Me.Lbl017.Location = New System.Drawing.Point(7,220)
Me.Lbl017.Name = "Lbl017"
Me.Lbl017.Size = New System.Drawing.Size(41, 13)
Me.Lbl017.Tabindex = 9999
Me.Lbl017.Text = "Domicilio destino (2):"
'
'TxtDatos017
'
Me.TxtDatos017.Location = New System.Drawing.Point(114,218)
Me.TxtDatos017.Name = "TxtDatos017"
Me.TxtDatos017.ReadOnly = True
Me.TxtDatos017.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos017.Tabindex = 9999
'
'CnEdicion017
'
Me.CnEdicion017.AceptaEspacios = True
Me.CnEdicion017.AceptaMayusculas = True
Me.CnEdicion017.AceptaMayusculasAcentuadas = False
Me.CnEdicion017.AceptaMinusculas = False
Me.CnEdicion017.AceptaMinusculasAcentuadas = False
Me.CnEdicion017.AceptaNumeros = True
Me.CnEdicion017.AceptaSimbolos = True
Me.CnEdicion017.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion017.ConvierteAMayusculas = True
Me.CnEdicion017.ConvierteAMinusculas = False
Me.CnEdicion017.EsFechaHoraCreacion = False
Me.CnEdicion017.EsFechaHoraModificacion = False
Me.CnEdicion017.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion017.ColorFondo = System.Drawing.Color.White
Me.CnEdicion017.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion017.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion017.Campo = "domicilio_dest_2"
Me.CnEdicion017.CampoEnlacesLookup1 = Nothing
Me.CnEdicion017.CampoEnlacesLookup2 = Nothing
Me.CnEdicion017.CampoEnlacesLookup3 = Nothing
Me.CnEdicion017.EdicionEnGrid = False
Me.CnEdicion017.TituloParaGrid = Nothing
Me.CnEdicion017.AnchoColumnaGrid = 0
Me.CnEdicion017.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion017.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion017.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion017.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion017.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion017.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion017.EnCreacionSoloLectura = False
Me.CnEdicion017.EnCreacionOculto = False
Me.CnEdicion017.SiempreSoloLectura = False
Me.CnEdicion017.SiempreOculto = False
Me.CnEdicion017.EnlacesLookup1 = 0
Me.CnEdicion017.EnlacesLookup2 = 0
Me.CnEdicion017.EnlacesLookup3 = 0
Me.CnEdicion017.EnModificacionSoloLectura = False
Me.CnEdicion017.EnModificacionOculto = False
Me.CnEdicion017.Fuente = Nothing
Me.CnEdicion017.HayMascaraEspecial = False
Me.CnEdicion017.HayValorDefecto = False
Me.CnEdicion017.NumeroParametroValorDefecto = 0
Me.CnEdicion017.ValorDefecto = ""
Me.CnEdicion017.HayValorFijo = False
Me.CnEdicion017.NumeroParametroValorFijo = 0
Me.CnEdicion017.ValorFijo = ""
Me.CnEdicion017.HayValorFijoCreacion = False
Me.CnEdicion017.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion017.ValorFijoCreacion = ""
Me.CnEdicion017.Location = New System.Drawing.Point(118,218)
Me.CnEdicion017.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion017.MascaraEspecial = ""
Me.CnEdicion017.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion017.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion017.MaximoNumero = 999999999999999.0R
Me.CnEdicion017.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion017.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion017.MinimoNumero = -999999999999999.0R
Me.CnEdicion017.Name = "CnEdicion017"
Me.CnEdicion017.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion017.TabIndex = 9999
Me.CnEdicion017.Tabla = "cabeceras_salida"
'
'Lbl018
'
Me.Lbl018.AutoSize = True
Me.Lbl018.Location = New System.Drawing.Point(9,241)
Me.Lbl018.Name = "Lbl018"
Me.Lbl018.Size = New System.Drawing.Size(41, 13)
Me.Lbl018.Tabindex = 9999
Me.Lbl018.Text = "Cód. postal destino:"
'
'TxtDatos018
'
Me.TxtDatos018.Location = New System.Drawing.Point(114,239)
Me.TxtDatos018.Name = "TxtDatos018"
Me.TxtDatos018.ReadOnly = True
Me.TxtDatos018.Size = New System.Drawing.Size(64, 20)
Me.TxtDatos018.Tabindex = 9999
'
'CnEdicion018
'
Me.CnEdicion018.AceptaEspacios = True
Me.CnEdicion018.AceptaMayusculas = True
Me.CnEdicion018.AceptaMayusculasAcentuadas = False
Me.CnEdicion018.AceptaMinusculas = False
Me.CnEdicion018.AceptaMinusculasAcentuadas = False
Me.CnEdicion018.AceptaNumeros = True
Me.CnEdicion018.AceptaSimbolos = True
Me.CnEdicion018.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion018.ConvierteAMayusculas = True
Me.CnEdicion018.ConvierteAMinusculas = False
Me.CnEdicion018.EsFechaHoraCreacion = False
Me.CnEdicion018.EsFechaHoraModificacion = False
Me.CnEdicion018.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion018.ColorFondo = System.Drawing.Color.White
Me.CnEdicion018.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion018.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion018.Campo = "codigo_postal_dest"
Me.CnEdicion018.CampoEnlacesLookup1 = Nothing
Me.CnEdicion018.CampoEnlacesLookup2 = Nothing
Me.CnEdicion018.CampoEnlacesLookup3 = Nothing
Me.CnEdicion018.EdicionEnGrid = False
Me.CnEdicion018.TituloParaGrid = Nothing
Me.CnEdicion018.AnchoColumnaGrid = 0
Me.CnEdicion018.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion018.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion018.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion018.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion018.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion018.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion018.EnCreacionSoloLectura = False
Me.CnEdicion018.EnCreacionOculto = False
Me.CnEdicion018.SiempreSoloLectura = False
Me.CnEdicion018.SiempreOculto = False
Me.CnEdicion018.EnlacesLookup1 = 0
Me.CnEdicion018.EnlacesLookup2 = 0
Me.CnEdicion018.EnlacesLookup3 = 0
Me.CnEdicion018.EnModificacionSoloLectura = False
Me.CnEdicion018.EnModificacionOculto = False
Me.CnEdicion018.Fuente = Nothing
Me.CnEdicion018.HayMascaraEspecial = False
Me.CnEdicion018.HayValorDefecto = False
Me.CnEdicion018.NumeroParametroValorDefecto = 0
Me.CnEdicion018.ValorDefecto = ""
Me.CnEdicion018.HayValorFijo = False
Me.CnEdicion018.NumeroParametroValorFijo = 0
Me.CnEdicion018.ValorFijo = ""
Me.CnEdicion018.HayValorFijoCreacion = False
Me.CnEdicion018.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion018.ValorFijoCreacion = ""
Me.CnEdicion018.Location = New System.Drawing.Point(118,239)
Me.CnEdicion018.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion018.MascaraEspecial = ""
Me.CnEdicion018.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion018.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion018.MaximoNumero = 999999999999999.0R
Me.CnEdicion018.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion018.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion018.MinimoNumero = -999999999999999.0R
Me.CnEdicion018.Name = "CnEdicion018"
Me.CnEdicion018.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion018.TabIndex = 9999
Me.CnEdicion018.Tabla = "cabeceras_salida"
'
'Lbl019
'
Me.Lbl019.AutoSize = True
Me.Lbl019.Location = New System.Drawing.Point(19,262)
Me.Lbl019.Name = "Lbl019"
Me.Lbl019.Size = New System.Drawing.Size(41, 13)
Me.Lbl019.Tabindex = 9999
Me.Lbl019.Text = "Población destino:"
'
'TxtDatos019
'
Me.TxtDatos019.Location = New System.Drawing.Point(114,260)
Me.TxtDatos019.Name = "TxtDatos019"
Me.TxtDatos019.ReadOnly = True
Me.TxtDatos019.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos019.Tabindex = 9999
'
'CnEdicion019
'
Me.CnEdicion019.AceptaEspacios = True
Me.CnEdicion019.AceptaMayusculas = True
Me.CnEdicion019.AceptaMayusculasAcentuadas = False
Me.CnEdicion019.AceptaMinusculas = False
Me.CnEdicion019.AceptaMinusculasAcentuadas = False
Me.CnEdicion019.AceptaNumeros = True
Me.CnEdicion019.AceptaSimbolos = True
Me.CnEdicion019.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion019.ConvierteAMayusculas = True
Me.CnEdicion019.ConvierteAMinusculas = False
Me.CnEdicion019.EsFechaHoraCreacion = False
Me.CnEdicion019.EsFechaHoraModificacion = False
Me.CnEdicion019.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion019.ColorFondo = System.Drawing.Color.White
Me.CnEdicion019.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion019.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion019.Campo = "poblacion_dest"
Me.CnEdicion019.CampoEnlacesLookup1 = Nothing
Me.CnEdicion019.CampoEnlacesLookup2 = Nothing
Me.CnEdicion019.CampoEnlacesLookup3 = Nothing
Me.CnEdicion019.EdicionEnGrid = False
Me.CnEdicion019.TituloParaGrid = Nothing
Me.CnEdicion019.AnchoColumnaGrid = 0
Me.CnEdicion019.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion019.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion019.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion019.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion019.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion019.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion019.EnCreacionSoloLectura = False
Me.CnEdicion019.EnCreacionOculto = False
Me.CnEdicion019.SiempreSoloLectura = False
Me.CnEdicion019.SiempreOculto = False
Me.CnEdicion019.EnlacesLookup1 = 0
Me.CnEdicion019.EnlacesLookup2 = 0
Me.CnEdicion019.EnlacesLookup3 = 0
Me.CnEdicion019.EnModificacionSoloLectura = False
Me.CnEdicion019.EnModificacionOculto = False
Me.CnEdicion019.Fuente = Nothing
Me.CnEdicion019.HayMascaraEspecial = False
Me.CnEdicion019.HayValorDefecto = False
Me.CnEdicion019.NumeroParametroValorDefecto = 0
Me.CnEdicion019.ValorDefecto = ""
Me.CnEdicion019.HayValorFijo = False
Me.CnEdicion019.NumeroParametroValorFijo = 0
Me.CnEdicion019.ValorFijo = ""
Me.CnEdicion019.HayValorFijoCreacion = False
Me.CnEdicion019.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion019.ValorFijoCreacion = ""
Me.CnEdicion019.Location = New System.Drawing.Point(118,260)
Me.CnEdicion019.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion019.MascaraEspecial = ""
Me.CnEdicion019.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion019.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion019.MaximoNumero = 999999999999999.0R
Me.CnEdicion019.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion019.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion019.MinimoNumero = -999999999999999.0R
Me.CnEdicion019.Name = "CnEdicion019"
Me.CnEdicion019.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion019.TabIndex = 9999
Me.CnEdicion019.Tabla = "cabeceras_salida"
'
'Lbl020
'
Me.Lbl020.AutoSize = True
Me.Lbl020.Location = New System.Drawing.Point(2,283)
Me.Lbl020.Name = "Lbl020"
Me.Lbl020.Size = New System.Drawing.Size(41, 13)
Me.Lbl020.Tabindex = 9999
Me.Lbl020.Text = "Población destino (2):"
'
'TxtDatos020
'
Me.TxtDatos020.Location = New System.Drawing.Point(114,281)
Me.TxtDatos020.Name = "TxtDatos020"
Me.TxtDatos020.ReadOnly = True
Me.TxtDatos020.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos020.Tabindex = 9999
'
'CnEdicion020
'
Me.CnEdicion020.AceptaEspacios = True
Me.CnEdicion020.AceptaMayusculas = True
Me.CnEdicion020.AceptaMayusculasAcentuadas = False
Me.CnEdicion020.AceptaMinusculas = False
Me.CnEdicion020.AceptaMinusculasAcentuadas = False
Me.CnEdicion020.AceptaNumeros = True
Me.CnEdicion020.AceptaSimbolos = True
Me.CnEdicion020.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion020.ConvierteAMayusculas = True
Me.CnEdicion020.ConvierteAMinusculas = False
Me.CnEdicion020.EsFechaHoraCreacion = False
Me.CnEdicion020.EsFechaHoraModificacion = False
Me.CnEdicion020.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion020.ColorFondo = System.Drawing.Color.White
Me.CnEdicion020.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion020.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion020.Campo = "poblacion_dest_2"
Me.CnEdicion020.CampoEnlacesLookup1 = Nothing
Me.CnEdicion020.CampoEnlacesLookup2 = Nothing
Me.CnEdicion020.CampoEnlacesLookup3 = Nothing
Me.CnEdicion020.EdicionEnGrid = False
Me.CnEdicion020.TituloParaGrid = Nothing
Me.CnEdicion020.AnchoColumnaGrid = 0
Me.CnEdicion020.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion020.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion020.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion020.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion020.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion020.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion020.EnCreacionSoloLectura = False
Me.CnEdicion020.EnCreacionOculto = False
Me.CnEdicion020.SiempreSoloLectura = False
Me.CnEdicion020.SiempreOculto = False
Me.CnEdicion020.EnlacesLookup1 = 0
Me.CnEdicion020.EnlacesLookup2 = 0
Me.CnEdicion020.EnlacesLookup3 = 0
Me.CnEdicion020.EnModificacionSoloLectura = False
Me.CnEdicion020.EnModificacionOculto = False
Me.CnEdicion020.Fuente = Nothing
Me.CnEdicion020.HayMascaraEspecial = False
Me.CnEdicion020.HayValorDefecto = False
Me.CnEdicion020.NumeroParametroValorDefecto = 0
Me.CnEdicion020.ValorDefecto = ""
Me.CnEdicion020.HayValorFijo = False
Me.CnEdicion020.NumeroParametroValorFijo = 0
Me.CnEdicion020.ValorFijo = ""
Me.CnEdicion020.HayValorFijoCreacion = False
Me.CnEdicion020.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion020.ValorFijoCreacion = ""
Me.CnEdicion020.Location = New System.Drawing.Point(118,281)
Me.CnEdicion020.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion020.MascaraEspecial = ""
Me.CnEdicion020.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion020.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion020.MaximoNumero = 999999999999999.0R
Me.CnEdicion020.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion020.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion020.MinimoNumero = -999999999999999.0R
Me.CnEdicion020.Name = "CnEdicion020"
Me.CnEdicion020.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion020.TabIndex = 9999
Me.CnEdicion020.Tabla = "cabeceras_salida"
'
'Lbl021
'
Me.Lbl021.AutoSize = True
Me.Lbl021.Location = New System.Drawing.Point(59,304)
Me.Lbl021.Name = "Lbl021"
Me.Lbl021.Size = New System.Drawing.Size(41, 13)
Me.Lbl021.Tabindex = 9999
Me.Lbl021.Text = "Provincia:"
'
'TxtDatos021
'
Me.TxtDatos021.Location = New System.Drawing.Point(114,302)
Me.TxtDatos021.Name = "TxtDatos021"
Me.TxtDatos021.ReadOnly = True
Me.TxtDatos021.Size = New System.Drawing.Size(40, 20)
Me.TxtDatos021.Tabindex = 9999
'
'CnEdicion021
'
Me.CnEdicion021.AceptaEspacios = True
Me.CnEdicion021.AceptaMayusculas = True
Me.CnEdicion021.AceptaMayusculasAcentuadas = False
Me.CnEdicion021.AceptaMinusculas = False
Me.CnEdicion021.AceptaMinusculasAcentuadas = False
Me.CnEdicion021.AceptaNumeros = True
Me.CnEdicion021.AceptaSimbolos = True
Me.CnEdicion021.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion021.ConvierteAMayusculas = True
Me.CnEdicion021.ConvierteAMinusculas = False
Me.CnEdicion021.EsFechaHoraCreacion = False
Me.CnEdicion021.EsFechaHoraModificacion = False
Me.CnEdicion021.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion021.ColorFondo = System.Drawing.Color.White
Me.CnEdicion021.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion021.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion021.Campo = "provincia_dest"
Me.CnEdicion021.CampoEnlacesLookup1 = "nombre_provincia"
Me.CnEdicion021.CampoEnlacesLookup2 = Nothing
Me.CnEdicion021.CampoEnlacesLookup3 = Nothing
Me.CnEdicion021.EdicionEnGrid = False
Me.CnEdicion021.TituloParaGrid = Nothing
Me.CnEdicion021.AnchoColumnaGrid = 0
Me.CnEdicion021.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion021.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion021.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion021.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion021.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion021.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion021.EnCreacionSoloLectura = False
Me.CnEdicion021.EnCreacionOculto = False
Me.CnEdicion021.SiempreSoloLectura = False
Me.CnEdicion021.SiempreOculto = False
Me.CnEdicion021.EnlacesLookup1 = 31178
Me.CnEdicion021.EnlacesLookup2 = 0
Me.CnEdicion021.EnlacesLookup3 = 0
Me.CnEdicion021.EnModificacionSoloLectura = False
Me.CnEdicion021.EnModificacionOculto = False
Me.CnEdicion021.Fuente = Nothing
Me.CnEdicion021.HayMascaraEspecial = False
Me.CnEdicion021.HayValorDefecto = False
Me.CnEdicion021.NumeroParametroValorDefecto = 0
Me.CnEdicion021.ValorDefecto = ""
Me.CnEdicion021.HayValorFijo = False
Me.CnEdicion021.NumeroParametroValorFijo = 0
Me.CnEdicion021.ValorFijo = ""
Me.CnEdicion021.HayValorFijoCreacion = False
Me.CnEdicion021.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion021.ValorFijoCreacion = ""
Me.CnEdicion021.Location = New System.Drawing.Point(118,302)
Me.CnEdicion021.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion021.MascaraEspecial = ""
Me.CnEdicion021.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion021.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion021.MaximoNumero = 999999999999999.0R
Me.CnEdicion021.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion021.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion021.MinimoNumero = -999999999999999.0R
Me.CnEdicion021.Name = "CnEdicion021"
Me.CnEdicion021.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion021.TabIndex = 9999
Me.CnEdicion021.Tabla = "cabeceras_salida"
'
'CmdGrid021
'
Me.CmdGrid021.Image = CType(Resources.GetObject("CmdGrid021.Image"), System.Drawing.Image)
Me.CmdGrid021.Location = New System.Drawing.Point(155,302)
Me.CmdGrid021.Name = "CmdGrid021"
Me.CmdGrid021.Size = New System.Drawing.Size(24,22)
Me.CmdGrid021.UseVisualStyleBackColor = True
Me.CmdGrid021.Tabindex = 9999
'
'TxtLookup0211
'
Me.TxtLookup0211.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0211.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0211.Location = New System.Drawing.Point(189,305)
Me.TxtLookup0211.Name = "TxtLookup0211"
Me.TxtLookup0211.ReadOnly = True
Me.TxtLookup0211.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0211.Tabindex = 9999
'
'Lbl022
'
Me.Lbl022.AutoSize = True
Me.Lbl022.Location = New System.Drawing.Point(83,325)
Me.Lbl022.Name = "Lbl022"
Me.Lbl022.Size = New System.Drawing.Size(41, 13)
Me.Lbl022.Tabindex = 9999
Me.Lbl022.Text = "Pais:"
'
'TxtDatos022
'
Me.TxtDatos022.Location = New System.Drawing.Point(114,323)
Me.TxtDatos022.Name = "TxtDatos022"
Me.TxtDatos022.ReadOnly = True
Me.TxtDatos022.Size = New System.Drawing.Size(30, 20)
Me.TxtDatos022.Tabindex = 9999
'
'CnEdicion022
'
Me.CnEdicion022.AceptaEspacios = True
Me.CnEdicion022.AceptaMayusculas = True
Me.CnEdicion022.AceptaMayusculasAcentuadas = False
Me.CnEdicion022.AceptaMinusculas = False
Me.CnEdicion022.AceptaMinusculasAcentuadas = False
Me.CnEdicion022.AceptaNumeros = True
Me.CnEdicion022.AceptaSimbolos = True
Me.CnEdicion022.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion022.ConvierteAMayusculas = True
Me.CnEdicion022.ConvierteAMinusculas = False
Me.CnEdicion022.EsFechaHoraCreacion = False
Me.CnEdicion022.EsFechaHoraModificacion = False
Me.CnEdicion022.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion022.ColorFondo = System.Drawing.Color.White
Me.CnEdicion022.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion022.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion022.Campo = "pais_dest"
Me.CnEdicion022.CampoEnlacesLookup1 = "nombre_pais"
Me.CnEdicion022.CampoEnlacesLookup2 = Nothing
Me.CnEdicion022.CampoEnlacesLookup3 = Nothing
Me.CnEdicion022.EdicionEnGrid = False
Me.CnEdicion022.TituloParaGrid = Nothing
Me.CnEdicion022.AnchoColumnaGrid = 0
Me.CnEdicion022.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion022.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion022.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion022.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion022.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion022.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion022.EnCreacionSoloLectura = False
Me.CnEdicion022.EnCreacionOculto = False
Me.CnEdicion022.SiempreSoloLectura = False
Me.CnEdicion022.SiempreOculto = False
Me.CnEdicion022.EnlacesLookup1 = 31180
Me.CnEdicion022.EnlacesLookup2 = 0
Me.CnEdicion022.EnlacesLookup3 = 0
Me.CnEdicion022.EnModificacionSoloLectura = False
Me.CnEdicion022.EnModificacionOculto = False
Me.CnEdicion022.Fuente = Nothing
Me.CnEdicion022.HayMascaraEspecial = False
Me.CnEdicion022.HayValorDefecto = False
Me.CnEdicion022.NumeroParametroValorDefecto = 0
Me.CnEdicion022.ValorDefecto = ""
Me.CnEdicion022.HayValorFijo = False
Me.CnEdicion022.NumeroParametroValorFijo = 0
Me.CnEdicion022.ValorFijo = ""
Me.CnEdicion022.HayValorFijoCreacion = False
Me.CnEdicion022.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion022.ValorFijoCreacion = ""
Me.CnEdicion022.Location = New System.Drawing.Point(118,323)
Me.CnEdicion022.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion022.MascaraEspecial = ""
Me.CnEdicion022.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion022.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion022.MaximoNumero = 999999999999999.0R
Me.CnEdicion022.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion022.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion022.MinimoNumero = -999999999999999.0R
Me.CnEdicion022.Name = "CnEdicion022"
Me.CnEdicion022.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion022.TabIndex = 9999
Me.CnEdicion022.Tabla = "cabeceras_salida"
'
'CmdGrid022
'
Me.CmdGrid022.Image = CType(Resources.GetObject("CmdGrid022.Image"), System.Drawing.Image)
Me.CmdGrid022.Location = New System.Drawing.Point(145,323)
Me.CmdGrid022.Name = "CmdGrid022"
Me.CmdGrid022.Size = New System.Drawing.Size(24,22)
Me.CmdGrid022.UseVisualStyleBackColor = True
Me.CmdGrid022.Tabindex = 9999
'
'TxtLookup0221
'
Me.TxtLookup0221.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0221.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0221.Location = New System.Drawing.Point(179,326)
Me.TxtLookup0221.Name = "TxtLookup0221"
Me.TxtLookup0221.ReadOnly = True
Me.TxtLookup0221.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0221.Tabindex = 9999
'
'Lbl023
'
Me.Lbl023.AutoSize = True
Me.Lbl023.Location = New System.Drawing.Point(31,346)
Me.Lbl023.Name = "Lbl023"
Me.Lbl023.Size = New System.Drawing.Size(41, 13)
Me.Lbl023.Tabindex = 9999
Me.Lbl023.Text = "Observaciones:"
'
'TxtDatos023
'
Me.TxtDatos023.Location = New System.Drawing.Point(114,344)
Me.TxtDatos023.Name = "TxtDatos023"
Me.TxtDatos023.ReadOnly = True
Me.TxtDatos023.Size = New System.Drawing.Size(250, 20)
Me.TxtDatos023.Tabindex = 9999
'
'CnEdicion023
'
Me.CnEdicion023.AceptaEspacios = True
Me.CnEdicion023.AceptaMayusculas = True
Me.CnEdicion023.AceptaMayusculasAcentuadas = False
Me.CnEdicion023.AceptaMinusculas = False
Me.CnEdicion023.AceptaMinusculasAcentuadas = False
Me.CnEdicion023.AceptaNumeros = True
Me.CnEdicion023.AceptaSimbolos = True
Me.CnEdicion023.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion023.ConvierteAMayusculas = True
Me.CnEdicion023.ConvierteAMinusculas = False
Me.CnEdicion023.EsFechaHoraCreacion = False
Me.CnEdicion023.EsFechaHoraModificacion = False
Me.CnEdicion023.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion023.ColorFondo = System.Drawing.Color.White
Me.CnEdicion023.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion023.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion023.Campo = "observaciones"
Me.CnEdicion023.CampoEnlacesLookup1 = Nothing
Me.CnEdicion023.CampoEnlacesLookup2 = Nothing
Me.CnEdicion023.CampoEnlacesLookup3 = Nothing
Me.CnEdicion023.EdicionEnGrid = False
Me.CnEdicion023.TituloParaGrid = Nothing
Me.CnEdicion023.AnchoColumnaGrid = 0
Me.CnEdicion023.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion023.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion023.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion023.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion023.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion023.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion023.EnCreacionSoloLectura = False
Me.CnEdicion023.EnCreacionOculto = False
Me.CnEdicion023.SiempreSoloLectura = False
Me.CnEdicion023.SiempreOculto = False
Me.CnEdicion023.EnlacesLookup1 = 0
Me.CnEdicion023.EnlacesLookup2 = 0
Me.CnEdicion023.EnlacesLookup3 = 0
Me.CnEdicion023.EnModificacionSoloLectura = False
Me.CnEdicion023.EnModificacionOculto = False
Me.CnEdicion023.Fuente = Nothing
Me.CnEdicion023.HayMascaraEspecial = False
Me.CnEdicion023.HayValorDefecto = False
Me.CnEdicion023.NumeroParametroValorDefecto = 0
Me.CnEdicion023.ValorDefecto = ""
Me.CnEdicion023.HayValorFijo = False
Me.CnEdicion023.NumeroParametroValorFijo = 0
Me.CnEdicion023.ValorFijo = ""
Me.CnEdicion023.HayValorFijoCreacion = False
Me.CnEdicion023.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion023.ValorFijoCreacion = ""
Me.CnEdicion023.Location = New System.Drawing.Point(118,344)
Me.CnEdicion023.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion023.MascaraEspecial = ""
Me.CnEdicion023.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion023.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion023.MaximoNumero = 999999999999999.0R
Me.CnEdicion023.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion023.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion023.MinimoNumero = -999999999999999.0R
Me.CnEdicion023.Name = "CnEdicion023"
Me.CnEdicion023.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion023.TabIndex = 9999
Me.CnEdicion023.Tabla = "cabeceras_salida"
'
'Lbl024
'
Me.Lbl024.AutoSize = True
Me.Lbl024.Location = New System.Drawing.Point(74,367)
Me.Lbl024.Name = "Lbl024"
Me.Lbl024.Size = New System.Drawing.Size(41, 13)
Me.Lbl024.Tabindex = 9999
Me.Lbl024.Text = "Divisa:"
'
'TxtDatos024
'
Me.TxtDatos024.Location = New System.Drawing.Point(114,365)
Me.TxtDatos024.Name = "TxtDatos024"
Me.TxtDatos024.ReadOnly = True
Me.TxtDatos024.Size = New System.Drawing.Size(40, 20)
Me.TxtDatos024.Tabindex = 9999
'
'CnEdicion024
'
Me.CnEdicion024.AceptaEspacios = True
Me.CnEdicion024.AceptaMayusculas = True
Me.CnEdicion024.AceptaMayusculasAcentuadas = False
Me.CnEdicion024.AceptaMinusculas = False
Me.CnEdicion024.AceptaMinusculasAcentuadas = False
Me.CnEdicion024.AceptaNumeros = True
Me.CnEdicion024.AceptaSimbolos = True
Me.CnEdicion024.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion024.ConvierteAMayusculas = True
Me.CnEdicion024.ConvierteAMinusculas = False
Me.CnEdicion024.EsFechaHoraCreacion = False
Me.CnEdicion024.EsFechaHoraModificacion = False
Me.CnEdicion024.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion024.ColorFondo = System.Drawing.Color.White
Me.CnEdicion024.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion024.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion024.Campo = "codigo_divisa"
Me.CnEdicion024.CampoEnlacesLookup1 = "nombre_divisa"
Me.CnEdicion024.CampoEnlacesLookup2 = "nombre_divisa"
Me.CnEdicion024.CampoEnlacesLookup3 = Nothing
Me.CnEdicion024.EdicionEnGrid = False
Me.CnEdicion024.TituloParaGrid = Nothing
Me.CnEdicion024.AnchoColumnaGrid = 0
Me.CnEdicion024.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion024.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion024.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion024.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion024.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion024.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion024.EnCreacionSoloLectura = False
Me.CnEdicion024.EnCreacionOculto = False
Me.CnEdicion024.SiempreSoloLectura = False
Me.CnEdicion024.SiempreOculto = False
Me.CnEdicion024.EnlacesLookup1 = 32164
Me.CnEdicion024.EnlacesLookup2 = 31184
Me.CnEdicion024.EnlacesLookup3 = 0
Me.CnEdicion024.EnModificacionSoloLectura = False
Me.CnEdicion024.EnModificacionOculto = False
Me.CnEdicion024.Fuente = Nothing
Me.CnEdicion024.HayMascaraEspecial = False
Me.CnEdicion024.HayValorDefecto = True
Me.CnEdicion024.NumeroParametroValorDefecto = 0
Me.CnEdicion024.ValorDefecto = "EUR"
Me.CnEdicion024.HayValorFijo = False
Me.CnEdicion024.NumeroParametroValorFijo = 0
Me.CnEdicion024.ValorFijo = ""
Me.CnEdicion024.HayValorFijoCreacion = False
Me.CnEdicion024.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion024.ValorFijoCreacion = ""
Me.CnEdicion024.Location = New System.Drawing.Point(118,365)
Me.CnEdicion024.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion024.MascaraEspecial = ""
Me.CnEdicion024.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion024.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion024.MaximoNumero = 999999999999999.0R
Me.CnEdicion024.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion024.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion024.MinimoNumero = -999999999999999.0R
Me.CnEdicion024.Name = "CnEdicion024"
Me.CnEdicion024.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion024.TabIndex = 9999
Me.CnEdicion024.Tabla = "cabeceras_salida"
'
'CmdGrid024
'
Me.CmdGrid024.Image = CType(Resources.GetObject("CmdGrid024.Image"), System.Drawing.Image)
Me.CmdGrid024.Location = New System.Drawing.Point(155,365)
Me.CmdGrid024.Name = "CmdGrid024"
Me.CmdGrid024.Size = New System.Drawing.Size(24,22)
Me.CmdGrid024.UseVisualStyleBackColor = True
Me.CmdGrid024.Tabindex = 9999
'
'TxtLookup0241
'
Me.TxtLookup0241.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0241.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0241.Location = New System.Drawing.Point(189,368)
Me.TxtLookup0241.Name = "TxtLookup0241"
Me.TxtLookup0241.ReadOnly = True
Me.TxtLookup0241.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0241.Tabindex = 9999
'
'TxtLookup0242
'
Me.TxtLookup0242.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0242.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0242.Location = New System.Drawing.Point(388,389)
Me.TxtLookup0242.Name = "TxtLookup0242"
Me.TxtLookup0242.ReadOnly = True
Me.TxtLookup0242.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0242.Tabindex = 9999
'
'Lbl025
'
Me.Lbl025.AutoSize = True
Me.Lbl025.Location = New System.Drawing.Point(37,409)
Me.Lbl025.Name = "Lbl025"
Me.Lbl025.Size = New System.Drawing.Size(41, 13)
Me.Lbl025.Tabindex = 9999
Me.Lbl025.Text = "Cambio divisa:"
'
'TxtDatos025
'
Me.TxtDatos025.Location = New System.Drawing.Point(114,407)
Me.TxtDatos025.Name = "TxtDatos025"
Me.TxtDatos025.ReadOnly = True
Me.TxtDatos025.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos025.Tabindex = 9999
'
'CnEdicion025
'
Me.CnEdicion025.AceptaEspacios = True
Me.CnEdicion025.AceptaMayusculas = True
Me.CnEdicion025.AceptaMayusculasAcentuadas = True
Me.CnEdicion025.AceptaMinusculas = True
Me.CnEdicion025.AceptaMinusculasAcentuadas = True
Me.CnEdicion025.AceptaNumeros = True
Me.CnEdicion025.AceptaSimbolos = False
Me.CnEdicion025.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion025.ConvierteAMayusculas = False
Me.CnEdicion025.ConvierteAMinusculas = False
Me.CnEdicion025.EsFechaHoraCreacion = False
Me.CnEdicion025.EsFechaHoraModificacion = False
Me.CnEdicion025.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion025.ColorFondo = System.Drawing.Color.White
Me.CnEdicion025.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion025.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion025.Campo = "cambio_divisa"
Me.CnEdicion025.CampoEnlacesLookup1 = Nothing
Me.CnEdicion025.CampoEnlacesLookup2 = Nothing
Me.CnEdicion025.CampoEnlacesLookup3 = Nothing
Me.CnEdicion025.EdicionEnGrid = False
Me.CnEdicion025.TituloParaGrid = Nothing
Me.CnEdicion025.AnchoColumnaGrid = 0
Me.CnEdicion025.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion025.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion025.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion025.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion025.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion025.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion025.EnCreacionSoloLectura = False
Me.CnEdicion025.EnCreacionOculto = False
Me.CnEdicion025.SiempreSoloLectura = False
Me.CnEdicion025.SiempreOculto = False
Me.CnEdicion025.EnlacesLookup1 = 0
Me.CnEdicion025.EnlacesLookup2 = 0
Me.CnEdicion025.EnlacesLookup3 = 0
Me.CnEdicion025.EnModificacionSoloLectura = False
Me.CnEdicion025.EnModificacionOculto = False
Me.CnEdicion025.Fuente = Nothing
Me.CnEdicion025.HayMascaraEspecial = False
Me.CnEdicion025.HayValorDefecto = True
Me.CnEdicion025.NumeroParametroValorDefecto = 0
Me.CnEdicion025.ValorDefecto = "1"
Me.CnEdicion025.HayValorFijo = False
Me.CnEdicion025.NumeroParametroValorFijo = 0
Me.CnEdicion025.ValorFijo = ""
Me.CnEdicion025.HayValorFijoCreacion = False
Me.CnEdicion025.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion025.ValorFijoCreacion = ""
Me.CnEdicion025.Location = New System.Drawing.Point(118,407)
Me.CnEdicion025.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion025.MascaraEspecial = ""
Me.CnEdicion025.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion025.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion025.MaximoNumero = 999999999999999.0R
Me.CnEdicion025.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion025.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion025.MinimoNumero = -999999999999999.0R
Me.CnEdicion025.Name = "CnEdicion025"
Me.CnEdicion025.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion025.TabIndex = 9999
Me.CnEdicion025.Tabla = "cabeceras_salida"
'
'Lbl026
'
Me.Lbl026.AutoSize = True
Me.Lbl026.Location = New System.Drawing.Point(40,430)
Me.Lbl026.Name = "Lbl026"
Me.Lbl026.Size = New System.Drawing.Size(41, 13)
Me.Lbl026.Tabindex = 9999
Me.Lbl026.Text = "Orden Carga:"
'
'TxtDatos026
'
Me.TxtDatos026.Location = New System.Drawing.Point(114,428)
Me.TxtDatos026.Name = "TxtDatos026"
Me.TxtDatos026.ReadOnly = True
Me.TxtDatos026.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos026.Tabindex = 9999
'
'CnEdicion026
'
Me.CnEdicion026.AceptaEspacios = True
Me.CnEdicion026.AceptaMayusculas = True
Me.CnEdicion026.AceptaMayusculasAcentuadas = True
Me.CnEdicion026.AceptaMinusculas = True
Me.CnEdicion026.AceptaMinusculasAcentuadas = True
Me.CnEdicion026.AceptaNumeros = True
Me.CnEdicion026.AceptaSimbolos = False
Me.CnEdicion026.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion026.ConvierteAMayusculas = False
Me.CnEdicion026.ConvierteAMinusculas = False
Me.CnEdicion026.EsFechaHoraCreacion = False
Me.CnEdicion026.EsFechaHoraModificacion = False
Me.CnEdicion026.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion026.ColorFondo = System.Drawing.Color.White
Me.CnEdicion026.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion026.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion026.Campo = "orden_carga"
Me.CnEdicion026.CampoEnlacesLookup1 = "fecha_camion"
Me.CnEdicion026.CampoEnlacesLookup2 = Nothing
Me.CnEdicion026.CampoEnlacesLookup3 = Nothing
Me.CnEdicion026.EdicionEnGrid = False
Me.CnEdicion026.TituloParaGrid = Nothing
Me.CnEdicion026.AnchoColumnaGrid = 0
Me.CnEdicion026.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion026.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion026.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion026.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion026.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion026.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion026.EnCreacionSoloLectura = False
Me.CnEdicion026.EnCreacionOculto = False
Me.CnEdicion026.SiempreSoloLectura = False
Me.CnEdicion026.SiempreOculto = False
Me.CnEdicion026.EnlacesLookup1 = 32304
Me.CnEdicion026.EnlacesLookup2 = 0
Me.CnEdicion026.EnlacesLookup3 = 0
Me.CnEdicion026.EnModificacionSoloLectura = False
Me.CnEdicion026.EnModificacionOculto = False
Me.CnEdicion026.Fuente = Nothing
Me.CnEdicion026.HayMascaraEspecial = False
Me.CnEdicion026.HayValorDefecto = False
Me.CnEdicion026.NumeroParametroValorDefecto = 0
Me.CnEdicion026.ValorDefecto = ""
Me.CnEdicion026.HayValorFijo = False
Me.CnEdicion026.NumeroParametroValorFijo = 0
Me.CnEdicion026.ValorFijo = ""
Me.CnEdicion026.HayValorFijoCreacion = False
Me.CnEdicion026.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion026.ValorFijoCreacion = ""
Me.CnEdicion026.Location = New System.Drawing.Point(118,428)
Me.CnEdicion026.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion026.MascaraEspecial = ""
Me.CnEdicion026.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion026.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion026.MaximoNumero = 999999999999999.0R
Me.CnEdicion026.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion026.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion026.MinimoNumero = -999999999999999.0R
Me.CnEdicion026.Name = "CnEdicion026"
Me.CnEdicion026.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion026.TabIndex = 9999
Me.CnEdicion026.Tabla = "cabeceras_salida"
'
'CmdGrid026
'
Me.CmdGrid026.Image = CType(Resources.GetObject("CmdGrid026.Image"), System.Drawing.Image)
Me.CmdGrid026.Location = New System.Drawing.Point(215,428)
Me.CmdGrid026.Name = "CmdGrid026"
Me.CmdGrid026.Size = New System.Drawing.Size(24,22)
Me.CmdGrid026.UseVisualStyleBackColor = True
Me.CmdGrid026.Tabindex = 9999
'
'TxtLookup0261
'
Me.TxtLookup0261.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0261.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0261.Location = New System.Drawing.Point(249,431)
Me.TxtLookup0261.Name = "TxtLookup0261"
Me.TxtLookup0261.ReadOnly = True
Me.TxtLookup0261.Size = New System.Drawing.Size(100, 13)
Me.TxtLookup0261.Tabindex = 9999
'
'Lbl027
'
Me.Lbl027.AutoSize = True
Me.Lbl027.Location = New System.Drawing.Point(9,451)
Me.Lbl027.Name = "Lbl027"
Me.Lbl027.Size = New System.Drawing.Size(41, 13)
Me.Lbl027.Tabindex = 9999
Me.Lbl027.Text = "Importe Prev Trans:"
'
'TxtDatos027
'
Me.TxtDatos027.Location = New System.Drawing.Point(114,449)
Me.TxtDatos027.Name = "TxtDatos027"
Me.TxtDatos027.ReadOnly = True
Me.TxtDatos027.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos027.Tabindex = 9999
'
'CnEdicion027
'
Me.CnEdicion027.AceptaEspacios = True
Me.CnEdicion027.AceptaMayusculas = True
Me.CnEdicion027.AceptaMayusculasAcentuadas = True
Me.CnEdicion027.AceptaMinusculas = True
Me.CnEdicion027.AceptaMinusculasAcentuadas = True
Me.CnEdicion027.AceptaNumeros = True
Me.CnEdicion027.AceptaSimbolos = False
Me.CnEdicion027.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion027.ConvierteAMayusculas = False
Me.CnEdicion027.ConvierteAMinusculas = False
Me.CnEdicion027.EsFechaHoraCreacion = False
Me.CnEdicion027.EsFechaHoraModificacion = False
Me.CnEdicion027.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion027.ColorFondo = System.Drawing.Color.White
Me.CnEdicion027.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion027.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion027.Campo = "importe_prev_trans"
Me.CnEdicion027.CampoEnlacesLookup1 = Nothing
Me.CnEdicion027.CampoEnlacesLookup2 = Nothing
Me.CnEdicion027.CampoEnlacesLookup3 = Nothing
Me.CnEdicion027.EdicionEnGrid = False
Me.CnEdicion027.TituloParaGrid = Nothing
Me.CnEdicion027.AnchoColumnaGrid = 0
Me.CnEdicion027.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion027.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion027.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion027.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion027.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion027.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion027.EnCreacionSoloLectura = False
Me.CnEdicion027.EnCreacionOculto = False
Me.CnEdicion027.SiempreSoloLectura = False
Me.CnEdicion027.SiempreOculto = False
Me.CnEdicion027.EnlacesLookup1 = 0
Me.CnEdicion027.EnlacesLookup2 = 0
Me.CnEdicion027.EnlacesLookup3 = 0
Me.CnEdicion027.EnModificacionSoloLectura = False
Me.CnEdicion027.EnModificacionOculto = False
Me.CnEdicion027.Fuente = Nothing
Me.CnEdicion027.HayMascaraEspecial = False
Me.CnEdicion027.HayValorDefecto = True
Me.CnEdicion027.NumeroParametroValorDefecto = 0
Me.CnEdicion027.ValorDefecto = "0"
Me.CnEdicion027.HayValorFijo = False
Me.CnEdicion027.NumeroParametroValorFijo = 0
Me.CnEdicion027.ValorFijo = ""
Me.CnEdicion027.HayValorFijoCreacion = False
Me.CnEdicion027.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion027.ValorFijoCreacion = ""
Me.CnEdicion027.Location = New System.Drawing.Point(118,449)
Me.CnEdicion027.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion027.MascaraEspecial = ""
Me.CnEdicion027.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion027.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion027.MaximoNumero = 999999999999999.0R
Me.CnEdicion027.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion027.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion027.MinimoNumero = -999999999999999.0R
Me.CnEdicion027.Name = "CnEdicion027"
Me.CnEdicion027.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion027.TabIndex = 9999
Me.CnEdicion027.Tabla = "cabeceras_salida"
'
'Lbl028
'
Me.Lbl028.AutoSize = True
Me.Lbl028.Location = New System.Drawing.Point(10,472)
Me.Lbl028.Name = "Lbl028"
Me.Lbl028.Size = New System.Drawing.Size(41, 13)
Me.Lbl028.Tabindex = 9999
Me.Lbl028.Text = "Importe Real Trans:"
'
'TxtDatos028
'
Me.TxtDatos028.Location = New System.Drawing.Point(114,470)
Me.TxtDatos028.Name = "TxtDatos028"
Me.TxtDatos028.ReadOnly = True
Me.TxtDatos028.Size = New System.Drawing.Size(100, 20)
Me.TxtDatos028.Tabindex = 9999
'
'CnEdicion028
'
Me.CnEdicion028.AceptaEspacios = True
Me.CnEdicion028.AceptaMayusculas = True
Me.CnEdicion028.AceptaMayusculasAcentuadas = True
Me.CnEdicion028.AceptaMinusculas = True
Me.CnEdicion028.AceptaMinusculasAcentuadas = True
Me.CnEdicion028.AceptaNumeros = True
Me.CnEdicion028.AceptaSimbolos = False
Me.CnEdicion028.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion028.ConvierteAMayusculas = False
Me.CnEdicion028.ConvierteAMinusculas = False
Me.CnEdicion028.EsFechaHoraCreacion = False
Me.CnEdicion028.EsFechaHoraModificacion = False
Me.CnEdicion028.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion028.ColorFondo = System.Drawing.Color.White
Me.CnEdicion028.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion028.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion028.Campo = "importe_real_trans"
Me.CnEdicion028.CampoEnlacesLookup1 = Nothing
Me.CnEdicion028.CampoEnlacesLookup2 = Nothing
Me.CnEdicion028.CampoEnlacesLookup3 = Nothing
Me.CnEdicion028.EdicionEnGrid = False
Me.CnEdicion028.TituloParaGrid = Nothing
Me.CnEdicion028.AnchoColumnaGrid = 0
Me.CnEdicion028.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion028.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion028.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion028.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion028.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion028.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion028.EnCreacionSoloLectura = False
Me.CnEdicion028.EnCreacionOculto = False
Me.CnEdicion028.SiempreSoloLectura = False
Me.CnEdicion028.SiempreOculto = False
Me.CnEdicion028.EnlacesLookup1 = 0
Me.CnEdicion028.EnlacesLookup2 = 0
Me.CnEdicion028.EnlacesLookup3 = 0
Me.CnEdicion028.EnModificacionSoloLectura = False
Me.CnEdicion028.EnModificacionOculto = False
Me.CnEdicion028.Fuente = Nothing
Me.CnEdicion028.HayMascaraEspecial = False
Me.CnEdicion028.HayValorDefecto = True
Me.CnEdicion028.NumeroParametroValorDefecto = 0
Me.CnEdicion028.ValorDefecto = "0"
Me.CnEdicion028.HayValorFijo = False
Me.CnEdicion028.NumeroParametroValorFijo = 0
Me.CnEdicion028.ValorFijo = ""
Me.CnEdicion028.HayValorFijoCreacion = False
Me.CnEdicion028.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion028.ValorFijoCreacion = ""
Me.CnEdicion028.Location = New System.Drawing.Point(118,470)
Me.CnEdicion028.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion028.MascaraEspecial = ""
Me.CnEdicion028.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion028.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion028.MaximoNumero = 999999999999999.0R
Me.CnEdicion028.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion028.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion028.MinimoNumero = -999999999999999.0R
Me.CnEdicion028.Name = "CnEdicion028"
Me.CnEdicion028.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion028.TabIndex = 9999
Me.CnEdicion028.Tabla = "cabeceras_salida"
'
'Lbl029
'
Me.Lbl029.AutoSize = True
Me.Lbl029.Location = New System.Drawing.Point(42,493)
Me.Lbl029.Name = "Lbl029"
Me.Lbl029.Size = New System.Drawing.Size(41, 13)
Me.Lbl029.Tabindex = 9999
Me.Lbl029.Text = "Propio Trans:"
'
'TxtDatos029
'
Me.TxtDatos029.Location = New System.Drawing.Point(114,491)
Me.TxtDatos029.Name = "TxtDatos029"
Me.TxtDatos029.ReadOnly = True
Me.TxtDatos029.Size = New System.Drawing.Size(20, 20)
Me.TxtDatos029.Tabindex = 9999
'
'CnEdicion029
'
Me.CnEdicion029.AceptaEspacios = True
Me.CnEdicion029.AceptaMayusculas = True
Me.CnEdicion029.AceptaMayusculasAcentuadas = False
Me.CnEdicion029.AceptaMinusculas = False
Me.CnEdicion029.AceptaMinusculasAcentuadas = False
Me.CnEdicion029.AceptaNumeros = True
Me.CnEdicion029.AceptaSimbolos = True
Me.CnEdicion029.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion029.ConvierteAMayusculas = True
Me.CnEdicion029.ConvierteAMinusculas = False
Me.CnEdicion029.EsFechaHoraCreacion = False
Me.CnEdicion029.EsFechaHoraModificacion = False
Me.CnEdicion029.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion029.ColorFondo = System.Drawing.Color.White
Me.CnEdicion029.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion029.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion029.Campo = "propio_trans"
Me.CnEdicion029.CampoEnlacesLookup1 = Nothing
Me.CnEdicion029.CampoEnlacesLookup2 = Nothing
Me.CnEdicion029.CampoEnlacesLookup3 = Nothing
Me.CnEdicion029.EdicionEnGrid = False
Me.CnEdicion029.TituloParaGrid = Nothing
Me.CnEdicion029.AnchoColumnaGrid = 0
Me.CnEdicion029.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion029.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion029.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion029.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion029.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion029.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion029.EnCreacionSoloLectura = False
Me.CnEdicion029.EnCreacionOculto = False
Me.CnEdicion029.SiempreSoloLectura = False
Me.CnEdicion029.SiempreOculto = False
Me.CnEdicion029.EnlacesLookup1 = 0
Me.CnEdicion029.EnlacesLookup2 = 0
Me.CnEdicion029.EnlacesLookup3 = 0
Me.CnEdicion029.EnModificacionSoloLectura = False
Me.CnEdicion029.EnModificacionOculto = False
Me.CnEdicion029.Fuente = Nothing
Me.CnEdicion029.HayMascaraEspecial = False
Me.CnEdicion029.HayValorDefecto = True
Me.CnEdicion029.NumeroParametroValorDefecto = 0
Me.CnEdicion029.ValorDefecto = "N"
Me.CnEdicion029.HayValorFijo = False
Me.CnEdicion029.NumeroParametroValorFijo = 0
Me.CnEdicion029.ValorFijo = ""
Me.CnEdicion029.HayValorFijoCreacion = False
Me.CnEdicion029.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion029.ValorFijoCreacion = ""
Me.CnEdicion029.Location = New System.Drawing.Point(118,491)
Me.CnEdicion029.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion029.MascaraEspecial = ""
Me.CnEdicion029.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion029.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion029.MaximoNumero = 999999999999999.0R
Me.CnEdicion029.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion029.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion029.MinimoNumero = -999999999999999.0R
Me.CnEdicion029.Name = "CnEdicion029"
Me.CnEdicion029.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion029.TabIndex = 9999
Me.CnEdicion029.Tabla = "cabeceras_salida"
'
'Lbl030
'
Me.Lbl030.AutoSize = True
Me.Lbl030.Location = New System.Drawing.Point(29,514)
Me.Lbl030.Name = "Lbl030"
Me.Lbl030.Size = New System.Drawing.Size(41, 13)
Me.Lbl030.Tabindex = 9999
Me.Lbl030.Text = "Situacion Trans:"
'
'TxtDatos030
'
Me.TxtDatos030.Location = New System.Drawing.Point(114,512)
Me.TxtDatos030.Name = "TxtDatos030"
Me.TxtDatos030.ReadOnly = True
Me.TxtDatos030.Size = New System.Drawing.Size(20, 20)
Me.TxtDatos030.Tabindex = 9999
'
'CnEdicion030
'
Me.CnEdicion030.AceptaEspacios = True
Me.CnEdicion030.AceptaMayusculas = True
Me.CnEdicion030.AceptaMayusculasAcentuadas = False
Me.CnEdicion030.AceptaMinusculas = False
Me.CnEdicion030.AceptaMinusculasAcentuadas = False
Me.CnEdicion030.AceptaNumeros = True
Me.CnEdicion030.AceptaSimbolos = True
Me.CnEdicion030.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion030.ConvierteAMayusculas = True
Me.CnEdicion030.ConvierteAMinusculas = False
Me.CnEdicion030.EsFechaHoraCreacion = False
Me.CnEdicion030.EsFechaHoraModificacion = False
Me.CnEdicion030.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion030.ColorFondo = System.Drawing.Color.White
Me.CnEdicion030.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion030.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion030.Campo = "situacion_trans"
Me.CnEdicion030.CampoEnlacesLookup1 = Nothing
Me.CnEdicion030.CampoEnlacesLookup2 = Nothing
Me.CnEdicion030.CampoEnlacesLookup3 = Nothing
Me.CnEdicion030.EdicionEnGrid = False
Me.CnEdicion030.TituloParaGrid = Nothing
Me.CnEdicion030.AnchoColumnaGrid = 0
Me.CnEdicion030.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion030.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion030.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion030.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion030.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion030.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion030.EnCreacionSoloLectura = False
Me.CnEdicion030.EnCreacionOculto = False
Me.CnEdicion030.SiempreSoloLectura = False
Me.CnEdicion030.SiempreOculto = False
Me.CnEdicion030.EnlacesLookup1 = 0
Me.CnEdicion030.EnlacesLookup2 = 0
Me.CnEdicion030.EnlacesLookup3 = 0
Me.CnEdicion030.EnModificacionSoloLectura = False
Me.CnEdicion030.EnModificacionOculto = False
Me.CnEdicion030.Fuente = Nothing
Me.CnEdicion030.HayMascaraEspecial = False
Me.CnEdicion030.HayValorDefecto = True
Me.CnEdicion030.NumeroParametroValorDefecto = 0
Me.CnEdicion030.ValorDefecto = "N"
Me.CnEdicion030.HayValorFijo = False
Me.CnEdicion030.NumeroParametroValorFijo = 0
Me.CnEdicion030.ValorFijo = ""
Me.CnEdicion030.HayValorFijoCreacion = False
Me.CnEdicion030.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion030.ValorFijoCreacion = ""
Me.CnEdicion030.Location = New System.Drawing.Point(118,512)
Me.CnEdicion030.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion030.MascaraEspecial = ""
Me.CnEdicion030.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion030.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion030.MaximoNumero = 999999999999999.0R
Me.CnEdicion030.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion030.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion030.MinimoNumero = -999999999999999.0R
Me.CnEdicion030.Name = "CnEdicion030"
Me.CnEdicion030.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion030.TabIndex = 9999
Me.CnEdicion030.Tabla = "cabeceras_salida"
'
'Lbl031
'
Me.Lbl031.AutoSize = True
Me.Lbl031.Location = New System.Drawing.Point(59,535)
Me.Lbl031.Name = "Lbl031"
Me.Lbl031.Size = New System.Drawing.Size(41, 13)
Me.Lbl031.Tabindex = 9999
Me.Lbl031.Text = "Situación:"
'
'TxtDatos031
'
Me.TxtDatos031.Location = New System.Drawing.Point(114,533)
Me.TxtDatos031.Name = "TxtDatos031"
Me.TxtDatos031.ReadOnly = True
Me.TxtDatos031.Size = New System.Drawing.Size(88, 20)
Me.TxtDatos031.Tabindex = 9999
'
'CnEdicion031
'
Me.CnEdicion031.AceptaEspacios = True
Me.CnEdicion031.AceptaMayusculas = True
Me.CnEdicion031.AceptaMayusculasAcentuadas = False
Me.CnEdicion031.AceptaMinusculas = False
Me.CnEdicion031.AceptaMinusculasAcentuadas = False
Me.CnEdicion031.AceptaNumeros = True
Me.CnEdicion031.AceptaSimbolos = True
Me.CnEdicion031.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion031.ConvierteAMayusculas = True
Me.CnEdicion031.ConvierteAMinusculas = False
Me.CnEdicion031.EsFechaHoraCreacion = False
Me.CnEdicion031.EsFechaHoraModificacion = False
Me.CnEdicion031.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion031.ColorFondo = System.Drawing.Color.White
Me.CnEdicion031.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion031.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion031.Campo = "situacion"
Me.CnEdicion031.CampoEnlacesLookup1 = Nothing
Me.CnEdicion031.CampoEnlacesLookup2 = Nothing
Me.CnEdicion031.CampoEnlacesLookup3 = Nothing
Me.CnEdicion031.EdicionEnGrid = False
Me.CnEdicion031.TituloParaGrid = Nothing
Me.CnEdicion031.AnchoColumnaGrid = 0
Me.CnEdicion031.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion031.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion031.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion031.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion031.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion031.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion031.EnCreacionSoloLectura = False
Me.CnEdicion031.EnCreacionOculto = False
Me.CnEdicion031.SiempreSoloLectura = False
Me.CnEdicion031.SiempreOculto = False
Me.CnEdicion031.EnlacesLookup1 = 0
Me.CnEdicion031.EnlacesLookup2 = 0
Me.CnEdicion031.EnlacesLookup3 = 0
Me.CnEdicion031.EnModificacionSoloLectura = False
Me.CnEdicion031.EnModificacionOculto = False
Me.CnEdicion031.Fuente = Nothing
Me.CnEdicion031.HayMascaraEspecial = False
Me.CnEdicion031.HayValorDefecto = True
Me.CnEdicion031.NumeroParametroValorDefecto = 0
Me.CnEdicion031.ValorDefecto = "N"
Me.CnEdicion031.HayValorFijo = False
Me.CnEdicion031.NumeroParametroValorFijo = 0
Me.CnEdicion031.ValorFijo = ""
Me.CnEdicion031.HayValorFijoCreacion = False
Me.CnEdicion031.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion031.ValorFijoCreacion = ""
Me.CnEdicion031.Location = New System.Drawing.Point(118,533)
Me.CnEdicion031.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion031.MascaraEspecial = ""
Me.CnEdicion031.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion031.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion031.MaximoNumero = 999999999999999.0R
Me.CnEdicion031.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion031.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion031.MinimoNumero = -999999999999999.0R
Me.CnEdicion031.Name = "CnEdicion031"
Me.CnEdicion031.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion031.TabIndex = 9999
Me.CnEdicion031.Tabla = "cabeceras_salida"
Me.TabPage00.Text = "cabeceras_salida"
'
'TabPage01
'
Me.TabPage01.Controls.Add(Me.CnEdicion063)
Me.TabPage01.Controls.Add(Me.TxtDatos063)
Me.TabPage01.Controls.Add(Me.Lbl063)
Me.TabPage01.Controls.Add(Me.CnEdicion062)
Me.TabPage01.Controls.Add(Me.TxtDatos062)
Me.TabPage01.Controls.Add(Me.Lbl062)
Me.TabPage01.Controls.Add(Me.CmdCombo061)
Me.TabPage01.Controls.Add(Me.CnEdicion061)
Me.TabPage01.Controls.Add(Me.TxtDatos061)
Me.TabPage01.Controls.Add(Me.Lbl061)
Me.TabPage01.Controls.Add(Me.TxtLookup0601)
Me.TabPage01.Controls.Add(Me.CmdGrid060)
Me.TabPage01.Controls.Add(Me.CnEdicion060)
Me.TabPage01.Controls.Add(Me.TxtDatos060)
Me.TabPage01.Controls.Add(Me.Lbl060)
Me.TabPage01.Controls.Add(Me.TxtLookup0591)
Me.TabPage01.Controls.Add(Me.CmdGrid059)
Me.TabPage01.Controls.Add(Me.CnEdicion059)
Me.TabPage01.Controls.Add(Me.TxtDatos059)
Me.TabPage01.Controls.Add(Me.Lbl059)
Me.TabPage01.Controls.Add(Me.TxtLookup0581)
Me.TabPage01.Controls.Add(Me.CmdGrid058)
Me.TabPage01.Controls.Add(Me.CnEdicion058)
Me.TabPage01.Controls.Add(Me.TxtDatos058)
Me.TabPage01.Controls.Add(Me.Lbl058)
Me.TabPage01.Controls.Add(Me.CnEdicion057)
Me.TabPage01.Controls.Add(Me.CnEdicion056)
Me.TabPage01.Controls.Add(Me.CnEdicion055)
Me.TabPage01.Controls.Add(Me.CnEdicion054)
Me.TabPage01.Controls.Add(Me.CnEdicion053)
Me.TabPage01.Controls.Add(Me.CnEdicion052)
Me.TabPage01.Controls.Add(Me.CnEdicion051)
Me.TabPage01.Controls.Add(Me.CnEdicion050)
Me.TabPage01.Controls.Add(Me.CnEdicion049)
Me.TabPage01.Controls.Add(Me.CnEdicion048)
Me.TabPage01.Controls.Add(Me.CnEdicion047)
Me.TabPage01.Controls.Add(Me.CnEdicion046)
Me.TabPage01.Controls.Add(Me.CnEdicion045)
Me.TabPage01.Controls.Add(Me.CnEdicion044)
Me.TabPage01.Controls.Add(Me.GridTabla02)
Me.TabPage01.Location = New System.Drawing.Point(4, 4)
Me.TabPage01.Name = "TabPage01"
Me.TabPage01.Size = New System.Drawing.Size(1172, 765)
Me.TabPage01.TabIndex = 9
Me.TabPage01.Text = "1"
Me.TabPage01.UseVisualStyleBackColor = True
Me.Tabpage01.CausesValidation = False
'
'GridTabla02
'
Me.GridTabla02.Size = New System.Drawing.Size(1160, 320)
Me.GridTabla02.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) Or System.Windows.Forms.AnchorStyles.Left) Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
Me.GridTabla02.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
Me.GridTabla02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
Me.GridTabla02.DefaultCellStyle = DataGridViewCellStyle2
Me.GridTabla02.Location = New System.Drawing.Point(2, 12)
Me.GridTabla02.MultiSelect = False
Me.GridTabla02.Name = "GridTabla02"
Me.GridTabla02.ReadOnly = True
DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
Me.GridTabla02.TabIndex = 9999
Me.GridTabla02.TabStop = False
'
'CnEdicion044
'
Me.CnEdicion044.AceptaEspacios = True
Me.CnEdicion044.AceptaMayusculas = True
Me.CnEdicion044.AceptaMayusculasAcentuadas = True
Me.CnEdicion044.AceptaMinusculas = True
Me.CnEdicion044.AceptaMinusculasAcentuadas = True
Me.CnEdicion044.AceptaNumeros = True
Me.CnEdicion044.AceptaSimbolos = False
Me.CnEdicion044.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion044.ConvierteAMayusculas = False
Me.CnEdicion044.ConvierteAMinusculas = False
Me.CnEdicion044.EsFechaHoraCreacion = False
Me.CnEdicion044.EsFechaHoraModificacion = False
Me.CnEdicion044.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion044.ColorFondo = System.Drawing.Color.White
Me.CnEdicion044.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion044.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion044.Campo = "numero_linea"
Me.CnEdicion044.CampoEnlacesLookup1 = Nothing
Me.CnEdicion044.CampoEnlacesLookup2 = Nothing
Me.CnEdicion044.CampoEnlacesLookup3 = Nothing
Me.CnEdicion044.EdicionEnGrid = True
Me.CnEdicion044.TituloParaGrid = "Línea"
Me.CnEdicion044.AnchoColumnaGrid = 100
Me.CnEdicion044.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion044.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion044.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion044.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion044.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion044.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion044.EnCreacionSoloLectura = False
Me.CnEdicion044.EnCreacionOculto = False
Me.CnEdicion044.SiempreSoloLectura = False
Me.CnEdicion044.SiempreOculto = False
Me.CnEdicion044.EnlacesLookup1 = 0
Me.CnEdicion044.EnlacesLookup2 = 0
Me.CnEdicion044.EnlacesLookup3 = 0
Me.CnEdicion044.EnModificacionSoloLectura = False
Me.CnEdicion044.EnModificacionOculto = False
Me.CnEdicion044.Fuente = Nothing
Me.CnEdicion044.HayMascaraEspecial = False
Me.CnEdicion044.HayValorDefecto = False
Me.CnEdicion044.NumeroParametroValorDefecto = 0
Me.CnEdicion044.ValorDefecto = ""
Me.CnEdicion044.HayValorFijo = False
Me.CnEdicion044.NumeroParametroValorFijo = 0
Me.CnEdicion044.ValorFijo = ""
Me.CnEdicion044.HayValorFijoCreacion = False
Me.CnEdicion044.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion044.ValorFijoCreacion = ""
Me.CnEdicion044.Location = New System.Drawing.Point(5,98)
Me.CnEdicion044.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion044.MascaraEspecial = ""
Me.CnEdicion044.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion044.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion044.MaximoNumero = 999999999999999.0R
Me.CnEdicion044.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion044.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion044.MinimoNumero = -999999999999999.0R
Me.CnEdicion044.Name = "CnEdicion044"
Me.CnEdicion044.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion044.TabIndex = 9999
Me.CnEdicion044.Tabla = "lineas_salida"
'
'CnEdicion045
'
Me.CnEdicion045.AceptaEspacios = True
Me.CnEdicion045.AceptaMayusculas = True
Me.CnEdicion045.AceptaMayusculasAcentuadas = False
Me.CnEdicion045.AceptaMinusculas = False
Me.CnEdicion045.AceptaMinusculasAcentuadas = False
Me.CnEdicion045.AceptaNumeros = True
Me.CnEdicion045.AceptaSimbolos = True
Me.CnEdicion045.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion045.ConvierteAMayusculas = True
Me.CnEdicion045.ConvierteAMinusculas = False
Me.CnEdicion045.EsFechaHoraCreacion = False
Me.CnEdicion045.EsFechaHoraModificacion = False
Me.CnEdicion045.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion045.ColorFondo = System.Drawing.Color.White
Me.CnEdicion045.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion045.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion045.Campo = "tipo_palet_sal"
Me.CnEdicion045.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion045.CampoEnlacesLookup2 = Nothing
Me.CnEdicion045.CampoEnlacesLookup3 = Nothing
Me.CnEdicion045.EdicionEnGrid = True
Me.CnEdicion045.TituloParaGrid = "Tipo palet"
Me.CnEdicion045.AnchoColumnaGrid = 96
Me.CnEdicion045.TituloGridEnlaceLookup1 = "Descripción"
Me.CnEdicion045.AnchoColumnaGridEnlaceLookup1 = 250
Me.CnEdicion045.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion045.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion045.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion045.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion045.EnCreacionSoloLectura = False
Me.CnEdicion045.EnCreacionOculto = False
Me.CnEdicion045.SiempreSoloLectura = False
Me.CnEdicion045.SiempreOculto = False
Me.CnEdicion045.EnlacesLookup1 = 31693
Me.CnEdicion045.EnlacesLookup2 = 0
Me.CnEdicion045.EnlacesLookup3 = 0
Me.CnEdicion045.EnModificacionSoloLectura = False
Me.CnEdicion045.EnModificacionOculto = False
Me.CnEdicion045.Fuente = Nothing
Me.CnEdicion045.HayMascaraEspecial = False
Me.CnEdicion045.HayValorDefecto = False
Me.CnEdicion045.NumeroParametroValorDefecto = 0
Me.CnEdicion045.ValorDefecto = ""
Me.CnEdicion045.HayValorFijo = False
Me.CnEdicion045.NumeroParametroValorFijo = 0
Me.CnEdicion045.ValorFijo = ""
Me.CnEdicion045.HayValorFijoCreacion = False
Me.CnEdicion045.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion045.ValorFijoCreacion = ""
Me.CnEdicion045.Location = New System.Drawing.Point(40,98)
Me.CnEdicion045.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion045.MascaraEspecial = ""
Me.CnEdicion045.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion045.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion045.MaximoNumero = 999999999999999.0R
Me.CnEdicion045.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion045.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion045.MinimoNumero = -999999999999999.0R
Me.CnEdicion045.Name = "CnEdicion045"
Me.CnEdicion045.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion045.TabIndex = 9999
Me.CnEdicion045.Tabla = "lineas_salida"
'
'CnEdicion046
'
Me.CnEdicion046.AceptaEspacios = True
Me.CnEdicion046.AceptaMayusculas = True
Me.CnEdicion046.AceptaMayusculasAcentuadas = False
Me.CnEdicion046.AceptaMinusculas = False
Me.CnEdicion046.AceptaMinusculasAcentuadas = False
Me.CnEdicion046.AceptaNumeros = True
Me.CnEdicion046.AceptaSimbolos = True
Me.CnEdicion046.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion046.ConvierteAMayusculas = True
Me.CnEdicion046.ConvierteAMinusculas = False
Me.CnEdicion046.EsFechaHoraCreacion = False
Me.CnEdicion046.EsFechaHoraModificacion = False
Me.CnEdicion046.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion046.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion046.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion046.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion046.Campo = "empresa"
Me.CnEdicion046.CampoEnlacesLookup1 = Nothing
Me.CnEdicion046.CampoEnlacesLookup2 = Nothing
Me.CnEdicion046.CampoEnlacesLookup3 = Nothing
Me.CnEdicion046.EdicionEnGrid = True
Me.CnEdicion046.TituloParaGrid = "Empresa"
Me.CnEdicion046.AnchoColumnaGrid = 58
Me.CnEdicion046.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion046.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion046.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion046.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion046.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion046.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion046.EnCreacionSoloLectura = False
Me.CnEdicion046.EnCreacionOculto = False
Me.CnEdicion046.SiempreSoloLectura = False
Me.CnEdicion046.SiempreOculto = False
Me.CnEdicion046.EnlacesLookup1 = 0
Me.CnEdicion046.EnlacesLookup2 = 0
Me.CnEdicion046.EnlacesLookup3 = 0
Me.CnEdicion046.EnModificacionSoloLectura = False
Me.CnEdicion046.EnModificacionOculto = False
Me.CnEdicion046.Fuente = Nothing
Me.CnEdicion046.HayMascaraEspecial = False
Me.CnEdicion046.HayValorDefecto = False
Me.CnEdicion046.NumeroParametroValorDefecto = 0
Me.CnEdicion046.ValorDefecto = ""
Me.CnEdicion046.HayValorFijo = True
Me.CnEdicion046.NumeroParametroValorFijo = 1
Me.CnEdicion046.ValorFijo = ""
Me.CnEdicion046.HayValorFijoCreacion = False
Me.CnEdicion046.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion046.ValorFijoCreacion = ""
Me.CnEdicion046.Location = New System.Drawing.Point(880,12)
Me.CnEdicion046.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion046.MascaraEspecial = ""
Me.CnEdicion046.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion046.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion046.MaximoNumero = 999999999999999.0R
Me.CnEdicion046.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion046.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion046.MinimoNumero = -999999999999999.0R
Me.CnEdicion046.Name = "CnEdicion046"
Me.CnEdicion046.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion046.TabIndex = 9999
Me.CnEdicion046.Tabla = "lineas_salida"
'
'CnEdicion047
'
Me.CnEdicion047.AceptaEspacios = True
Me.CnEdicion047.AceptaMayusculas = True
Me.CnEdicion047.AceptaMayusculasAcentuadas = False
Me.CnEdicion047.AceptaMinusculas = False
Me.CnEdicion047.AceptaMinusculasAcentuadas = False
Me.CnEdicion047.AceptaNumeros = True
Me.CnEdicion047.AceptaSimbolos = True
Me.CnEdicion047.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion047.ConvierteAMayusculas = True
Me.CnEdicion047.ConvierteAMinusculas = False
Me.CnEdicion047.EsFechaHoraCreacion = False
Me.CnEdicion047.EsFechaHoraModificacion = False
Me.CnEdicion047.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion047.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion047.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion047.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion047.Campo = "ejercicio"
Me.CnEdicion047.CampoEnlacesLookup1 = Nothing
Me.CnEdicion047.CampoEnlacesLookup2 = Nothing
Me.CnEdicion047.CampoEnlacesLookup3 = Nothing
Me.CnEdicion047.EdicionEnGrid = True
Me.CnEdicion047.TituloParaGrid = "Ejercicio"
Me.CnEdicion047.AnchoColumnaGrid = 55
Me.CnEdicion047.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion047.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion047.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion047.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion047.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion047.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion047.EnCreacionSoloLectura = False
Me.CnEdicion047.EnCreacionOculto = False
Me.CnEdicion047.SiempreSoloLectura = False
Me.CnEdicion047.SiempreOculto = False
Me.CnEdicion047.EnlacesLookup1 = 0
Me.CnEdicion047.EnlacesLookup2 = 0
Me.CnEdicion047.EnlacesLookup3 = 0
Me.CnEdicion047.EnModificacionSoloLectura = False
Me.CnEdicion047.EnModificacionOculto = False
Me.CnEdicion047.Fuente = Nothing
Me.CnEdicion047.HayMascaraEspecial = False
Me.CnEdicion047.HayValorDefecto = False
Me.CnEdicion047.NumeroParametroValorDefecto = 0
Me.CnEdicion047.ValorDefecto = ""
Me.CnEdicion047.HayValorFijo = True
Me.CnEdicion047.NumeroParametroValorFijo = 3
Me.CnEdicion047.ValorFijo = ""
Me.CnEdicion047.HayValorFijoCreacion = False
Me.CnEdicion047.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion047.ValorFijoCreacion = ""
Me.CnEdicion047.Location = New System.Drawing.Point(930,12)
Me.CnEdicion047.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion047.MascaraEspecial = ""
Me.CnEdicion047.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion047.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion047.MaximoNumero = 999999999999999.0R
Me.CnEdicion047.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion047.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion047.MinimoNumero = -999999999999999.0R
Me.CnEdicion047.Name = "CnEdicion047"
Me.CnEdicion047.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion047.TabIndex = 9999
Me.CnEdicion047.Tabla = "lineas_salida"
'
'CnEdicion048
'
Me.CnEdicion048.AceptaEspacios = True
Me.CnEdicion048.AceptaMayusculas = True
Me.CnEdicion048.AceptaMayusculasAcentuadas = False
Me.CnEdicion048.AceptaMinusculas = False
Me.CnEdicion048.AceptaMinusculasAcentuadas = False
Me.CnEdicion048.AceptaNumeros = True
Me.CnEdicion048.AceptaSimbolos = True
Me.CnEdicion048.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion048.ConvierteAMayusculas = True
Me.CnEdicion048.ConvierteAMinusculas = False
Me.CnEdicion048.EsFechaHoraCreacion = False
Me.CnEdicion048.EsFechaHoraModificacion = False
Me.CnEdicion048.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion048.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion048.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion048.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion048.Campo = "serie"
Me.CnEdicion048.CampoEnlacesLookup1 = Nothing
Me.CnEdicion048.CampoEnlacesLookup2 = Nothing
Me.CnEdicion048.CampoEnlacesLookup3 = Nothing
Me.CnEdicion048.EdicionEnGrid = True
Me.CnEdicion048.TituloParaGrid = "Serie"
Me.CnEdicion048.AnchoColumnaGrid = 40
Me.CnEdicion048.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion048.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion048.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion048.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion048.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion048.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion048.EnCreacionSoloLectura = False
Me.CnEdicion048.EnCreacionOculto = False
Me.CnEdicion048.SiempreSoloLectura = False
Me.CnEdicion048.SiempreOculto = False
Me.CnEdicion048.EnlacesLookup1 = 0
Me.CnEdicion048.EnlacesLookup2 = 0
Me.CnEdicion048.EnlacesLookup3 = 0
Me.CnEdicion048.EnModificacionSoloLectura = False
Me.CnEdicion048.EnModificacionOculto = False
Me.CnEdicion048.Fuente = Nothing
Me.CnEdicion048.HayMascaraEspecial = False
Me.CnEdicion048.HayValorDefecto = False
Me.CnEdicion048.NumeroParametroValorDefecto = 0
Me.CnEdicion048.ValorDefecto = ""
Me.CnEdicion048.HayValorFijo = False
Me.CnEdicion048.NumeroParametroValorFijo = 0
Me.CnEdicion048.ValorFijo = ""
Me.CnEdicion048.HayValorFijoCreacion = False
Me.CnEdicion048.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion048.ValorFijoCreacion = ""
Me.CnEdicion048.Location = New System.Drawing.Point(980,12)
Me.CnEdicion048.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion048.MascaraEspecial = ""
Me.CnEdicion048.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion048.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion048.MaximoNumero = 999999999999999.0R
Me.CnEdicion048.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion048.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion048.MinimoNumero = -999999999999999.0R
Me.CnEdicion048.Name = "CnEdicion048"
Me.CnEdicion048.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion048.TabIndex = 9999
Me.CnEdicion048.Tabla = "lineas_salida"
'
'CnEdicion049
'
Me.CnEdicion049.AceptaEspacios = True
Me.CnEdicion049.AceptaMayusculas = True
Me.CnEdicion049.AceptaMayusculasAcentuadas = False
Me.CnEdicion049.AceptaMinusculas = False
Me.CnEdicion049.AceptaMinusculasAcentuadas = False
Me.CnEdicion049.AceptaNumeros = True
Me.CnEdicion049.AceptaSimbolos = True
Me.CnEdicion049.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion049.ConvierteAMayusculas = True
Me.CnEdicion049.ConvierteAMinusculas = False
Me.CnEdicion049.EsFechaHoraCreacion = False
Me.CnEdicion049.EsFechaHoraModificacion = False
Me.CnEdicion049.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion049.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion049.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion049.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion049.Campo = "tipo_documento"
Me.CnEdicion049.CampoEnlacesLookup1 = Nothing
Me.CnEdicion049.CampoEnlacesLookup2 = Nothing
Me.CnEdicion049.CampoEnlacesLookup3 = Nothing
Me.CnEdicion049.EdicionEnGrid = True
Me.CnEdicion049.TituloParaGrid = "Tipo documento"
Me.CnEdicion049.AnchoColumnaGrid = 100
Me.CnEdicion049.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion049.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion049.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion049.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion049.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion049.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion049.EnCreacionSoloLectura = False
Me.CnEdicion049.EnCreacionOculto = False
Me.CnEdicion049.SiempreSoloLectura = False
Me.CnEdicion049.SiempreOculto = False
Me.CnEdicion049.EnlacesLookup1 = 0
Me.CnEdicion049.EnlacesLookup2 = 0
Me.CnEdicion049.EnlacesLookup3 = 0
Me.CnEdicion049.EnModificacionSoloLectura = False
Me.CnEdicion049.EnModificacionOculto = False
Me.CnEdicion049.Fuente = Nothing
Me.CnEdicion049.HayMascaraEspecial = False
Me.CnEdicion049.HayValorDefecto = False
Me.CnEdicion049.NumeroParametroValorDefecto = 0
Me.CnEdicion049.ValorDefecto = ""
Me.CnEdicion049.HayValorFijo = False
Me.CnEdicion049.NumeroParametroValorFijo = 0
Me.CnEdicion049.ValorFijo = ""
Me.CnEdicion049.HayValorFijoCreacion = False
Me.CnEdicion049.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion049.ValorFijoCreacion = ""
Me.CnEdicion049.Location = New System.Drawing.Point(1030,12)
Me.CnEdicion049.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion049.MascaraEspecial = ""
Me.CnEdicion049.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion049.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion049.MaximoNumero = 999999999999999.0R
Me.CnEdicion049.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion049.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion049.MinimoNumero = -999999999999999.0R
Me.CnEdicion049.Name = "CnEdicion049"
Me.CnEdicion049.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion049.TabIndex = 9999
Me.CnEdicion049.Tabla = "lineas_salida"
'
'CnEdicion050
'
Me.CnEdicion050.AceptaEspacios = True
Me.CnEdicion050.AceptaMayusculas = True
Me.CnEdicion050.AceptaMayusculasAcentuadas = False
Me.CnEdicion050.AceptaMinusculas = False
Me.CnEdicion050.AceptaMinusculasAcentuadas = False
Me.CnEdicion050.AceptaNumeros = True
Me.CnEdicion050.AceptaSimbolos = True
Me.CnEdicion050.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion050.ConvierteAMayusculas = True
Me.CnEdicion050.ConvierteAMinusculas = False
Me.CnEdicion050.EsFechaHoraCreacion = False
Me.CnEdicion050.EsFechaHoraModificacion = False
Me.CnEdicion050.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion050.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion050.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion050.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion050.Campo = "numero_documento"
Me.CnEdicion050.CampoEnlacesLookup1 = Nothing
Me.CnEdicion050.CampoEnlacesLookup2 = Nothing
Me.CnEdicion050.CampoEnlacesLookup3 = Nothing
Me.CnEdicion050.EdicionEnGrid = True
Me.CnEdicion050.TituloParaGrid = "Núm.documento"
Me.CnEdicion050.AnchoColumnaGrid = 102
Me.CnEdicion050.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion050.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion050.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion050.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion050.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion050.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion050.EnCreacionSoloLectura = False
Me.CnEdicion050.EnCreacionOculto = False
Me.CnEdicion050.SiempreSoloLectura = False
Me.CnEdicion050.SiempreOculto = False
Me.CnEdicion050.EnlacesLookup1 = 0
Me.CnEdicion050.EnlacesLookup2 = 0
Me.CnEdicion050.EnlacesLookup3 = 0
Me.CnEdicion050.EnModificacionSoloLectura = False
Me.CnEdicion050.EnModificacionOculto = False
Me.CnEdicion050.Fuente = Nothing
Me.CnEdicion050.HayMascaraEspecial = False
Me.CnEdicion050.HayValorDefecto = False
Me.CnEdicion050.NumeroParametroValorDefecto = 0
Me.CnEdicion050.ValorDefecto = ""
Me.CnEdicion050.HayValorFijo = False
Me.CnEdicion050.NumeroParametroValorFijo = 0
Me.CnEdicion050.ValorFijo = ""
Me.CnEdicion050.HayValorFijoCreacion = False
Me.CnEdicion050.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion050.ValorFijoCreacion = ""
Me.CnEdicion050.Location = New System.Drawing.Point(1080,12)
Me.CnEdicion050.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion050.MascaraEspecial = ""
Me.CnEdicion050.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion050.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion050.MaximoNumero = 999999999999999.0R
Me.CnEdicion050.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion050.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion050.MinimoNumero = -999999999999999.0R
Me.CnEdicion050.Name = "CnEdicion050"
Me.CnEdicion050.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion050.TabIndex = 9999
Me.CnEdicion050.Tabla = "lineas_salida"
'
'CnEdicion051
'
Me.CnEdicion051.AceptaEspacios = True
Me.CnEdicion051.AceptaMayusculas = True
Me.CnEdicion051.AceptaMayusculasAcentuadas = True
Me.CnEdicion051.AceptaMinusculas = True
Me.CnEdicion051.AceptaMinusculasAcentuadas = True
Me.CnEdicion051.AceptaNumeros = True
Me.CnEdicion051.AceptaSimbolos = False
Me.CnEdicion051.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion051.ConvierteAMayusculas = False
Me.CnEdicion051.ConvierteAMinusculas = False
Me.CnEdicion051.EsFechaHoraCreacion = False
Me.CnEdicion051.EsFechaHoraModificacion = False
Me.CnEdicion051.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion051.ColorFondo = System.Drawing.Color.White
Me.CnEdicion051.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion051.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion051.Campo = "palets"
Me.CnEdicion051.CampoEnlacesLookup1 = Nothing
Me.CnEdicion051.CampoEnlacesLookup2 = Nothing
Me.CnEdicion051.CampoEnlacesLookup3 = Nothing
Me.CnEdicion051.EdicionEnGrid = True
Me.CnEdicion051.TituloParaGrid = "Palets"
Me.CnEdicion051.AnchoColumnaGrid = 100
Me.CnEdicion051.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion051.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion051.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion051.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion051.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion051.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion051.EnCreacionSoloLectura = False
Me.CnEdicion051.EnCreacionOculto = False
Me.CnEdicion051.SiempreSoloLectura = False
Me.CnEdicion051.SiempreOculto = False
Me.CnEdicion051.EnlacesLookup1 = 0
Me.CnEdicion051.EnlacesLookup2 = 0
Me.CnEdicion051.EnlacesLookup3 = 0
Me.CnEdicion051.EnModificacionSoloLectura = False
Me.CnEdicion051.EnModificacionOculto = False
Me.CnEdicion051.Fuente = Nothing
Me.CnEdicion051.HayMascaraEspecial = False
Me.CnEdicion051.HayValorDefecto = True
Me.CnEdicion051.NumeroParametroValorDefecto = 0
Me.CnEdicion051.ValorDefecto = "0"
Me.CnEdicion051.HayValorFijo = False
Me.CnEdicion051.NumeroParametroValorFijo = 0
Me.CnEdicion051.ValorFijo = ""
Me.CnEdicion051.HayValorFijoCreacion = False
Me.CnEdicion051.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion051.ValorFijoCreacion = ""
Me.CnEdicion051.Location = New System.Drawing.Point(75,98)
Me.CnEdicion051.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion051.MascaraEspecial = ""
Me.CnEdicion051.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion051.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion051.MaximoNumero = 999999999999999.0R
Me.CnEdicion051.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion051.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion051.MinimoNumero = -999999999999999.0R
Me.CnEdicion051.Name = "CnEdicion051"
Me.CnEdicion051.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion051.TabIndex = 9999
Me.CnEdicion051.Tabla = "lineas_salida"
'
'CnEdicion052
'
Me.CnEdicion052.AceptaEspacios = True
Me.CnEdicion052.AceptaMayusculas = True
Me.CnEdicion052.AceptaMayusculasAcentuadas = True
Me.CnEdicion052.AceptaMinusculas = True
Me.CnEdicion052.AceptaMinusculasAcentuadas = True
Me.CnEdicion052.AceptaNumeros = True
Me.CnEdicion052.AceptaSimbolos = False
Me.CnEdicion052.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion052.ConvierteAMayusculas = False
Me.CnEdicion052.ConvierteAMinusculas = False
Me.CnEdicion052.EsFechaHoraCreacion = False
Me.CnEdicion052.EsFechaHoraModificacion = False
Me.CnEdicion052.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion052.ColorFondo = System.Drawing.Color.White
Me.CnEdicion052.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion052.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion052.Campo = "bultos"
Me.CnEdicion052.CampoEnlacesLookup1 = Nothing
Me.CnEdicion052.CampoEnlacesLookup2 = Nothing
Me.CnEdicion052.CampoEnlacesLookup3 = Nothing
Me.CnEdicion052.EdicionEnGrid = True
Me.CnEdicion052.TituloParaGrid = "Núm.bultos"
Me.CnEdicion052.AnchoColumnaGrid = 100
Me.CnEdicion052.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion052.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion052.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion052.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion052.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion052.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion052.EnCreacionSoloLectura = False
Me.CnEdicion052.EnCreacionOculto = False
Me.CnEdicion052.SiempreSoloLectura = False
Me.CnEdicion052.SiempreOculto = False
Me.CnEdicion052.EnlacesLookup1 = 0
Me.CnEdicion052.EnlacesLookup2 = 0
Me.CnEdicion052.EnlacesLookup3 = 0
Me.CnEdicion052.EnModificacionSoloLectura = False
Me.CnEdicion052.EnModificacionOculto = False
Me.CnEdicion052.Fuente = Nothing
Me.CnEdicion052.HayMascaraEspecial = False
Me.CnEdicion052.HayValorDefecto = True
Me.CnEdicion052.NumeroParametroValorDefecto = 0
Me.CnEdicion052.ValorDefecto = "0"
Me.CnEdicion052.HayValorFijo = False
Me.CnEdicion052.NumeroParametroValorFijo = 0
Me.CnEdicion052.ValorFijo = ""
Me.CnEdicion052.HayValorFijoCreacion = False
Me.CnEdicion052.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion052.ValorFijoCreacion = ""
Me.CnEdicion052.Location = New System.Drawing.Point(110,98)
Me.CnEdicion052.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion052.MascaraEspecial = ""
Me.CnEdicion052.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion052.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion052.MaximoNumero = 999999999999999.0R
Me.CnEdicion052.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion052.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion052.MinimoNumero = -999999999999999.0R
Me.CnEdicion052.Name = "CnEdicion052"
Me.CnEdicion052.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion052.TabIndex = 9999
Me.CnEdicion052.Tabla = "lineas_salida"
'
'CnEdicion053
'
Me.CnEdicion053.AceptaEspacios = True
Me.CnEdicion053.AceptaMayusculas = True
Me.CnEdicion053.AceptaMayusculasAcentuadas = True
Me.CnEdicion053.AceptaMinusculas = True
Me.CnEdicion053.AceptaMinusculasAcentuadas = True
Me.CnEdicion053.AceptaNumeros = True
Me.CnEdicion053.AceptaSimbolos = False
Me.CnEdicion053.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion053.ConvierteAMayusculas = False
Me.CnEdicion053.ConvierteAMinusculas = False
Me.CnEdicion053.EsFechaHoraCreacion = False
Me.CnEdicion053.EsFechaHoraModificacion = False
Me.CnEdicion053.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion053.ColorFondo = System.Drawing.Color.White
Me.CnEdicion053.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion053.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion053.Campo = "bruto"
Me.CnEdicion053.CampoEnlacesLookup1 = Nothing
Me.CnEdicion053.CampoEnlacesLookup2 = Nothing
Me.CnEdicion053.CampoEnlacesLookup3 = Nothing
Me.CnEdicion053.EdicionEnGrid = True
Me.CnEdicion053.TituloParaGrid = "Bruto"
Me.CnEdicion053.AnchoColumnaGrid = 100
Me.CnEdicion053.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion053.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion053.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion053.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion053.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion053.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion053.EnCreacionSoloLectura = False
Me.CnEdicion053.EnCreacionOculto = False
Me.CnEdicion053.SiempreSoloLectura = False
Me.CnEdicion053.SiempreOculto = False
Me.CnEdicion053.EnlacesLookup1 = 0
Me.CnEdicion053.EnlacesLookup2 = 0
Me.CnEdicion053.EnlacesLookup3 = 0
Me.CnEdicion053.EnModificacionSoloLectura = False
Me.CnEdicion053.EnModificacionOculto = False
Me.CnEdicion053.Fuente = Nothing
Me.CnEdicion053.HayMascaraEspecial = False
Me.CnEdicion053.HayValorDefecto = True
Me.CnEdicion053.NumeroParametroValorDefecto = 0
Me.CnEdicion053.ValorDefecto = "0"
Me.CnEdicion053.HayValorFijo = False
Me.CnEdicion053.NumeroParametroValorFijo = 0
Me.CnEdicion053.ValorFijo = ""
Me.CnEdicion053.HayValorFijoCreacion = False
Me.CnEdicion053.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion053.ValorFijoCreacion = ""
Me.CnEdicion053.Location = New System.Drawing.Point(145,98)
Me.CnEdicion053.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion053.MascaraEspecial = ""
Me.CnEdicion053.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion053.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion053.MaximoNumero = 999999999999999.0R
Me.CnEdicion053.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion053.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion053.MinimoNumero = -999999999999999.0R
Me.CnEdicion053.Name = "CnEdicion053"
Me.CnEdicion053.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion053.TabIndex = 9999
Me.CnEdicion053.Tabla = "lineas_salida"
'
'CnEdicion054
'
Me.CnEdicion054.AceptaEspacios = True
Me.CnEdicion054.AceptaMayusculas = True
Me.CnEdicion054.AceptaMayusculasAcentuadas = True
Me.CnEdicion054.AceptaMinusculas = True
Me.CnEdicion054.AceptaMinusculasAcentuadas = True
Me.CnEdicion054.AceptaNumeros = True
Me.CnEdicion054.AceptaSimbolos = False
Me.CnEdicion054.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion054.ConvierteAMayusculas = False
Me.CnEdicion054.ConvierteAMinusculas = False
Me.CnEdicion054.EsFechaHoraCreacion = False
Me.CnEdicion054.EsFechaHoraModificacion = False
Me.CnEdicion054.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion054.ColorFondo = System.Drawing.Color.White
Me.CnEdicion054.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion054.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion054.Campo = "neto"
Me.CnEdicion054.CampoEnlacesLookup1 = Nothing
Me.CnEdicion054.CampoEnlacesLookup2 = Nothing
Me.CnEdicion054.CampoEnlacesLookup3 = Nothing
Me.CnEdicion054.EdicionEnGrid = True
Me.CnEdicion054.TituloParaGrid = "Neto"
Me.CnEdicion054.AnchoColumnaGrid = 100
Me.CnEdicion054.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion054.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion054.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion054.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion054.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion054.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion054.EnCreacionSoloLectura = False
Me.CnEdicion054.EnCreacionOculto = False
Me.CnEdicion054.SiempreSoloLectura = False
Me.CnEdicion054.SiempreOculto = False
Me.CnEdicion054.EnlacesLookup1 = 0
Me.CnEdicion054.EnlacesLookup2 = 0
Me.CnEdicion054.EnlacesLookup3 = 0
Me.CnEdicion054.EnModificacionSoloLectura = False
Me.CnEdicion054.EnModificacionOculto = False
Me.CnEdicion054.Fuente = Nothing
Me.CnEdicion054.HayMascaraEspecial = False
Me.CnEdicion054.HayValorDefecto = True
Me.CnEdicion054.NumeroParametroValorDefecto = 0
Me.CnEdicion054.ValorDefecto = "0"
Me.CnEdicion054.HayValorFijo = False
Me.CnEdicion054.NumeroParametroValorFijo = 0
Me.CnEdicion054.ValorFijo = ""
Me.CnEdicion054.HayValorFijoCreacion = False
Me.CnEdicion054.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion054.ValorFijoCreacion = ""
Me.CnEdicion054.Location = New System.Drawing.Point(180,98)
Me.CnEdicion054.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion054.MascaraEspecial = ""
Me.CnEdicion054.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion054.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion054.MaximoNumero = 999999999999999.0R
Me.CnEdicion054.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion054.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion054.MinimoNumero = -999999999999999.0R
Me.CnEdicion054.Name = "CnEdicion054"
Me.CnEdicion054.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion054.TabIndex = 9999
Me.CnEdicion054.Tabla = "lineas_salida"
'
'CnEdicion055
'
Me.CnEdicion055.AceptaEspacios = True
Me.CnEdicion055.AceptaMayusculas = True
Me.CnEdicion055.AceptaMayusculasAcentuadas = True
Me.CnEdicion055.AceptaMinusculas = True
Me.CnEdicion055.AceptaMinusculasAcentuadas = True
Me.CnEdicion055.AceptaNumeros = True
Me.CnEdicion055.AceptaSimbolos = False
Me.CnEdicion055.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion055.ConvierteAMayusculas = False
Me.CnEdicion055.ConvierteAMinusculas = False
Me.CnEdicion055.EsFechaHoraCreacion = False
Me.CnEdicion055.EsFechaHoraModificacion = False
Me.CnEdicion055.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion055.ColorFondo = System.Drawing.Color.White
Me.CnEdicion055.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion055.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion055.Campo = "tara"
Me.CnEdicion055.CampoEnlacesLookup1 = Nothing
Me.CnEdicion055.CampoEnlacesLookup2 = Nothing
Me.CnEdicion055.CampoEnlacesLookup3 = Nothing
Me.CnEdicion055.EdicionEnGrid = True
Me.CnEdicion055.TituloParaGrid = "Tara"
Me.CnEdicion055.AnchoColumnaGrid = 100
Me.CnEdicion055.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion055.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion055.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion055.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion055.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion055.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion055.EnCreacionSoloLectura = False
Me.CnEdicion055.EnCreacionOculto = False
Me.CnEdicion055.SiempreSoloLectura = False
Me.CnEdicion055.SiempreOculto = False
Me.CnEdicion055.EnlacesLookup1 = 0
Me.CnEdicion055.EnlacesLookup2 = 0
Me.CnEdicion055.EnlacesLookup3 = 0
Me.CnEdicion055.EnModificacionSoloLectura = False
Me.CnEdicion055.EnModificacionOculto = False
Me.CnEdicion055.Fuente = Nothing
Me.CnEdicion055.HayMascaraEspecial = False
Me.CnEdicion055.HayValorDefecto = True
Me.CnEdicion055.NumeroParametroValorDefecto = 0
Me.CnEdicion055.ValorDefecto = "0"
Me.CnEdicion055.HayValorFijo = False
Me.CnEdicion055.NumeroParametroValorFijo = 0
Me.CnEdicion055.ValorFijo = ""
Me.CnEdicion055.HayValorFijoCreacion = False
Me.CnEdicion055.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion055.ValorFijoCreacion = ""
Me.CnEdicion055.Location = New System.Drawing.Point(215,98)
Me.CnEdicion055.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion055.MascaraEspecial = ""
Me.CnEdicion055.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion055.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion055.MaximoNumero = 999999999999999.0R
Me.CnEdicion055.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion055.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion055.MinimoNumero = -999999999999999.0R
Me.CnEdicion055.Name = "CnEdicion055"
Me.CnEdicion055.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion055.TabIndex = 9999
Me.CnEdicion055.Tabla = "lineas_salida"
'
'CnEdicion056
'
Me.CnEdicion056.AceptaEspacios = True
Me.CnEdicion056.AceptaMayusculas = True
Me.CnEdicion056.AceptaMayusculasAcentuadas = True
Me.CnEdicion056.AceptaMinusculas = True
Me.CnEdicion056.AceptaMinusculasAcentuadas = True
Me.CnEdicion056.AceptaNumeros = True
Me.CnEdicion056.AceptaSimbolos = False
Me.CnEdicion056.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion056.ConvierteAMayusculas = False
Me.CnEdicion056.ConvierteAMinusculas = False
Me.CnEdicion056.EsFechaHoraCreacion = False
Me.CnEdicion056.EsFechaHoraModificacion = False
Me.CnEdicion056.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion056.ColorFondo = System.Drawing.Color.White
Me.CnEdicion056.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion056.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion056.Campo = "precio_estimado"
Me.CnEdicion056.CampoEnlacesLookup1 = Nothing
Me.CnEdicion056.CampoEnlacesLookup2 = Nothing
Me.CnEdicion056.CampoEnlacesLookup3 = Nothing
Me.CnEdicion056.EdicionEnGrid = True
Me.CnEdicion056.TituloParaGrid = "Precio estimado"
Me.CnEdicion056.AnchoColumnaGrid = 144
Me.CnEdicion056.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion056.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion056.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion056.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion056.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion056.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion056.EnCreacionSoloLectura = False
Me.CnEdicion056.EnCreacionOculto = False
Me.CnEdicion056.SiempreSoloLectura = False
Me.CnEdicion056.SiempreOculto = False
Me.CnEdicion056.EnlacesLookup1 = 0
Me.CnEdicion056.EnlacesLookup2 = 0
Me.CnEdicion056.EnlacesLookup3 = 0
Me.CnEdicion056.EnModificacionSoloLectura = False
Me.CnEdicion056.EnModificacionOculto = False
Me.CnEdicion056.Fuente = Nothing
Me.CnEdicion056.HayMascaraEspecial = False
Me.CnEdicion056.HayValorDefecto = True
Me.CnEdicion056.NumeroParametroValorDefecto = 0
Me.CnEdicion056.ValorDefecto = "0"
Me.CnEdicion056.HayValorFijo = False
Me.CnEdicion056.NumeroParametroValorFijo = 0
Me.CnEdicion056.ValorFijo = ""
Me.CnEdicion056.HayValorFijoCreacion = False
Me.CnEdicion056.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion056.ValorFijoCreacion = ""
Me.CnEdicion056.Location = New System.Drawing.Point(250,98)
Me.CnEdicion056.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion056.MascaraEspecial = ""
Me.CnEdicion056.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion056.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion056.MaximoNumero = 999999999999999.0R
Me.CnEdicion056.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion056.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion056.MinimoNumero = -999999999999999.0R
Me.CnEdicion056.Name = "CnEdicion056"
Me.CnEdicion056.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion056.TabIndex = 9999
Me.CnEdicion056.Tabla = "lineas_salida"
'
'CnEdicion057
'
Me.CnEdicion057.AceptaEspacios = True
Me.CnEdicion057.AceptaMayusculas = True
Me.CnEdicion057.AceptaMayusculasAcentuadas = True
Me.CnEdicion057.AceptaMinusculas = True
Me.CnEdicion057.AceptaMinusculasAcentuadas = True
Me.CnEdicion057.AceptaNumeros = True
Me.CnEdicion057.AceptaSimbolos = False
Me.CnEdicion057.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion057.ConvierteAMayusculas = False
Me.CnEdicion057.ConvierteAMinusculas = False
Me.CnEdicion057.EsFechaHoraCreacion = False
Me.CnEdicion057.EsFechaHoraModificacion = False
Me.CnEdicion057.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion057.ColorFondo = System.Drawing.Color.White
Me.CnEdicion057.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion057.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion057.Campo = "precio_provisional"
Me.CnEdicion057.CampoEnlacesLookup1 = Nothing
Me.CnEdicion057.CampoEnlacesLookup2 = Nothing
Me.CnEdicion057.CampoEnlacesLookup3 = Nothing
Me.CnEdicion057.EdicionEnGrid = True
Me.CnEdicion057.TituloParaGrid = "Precio provisional"
Me.CnEdicion057.AnchoColumnaGrid = 173
Me.CnEdicion057.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion057.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion057.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion057.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion057.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion057.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion057.EnCreacionSoloLectura = False
Me.CnEdicion057.EnCreacionOculto = False
Me.CnEdicion057.SiempreSoloLectura = False
Me.CnEdicion057.SiempreOculto = False
Me.CnEdicion057.EnlacesLookup1 = 0
Me.CnEdicion057.EnlacesLookup2 = 0
Me.CnEdicion057.EnlacesLookup3 = 0
Me.CnEdicion057.EnModificacionSoloLectura = False
Me.CnEdicion057.EnModificacionOculto = False
Me.CnEdicion057.Fuente = Nothing
Me.CnEdicion057.HayMascaraEspecial = False
Me.CnEdicion057.HayValorDefecto = True
Me.CnEdicion057.NumeroParametroValorDefecto = 0
Me.CnEdicion057.ValorDefecto = "0"
Me.CnEdicion057.HayValorFijo = False
Me.CnEdicion057.NumeroParametroValorFijo = 0
Me.CnEdicion057.ValorFijo = ""
Me.CnEdicion057.HayValorFijoCreacion = False
Me.CnEdicion057.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion057.ValorFijoCreacion = ""
Me.CnEdicion057.Location = New System.Drawing.Point(285,98)
Me.CnEdicion057.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion057.MascaraEspecial = ""
Me.CnEdicion057.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion057.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion057.MaximoNumero = 999999999999999.0R
Me.CnEdicion057.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion057.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion057.MinimoNumero = -999999999999999.0R
Me.CnEdicion057.Name = "CnEdicion057"
Me.CnEdicion057.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion057.TabIndex = 9999
Me.CnEdicion057.Tabla = "lineas_salida"
'
'Lbl058
'
Me.Lbl058.AutoSize = True
Me.Lbl058.Location = New System.Drawing.Point(27,472)
Me.Lbl058.Name = "Lbl058"
Me.Lbl058.Size = New System.Drawing.Size(41, 13)
Me.Lbl058.Tabindex = 9999
Me.Lbl058.Text = "Cód.variedad"
'
'TxtDatos058
'
Me.TxtDatos058.Location = New System.Drawing.Point(114,470)
Me.TxtDatos058.Name = "TxtDatos058"
Me.TxtDatos058.ReadOnly = True
Me.TxtDatos058.Size = New System.Drawing.Size(115, 20)
Me.TxtDatos058.Tabindex = 9999
'
'CnEdicion058
'
Me.CnEdicion058.AceptaEspacios = True
Me.CnEdicion058.AceptaMayusculas = True
Me.CnEdicion058.AceptaMayusculasAcentuadas = False
Me.CnEdicion058.AceptaMinusculas = False
Me.CnEdicion058.AceptaMinusculasAcentuadas = False
Me.CnEdicion058.AceptaNumeros = True
Me.CnEdicion058.AceptaSimbolos = True
Me.CnEdicion058.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion058.ConvierteAMayusculas = True
Me.CnEdicion058.ConvierteAMinusculas = False
Me.CnEdicion058.EsFechaHoraCreacion = False
Me.CnEdicion058.EsFechaHoraModificacion = False
Me.CnEdicion058.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion058.ColorFondo = System.Drawing.Color.White
Me.CnEdicion058.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion058.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion058.Campo = "codigo_variedad"
Me.CnEdicion058.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion058.CampoEnlacesLookup2 = Nothing
Me.CnEdicion058.CampoEnlacesLookup3 = Nothing
Me.CnEdicion058.EdicionEnGrid = False
Me.CnEdicion058.TituloParaGrid = Nothing
Me.CnEdicion058.AnchoColumnaGrid = 0
Me.CnEdicion058.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion058.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion058.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion058.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion058.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion058.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion058.EnCreacionSoloLectura = False
Me.CnEdicion058.EnCreacionOculto = False
Me.CnEdicion058.SiempreSoloLectura = False
Me.CnEdicion058.SiempreOculto = False
Me.CnEdicion058.EnlacesLookup1 = 31185
Me.CnEdicion058.EnlacesLookup2 = 0
Me.CnEdicion058.EnlacesLookup3 = 0
Me.CnEdicion058.EnModificacionSoloLectura = False
Me.CnEdicion058.EnModificacionOculto = False
Me.CnEdicion058.Fuente = Nothing
Me.CnEdicion058.HayMascaraEspecial = False
Me.CnEdicion058.HayValorDefecto = False
Me.CnEdicion058.NumeroParametroValorDefecto = 0
Me.CnEdicion058.ValorDefecto = ""
Me.CnEdicion058.HayValorFijo = False
Me.CnEdicion058.NumeroParametroValorFijo = 0
Me.CnEdicion058.ValorFijo = ""
Me.CnEdicion058.HayValorFijoCreacion = False
Me.CnEdicion058.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion058.ValorFijoCreacion = ""
Me.CnEdicion058.Location = New System.Drawing.Point(118,470)
Me.CnEdicion058.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion058.MascaraEspecial = ""
Me.CnEdicion058.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion058.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion058.MaximoNumero = 999999999999999.0R
Me.CnEdicion058.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion058.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion058.MinimoNumero = -999999999999999.0R
Me.CnEdicion058.Name = "CnEdicion058"
Me.CnEdicion058.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion058.TabIndex = 9999
Me.CnEdicion058.Tabla = "lineas_salida"
'
'CmdGrid058
'
Me.CmdGrid058.Image = CType(Resources.GetObject("CmdGrid058.Image"), System.Drawing.Image)
Me.CmdGrid058.Location = New System.Drawing.Point(230,470)
Me.CmdGrid058.Name = "CmdGrid058"
Me.CmdGrid058.Size = New System.Drawing.Size(24,22)
Me.CmdGrid058.UseVisualStyleBackColor = True
Me.CmdGrid058.Tabindex = 9999
'
'TxtLookup0581
'
Me.TxtLookup0581.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0581.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0581.Location = New System.Drawing.Point(264,473)
Me.TxtLookup0581.Name = "TxtLookup0581"
Me.TxtLookup0581.ReadOnly = True
Me.TxtLookup0581.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0581.Tabindex = 9999
'
'Lbl059
'
Me.Lbl059.AutoSize = True
Me.Lbl059.Location = New System.Drawing.Point(16,493)
Me.Lbl059.Name = "Lbl059"
Me.Lbl059.Size = New System.Drawing.Size(41, 13)
Me.Lbl059.Tabindex = 9999
Me.Lbl059.Text = "Cód.confección"
'
'TxtDatos059
'
Me.TxtDatos059.Location = New System.Drawing.Point(114,491)
Me.TxtDatos059.Name = "TxtDatos059"
Me.TxtDatos059.ReadOnly = True
Me.TxtDatos059.Size = New System.Drawing.Size(134, 20)
Me.TxtDatos059.Tabindex = 9999
'
'CnEdicion059
'
Me.CnEdicion059.AceptaEspacios = True
Me.CnEdicion059.AceptaMayusculas = True
Me.CnEdicion059.AceptaMayusculasAcentuadas = False
Me.CnEdicion059.AceptaMinusculas = False
Me.CnEdicion059.AceptaMinusculasAcentuadas = False
Me.CnEdicion059.AceptaNumeros = True
Me.CnEdicion059.AceptaSimbolos = True
Me.CnEdicion059.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion059.ConvierteAMayusculas = True
Me.CnEdicion059.ConvierteAMinusculas = False
Me.CnEdicion059.EsFechaHoraCreacion = False
Me.CnEdicion059.EsFechaHoraModificacion = False
Me.CnEdicion059.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion059.ColorFondo = System.Drawing.Color.White
Me.CnEdicion059.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion059.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion059.Campo = "codigo_confeccion"
Me.CnEdicion059.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion059.CampoEnlacesLookup2 = Nothing
Me.CnEdicion059.CampoEnlacesLookup3 = Nothing
Me.CnEdicion059.EdicionEnGrid = False
Me.CnEdicion059.TituloParaGrid = Nothing
Me.CnEdicion059.AnchoColumnaGrid = 0
Me.CnEdicion059.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion059.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion059.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion059.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion059.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion059.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion059.EnCreacionSoloLectura = False
Me.CnEdicion059.EnCreacionOculto = False
Me.CnEdicion059.SiempreSoloLectura = False
Me.CnEdicion059.SiempreOculto = False
Me.CnEdicion059.EnlacesLookup1 = 31188
Me.CnEdicion059.EnlacesLookup2 = 0
Me.CnEdicion059.EnlacesLookup3 = 0
Me.CnEdicion059.EnModificacionSoloLectura = False
Me.CnEdicion059.EnModificacionOculto = False
Me.CnEdicion059.Fuente = Nothing
Me.CnEdicion059.HayMascaraEspecial = False
Me.CnEdicion059.HayValorDefecto = False
Me.CnEdicion059.NumeroParametroValorDefecto = 0
Me.CnEdicion059.ValorDefecto = ""
Me.CnEdicion059.HayValorFijo = False
Me.CnEdicion059.NumeroParametroValorFijo = 0
Me.CnEdicion059.ValorFijo = ""
Me.CnEdicion059.HayValorFijoCreacion = False
Me.CnEdicion059.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion059.ValorFijoCreacion = ""
Me.CnEdicion059.Location = New System.Drawing.Point(118,491)
Me.CnEdicion059.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion059.MascaraEspecial = ""
Me.CnEdicion059.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion059.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion059.MaximoNumero = 999999999999999.0R
Me.CnEdicion059.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion059.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion059.MinimoNumero = -999999999999999.0R
Me.CnEdicion059.Name = "CnEdicion059"
Me.CnEdicion059.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion059.TabIndex = 9999
Me.CnEdicion059.Tabla = "lineas_salida"
'
'CmdGrid059
'
Me.CmdGrid059.Image = CType(Resources.GetObject("CmdGrid059.Image"), System.Drawing.Image)
Me.CmdGrid059.Location = New System.Drawing.Point(249,491)
Me.CmdGrid059.Name = "CmdGrid059"
Me.CmdGrid059.Size = New System.Drawing.Size(24,22)
Me.CmdGrid059.UseVisualStyleBackColor = True
Me.CmdGrid059.Tabindex = 9999
'
'TxtLookup0591
'
Me.TxtLookup0591.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0591.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0591.Location = New System.Drawing.Point(283,494)
Me.TxtLookup0591.Name = "TxtLookup0591"
Me.TxtLookup0591.ReadOnly = True
Me.TxtLookup0591.Size = New System.Drawing.Size(250, 13)
Me.TxtLookup0591.Tabindex = 9999
'
'Lbl060
'
Me.Lbl060.AutoSize = True
Me.Lbl060.Location = New System.Drawing.Point(34,514)
Me.Lbl060.Name = "Lbl060"
Me.Lbl060.Size = New System.Drawing.Size(41, 13)
Me.Lbl060.Tabindex = 9999
Me.Lbl060.Text = "Cód.periodo"
'
'TxtDatos060
'
Me.TxtDatos060.Location = New System.Drawing.Point(114,512)
Me.TxtDatos060.Name = "TxtDatos060"
Me.TxtDatos060.ReadOnly = True
Me.TxtDatos060.Size = New System.Drawing.Size(106, 20)
Me.TxtDatos060.Tabindex = 9999
'
'CnEdicion060
'
Me.CnEdicion060.AceptaEspacios = True
Me.CnEdicion060.AceptaMayusculas = True
Me.CnEdicion060.AceptaMayusculasAcentuadas = True
Me.CnEdicion060.AceptaMinusculas = True
Me.CnEdicion060.AceptaMinusculasAcentuadas = True
Me.CnEdicion060.AceptaNumeros = True
Me.CnEdicion060.AceptaSimbolos = False
Me.CnEdicion060.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion060.ConvierteAMayusculas = False
Me.CnEdicion060.ConvierteAMinusculas = False
Me.CnEdicion060.EsFechaHoraCreacion = False
Me.CnEdicion060.EsFechaHoraModificacion = False
Me.CnEdicion060.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion060.ColorFondo = System.Drawing.Color.White
Me.CnEdicion060.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion060.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion060.Campo = "codigo_periodo"
Me.CnEdicion060.CampoEnlacesLookup1 = "descripcion_per"
Me.CnEdicion060.CampoEnlacesLookup2 = Nothing
Me.CnEdicion060.CampoEnlacesLookup3 = Nothing
Me.CnEdicion060.EdicionEnGrid = False
Me.CnEdicion060.TituloParaGrid = Nothing
Me.CnEdicion060.AnchoColumnaGrid = 0
Me.CnEdicion060.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion060.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion060.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion060.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion060.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion060.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion060.EnCreacionSoloLectura = False
Me.CnEdicion060.EnCreacionOculto = False
Me.CnEdicion060.SiempreSoloLectura = False
Me.CnEdicion060.SiempreOculto = False
Me.CnEdicion060.EnlacesLookup1 = 31692
Me.CnEdicion060.EnlacesLookup2 = 0
Me.CnEdicion060.EnlacesLookup3 = 0
Me.CnEdicion060.EnModificacionSoloLectura = False
Me.CnEdicion060.EnModificacionOculto = False
Me.CnEdicion060.Fuente = Nothing
Me.CnEdicion060.HayMascaraEspecial = False
Me.CnEdicion060.HayValorDefecto = False
Me.CnEdicion060.NumeroParametroValorDefecto = 0
Me.CnEdicion060.ValorDefecto = ""
Me.CnEdicion060.HayValorFijo = False
Me.CnEdicion060.NumeroParametroValorFijo = 0
Me.CnEdicion060.ValorFijo = ""
Me.CnEdicion060.HayValorFijoCreacion = False
Me.CnEdicion060.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion060.ValorFijoCreacion = ""
Me.CnEdicion060.Location = New System.Drawing.Point(118,512)
Me.CnEdicion060.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion060.MascaraEspecial = ""
Me.CnEdicion060.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion060.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion060.MaximoNumero = 999999999999999.0R
Me.CnEdicion060.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion060.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion060.MinimoNumero = -999999999999999.0R
Me.CnEdicion060.Name = "CnEdicion060"
Me.CnEdicion060.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion060.TabIndex = 9999
Me.CnEdicion060.Tabla = "lineas_salida"
'
'CmdGrid060
'
Me.CmdGrid060.Image = CType(Resources.GetObject("CmdGrid060.Image"), System.Drawing.Image)
Me.CmdGrid060.Location = New System.Drawing.Point(221,512)
Me.CmdGrid060.Name = "CmdGrid060"
Me.CmdGrid060.Size = New System.Drawing.Size(24,22)
Me.CmdGrid060.UseVisualStyleBackColor = True
Me.CmdGrid060.Tabindex = 9999
'
'TxtLookup0601
'
Me.TxtLookup0601.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
Me.TxtLookup0601.BorderStyle = System.Windows.Forms.BorderStyle.None
Me.TxtLookup0601.Location = New System.Drawing.Point(255,515)
Me.TxtLookup0601.Name = "TxtLookup0601"
Me.TxtLookup0601.ReadOnly = True
Me.TxtLookup0601.Size = New System.Drawing.Size(240, 13)
Me.TxtLookup0601.Tabindex = 9999
'
'Lbl061
'
Me.Lbl061.AutoSize = True
Me.Lbl061.Location = New System.Drawing.Point(814,514)
Me.Lbl061.Name = "Lbl061"
Me.Lbl061.Size = New System.Drawing.Size(41, 13)
Me.Lbl061.Tabindex = 9999
Me.Lbl061.Text = "Valoración"
'
'TxtDatos061
'
Me.TxtDatos061.Location = New System.Drawing.Point(882,512)
Me.TxtDatos061.Name = "TxtDatos061"
Me.TxtDatos061.ReadOnly = True
Me.TxtDatos061.Size = New System.Drawing.Size(96, 20)
Me.TxtDatos061.Tabindex = 9999
'
'CnEdicion061
'
Me.CnEdicion061.AceptaEspacios = True
Me.CnEdicion061.AceptaMayusculas = True
Me.CnEdicion061.AceptaMayusculasAcentuadas = False
Me.CnEdicion061.AceptaMinusculas = False
Me.CnEdicion061.AceptaMinusculasAcentuadas = False
Me.CnEdicion061.AceptaNumeros = True
Me.CnEdicion061.AceptaSimbolos = True
Me.CnEdicion061.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion061.ConvierteAMayusculas = True
Me.CnEdicion061.ConvierteAMinusculas = False
Me.CnEdicion061.EsFechaHoraCreacion = False
Me.CnEdicion061.EsFechaHoraModificacion = False
Me.CnEdicion061.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion061.ColorFondo = System.Drawing.Color.White
Me.CnEdicion061.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion061.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion061.Campo = "valoracion"
Me.CnEdicion061.CampoEnlacesLookup1 = Nothing
Me.CnEdicion061.CampoEnlacesLookup2 = Nothing
Me.CnEdicion061.CampoEnlacesLookup3 = Nothing
Me.CnEdicion061.EdicionEnGrid = False
Me.CnEdicion061.TituloParaGrid = Nothing
Me.CnEdicion061.AnchoColumnaGrid = 0
Me.CnEdicion061.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion061.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion061.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion061.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion061.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion061.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion061.EnCreacionSoloLectura = False
Me.CnEdicion061.EnCreacionOculto = False
Me.CnEdicion061.SiempreSoloLectura = False
Me.CnEdicion061.SiempreOculto = False
Me.CnEdicion061.EnlacesLookup1 = 0
Me.CnEdicion061.EnlacesLookup2 = 0
Me.CnEdicion061.EnlacesLookup3 = 0
Me.CnEdicion061.EnModificacionSoloLectura = False
Me.CnEdicion061.EnModificacionOculto = False
Me.CnEdicion061.Fuente = Nothing
Me.CnEdicion061.HayMascaraEspecial = False
Me.CnEdicion061.HayValorDefecto = True
Me.CnEdicion061.NumeroParametroValorDefecto = 0
Me.CnEdicion061.ValorDefecto = "N"
Me.CnEdicion061.HayValorFijo = False
Me.CnEdicion061.NumeroParametroValorFijo = 0
Me.CnEdicion061.ValorFijo = ""
Me.CnEdicion061.HayValorFijoCreacion = False
Me.CnEdicion061.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion061.ValorFijoCreacion = ""
Me.CnEdicion061.Location = New System.Drawing.Point(886,512)
Me.CnEdicion061.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion061.MascaraEspecial = ""
Me.CnEdicion061.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion061.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion061.MaximoNumero = 999999999999999.0R
Me.CnEdicion061.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion061.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion061.MinimoNumero = -999999999999999.0R
Me.CnEdicion061.Name = "CnEdicion061"
Me.CnEdicion061.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion061.TabIndex = 9999
Me.CnEdicion061.Tabla = "lineas_salida"
'
'CmdCombo061
'
Me.CmdCombo061.Image = CType(Resources.GetObject("CmdCombo061.Image"), System.Drawing.Image)
Me.CmdCombo061.Location = New System.Drawing.Point(979,512)
Me.CmdCombo061.Name = "CmdCombo061"
Me.CmdCombo061.Size = New System.Drawing.Size(24,22)
Me.CmdCombo061.UseVisualStyleBackColor = True
Me.CmdCombo061.Tabindex = 9999
'
'Lbl062
'
Me.Lbl062.AutoSize = True
Me.Lbl062.Location = New System.Drawing.Point(4,535)
Me.Lbl062.Name = "Lbl062"
Me.Lbl062.Size = New System.Drawing.Size(41, 13)
Me.Lbl062.Tabindex = 9999
Me.Lbl062.Text = "Importe estimado"
'
'TxtDatos062
'
Me.TxtDatos062.Location = New System.Drawing.Point(114,533)
Me.TxtDatos062.Name = "TxtDatos062"
Me.TxtDatos062.ReadOnly = True
Me.TxtDatos062.Size = New System.Drawing.Size(154, 20)
Me.TxtDatos062.Tabindex = 9999
'
'CnEdicion062
'
Me.CnEdicion062.AceptaEspacios = True
Me.CnEdicion062.AceptaMayusculas = True
Me.CnEdicion062.AceptaMayusculasAcentuadas = True
Me.CnEdicion062.AceptaMinusculas = True
Me.CnEdicion062.AceptaMinusculasAcentuadas = True
Me.CnEdicion062.AceptaNumeros = True
Me.CnEdicion062.AceptaSimbolos = False
Me.CnEdicion062.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion062.ConvierteAMayusculas = False
Me.CnEdicion062.ConvierteAMinusculas = False
Me.CnEdicion062.EsFechaHoraCreacion = False
Me.CnEdicion062.EsFechaHoraModificacion = False
Me.CnEdicion062.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion062.ColorFondo = System.Drawing.Color.White
Me.CnEdicion062.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion062.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion062.Campo = "importe_estimado"
Me.CnEdicion062.CampoEnlacesLookup1 = Nothing
Me.CnEdicion062.CampoEnlacesLookup2 = Nothing
Me.CnEdicion062.CampoEnlacesLookup3 = Nothing
Me.CnEdicion062.EdicionEnGrid = False
Me.CnEdicion062.TituloParaGrid = Nothing
Me.CnEdicion062.AnchoColumnaGrid = 0
Me.CnEdicion062.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion062.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion062.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion062.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion062.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion062.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion062.EnCreacionSoloLectura = False
Me.CnEdicion062.EnCreacionOculto = False
Me.CnEdicion062.SiempreSoloLectura = False
Me.CnEdicion062.SiempreOculto = False
Me.CnEdicion062.EnlacesLookup1 = 0
Me.CnEdicion062.EnlacesLookup2 = 0
Me.CnEdicion062.EnlacesLookup3 = 0
Me.CnEdicion062.EnModificacionSoloLectura = False
Me.CnEdicion062.EnModificacionOculto = False
Me.CnEdicion062.Fuente = Nothing
Me.CnEdicion062.HayMascaraEspecial = False
Me.CnEdicion062.HayValorDefecto = True
Me.CnEdicion062.NumeroParametroValorDefecto = 0
Me.CnEdicion062.ValorDefecto = "0"
Me.CnEdicion062.HayValorFijo = False
Me.CnEdicion062.NumeroParametroValorFijo = 0
Me.CnEdicion062.ValorFijo = ""
Me.CnEdicion062.HayValorFijoCreacion = False
Me.CnEdicion062.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion062.ValorFijoCreacion = ""
Me.CnEdicion062.Location = New System.Drawing.Point(118,533)
Me.CnEdicion062.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion062.MascaraEspecial = ""
Me.CnEdicion062.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion062.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion062.MaximoNumero = 999999999999999.0R
Me.CnEdicion062.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion062.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion062.MinimoNumero = -999999999999999.0R
Me.CnEdicion062.Name = "CnEdicion062"
Me.CnEdicion062.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion062.TabIndex = 9999
Me.CnEdicion062.Tabla = "lineas_salida"
'
'Lbl063
'
Me.Lbl063.AutoSize = True
Me.Lbl063.Location = New System.Drawing.Point(374,535)
Me.Lbl063.Name = "Lbl063"
Me.Lbl063.Size = New System.Drawing.Size(41, 13)
Me.Lbl063.Tabindex = 9999
Me.Lbl063.Text = "Importe provisional"
'
'TxtDatos063
'
Me.TxtDatos063.Location = New System.Drawing.Point(494,533)
Me.TxtDatos063.Name = "TxtDatos063"
Me.TxtDatos063.ReadOnly = True
Me.TxtDatos063.Size = New System.Drawing.Size(182, 20)
Me.TxtDatos063.Tabindex = 9999
'
'CnEdicion063
'
Me.CnEdicion063.AceptaEspacios = True
Me.CnEdicion063.AceptaMayusculas = True
Me.CnEdicion063.AceptaMayusculasAcentuadas = True
Me.CnEdicion063.AceptaMinusculas = True
Me.CnEdicion063.AceptaMinusculasAcentuadas = True
Me.CnEdicion063.AceptaNumeros = True
Me.CnEdicion063.AceptaSimbolos = False
Me.CnEdicion063.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion063.ConvierteAMayusculas = False
Me.CnEdicion063.ConvierteAMinusculas = False
Me.CnEdicion063.EsFechaHoraCreacion = False
Me.CnEdicion063.EsFechaHoraModificacion = False
Me.CnEdicion063.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion063.ColorFondo = System.Drawing.Color.White
Me.CnEdicion063.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion063.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion063.Campo = "importe_provisional"
Me.CnEdicion063.CampoEnlacesLookup1 = Nothing
Me.CnEdicion063.CampoEnlacesLookup2 = Nothing
Me.CnEdicion063.CampoEnlacesLookup3 = Nothing
Me.CnEdicion063.EdicionEnGrid = False
Me.CnEdicion063.TituloParaGrid = Nothing
Me.CnEdicion063.AnchoColumnaGrid = 0
Me.CnEdicion063.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion063.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion063.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion063.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion063.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion063.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion063.EnCreacionSoloLectura = False
Me.CnEdicion063.EnCreacionOculto = False
Me.CnEdicion063.SiempreSoloLectura = False
Me.CnEdicion063.SiempreOculto = False
Me.CnEdicion063.EnlacesLookup1 = 0
Me.CnEdicion063.EnlacesLookup2 = 0
Me.CnEdicion063.EnlacesLookup3 = 0
Me.CnEdicion063.EnModificacionSoloLectura = False
Me.CnEdicion063.EnModificacionOculto = False
Me.CnEdicion063.Fuente = Nothing
Me.CnEdicion063.HayMascaraEspecial = False
Me.CnEdicion063.HayValorDefecto = True
Me.CnEdicion063.NumeroParametroValorDefecto = 0
Me.CnEdicion063.ValorDefecto = "0"
Me.CnEdicion063.HayValorFijo = False
Me.CnEdicion063.NumeroParametroValorFijo = 0
Me.CnEdicion063.ValorFijo = ""
Me.CnEdicion063.HayValorFijoCreacion = False
Me.CnEdicion063.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion063.ValorFijoCreacion = ""
Me.CnEdicion063.Location = New System.Drawing.Point(498,533)
Me.CnEdicion063.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion063.MascaraEspecial = ""
Me.CnEdicion063.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion063.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion063.MaximoNumero = 999999999999999.0R
Me.CnEdicion063.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion063.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion063.MinimoNumero = -999999999999999.0R
Me.CnEdicion063.Name = "CnEdicion063"
Me.CnEdicion063.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion063.TabIndex = 9999
Me.CnEdicion063.Tabla = "lineas_salida"
Me.TabPage01.Text = "lineas_salida"
'
'TabPage02
'
Me.TabPage02.Controls.Add(Me.CnEdicion072)
Me.TabPage02.Controls.Add(Me.CnEdicion071)
Me.TabPage02.Controls.Add(Me.CnEdicion070)
Me.TabPage02.Controls.Add(Me.CnEdicion069)
Me.TabPage02.Controls.Add(Me.CnEdicion068)
Me.TabPage02.Controls.Add(Me.CnEdicion067)
Me.TabPage02.Controls.Add(Me.CnEdicion066)
Me.TabPage02.Controls.Add(Me.CnEdicion065)
Me.TabPage02.Controls.Add(Me.CnEdicion064)
Me.TabPage02.Controls.Add(Me.GridTabla03)
Me.TabPage02.Controls.Add(Me.CnTabla03)
Me.TabPage02.Location = New System.Drawing.Point(4, 4)
Me.TabPage02.Name = "TabPage02"
Me.TabPage02.Padding = New System.Windows.Forms.Padding(3)
Me.TabPage02.Size = New System.Drawing.Size(1172, 765)
Me.TabPage02.TabIndex = 1
Me.TabPage02.Text = "2"
Me.TabPage02.UseVisualStyleBackColor = True
Me.Tabpage02.CausesValidation = False
'
'CnTabla03
'
Me.CnTabla03.Autosize = True
Me.CnTabla03.BackColor = System.Drawing.SystemColors.Control
Me.CnTabla03.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
Me.CnTabla03.CargaAlInicio = True
Me.CnTabla03.CausesValidation = False
Me.CnTabla03.EnlaceATablaPadre = 31332
Me.CnTabla03.Estado = CnTabla.CnTabla.EstadoCnTabla.Inactivo
Me.CnTabla03.Formato = CnTabla.CnTabla.FormatoCnTabla.TablaSecundariaSuperior
Me.CnTabla03.HayBorrado = True
Me.CnTabla03.HayCreacion = True
Me.CnTabla03.HayDesplegar = True
Me.CnTabla03.HayModificacion = True
Me.CnTabla03.HaySeleccion = True
Me.CnTabla03.HaySiguienteAnterior = True
Me.CnTabla03.Location = New System.Drawing.Point(116,0)
Me.CnTabla03.Margin = New System.Windows.Forms.Padding(0)
Me.CnTabla03.Name = "CnTabla03"
Me.CnTabla03.Size = New System.Drawing.Size(550, 48)
Me.CnTabla03.TabIndex = 10000
Me.CnTabla03.TabStop = False
Me.CnTabla03.Tabla = "calibres_salida"
'
'GridTabla03
'
Me.GridTabla03.Size = New System.Drawing.Size(1160, 341)
Me.GridTabla03.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) Or System.Windows.Forms.AnchorStyles.Left) Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
Me.GridTabla03.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
Me.GridTabla03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
Me.GridTabla03.DefaultCellStyle = DataGridViewCellStyle2
Me.GridTabla03.Location = New System.Drawing.Point(2, 75)
Me.GridTabla03.MultiSelect = False
Me.GridTabla03.Name = "GridTabla03"
Me.GridTabla03.ReadOnly = True
DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
Me.GridTabla03.TabIndex = 9999
Me.GridTabla03.TabStop = False
'
'CnEdicion064
'
Me.CnEdicion064.AceptaEspacios = True
Me.CnEdicion064.AceptaMayusculas = True
Me.CnEdicion064.AceptaMayusculasAcentuadas = False
Me.CnEdicion064.AceptaMinusculas = False
Me.CnEdicion064.AceptaMinusculasAcentuadas = False
Me.CnEdicion064.AceptaNumeros = True
Me.CnEdicion064.AceptaSimbolos = True
Me.CnEdicion064.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion064.ConvierteAMayusculas = True
Me.CnEdicion064.ConvierteAMinusculas = False
Me.CnEdicion064.EsFechaHoraCreacion = False
Me.CnEdicion064.EsFechaHoraModificacion = False
Me.CnEdicion064.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion064.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion064.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion064.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion064.Campo = "empresa"
Me.CnEdicion064.CampoEnlacesLookup1 = Nothing
Me.CnEdicion064.CampoEnlacesLookup2 = Nothing
Me.CnEdicion064.CampoEnlacesLookup3 = Nothing
Me.CnEdicion064.EdicionEnGrid = True
Me.CnEdicion064.TituloParaGrid = "Empresa"
Me.CnEdicion064.AnchoColumnaGrid = 58
Me.CnEdicion064.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion064.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion064.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion064.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion064.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion064.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion064.EnCreacionSoloLectura = False
Me.CnEdicion064.EnCreacionOculto = False
Me.CnEdicion064.SiempreSoloLectura = False
Me.CnEdicion064.SiempreOculto = False
Me.CnEdicion064.EnlacesLookup1 = 0
Me.CnEdicion064.EnlacesLookup2 = 0
Me.CnEdicion064.EnlacesLookup3 = 0
Me.CnEdicion064.EnModificacionSoloLectura = False
Me.CnEdicion064.EnModificacionOculto = False
Me.CnEdicion064.Fuente = Nothing
Me.CnEdicion064.HayMascaraEspecial = False
Me.CnEdicion064.HayValorDefecto = False
Me.CnEdicion064.NumeroParametroValorDefecto = 0
Me.CnEdicion064.ValorDefecto = ""
Me.CnEdicion064.HayValorFijo = True
Me.CnEdicion064.NumeroParametroValorFijo = 1
Me.CnEdicion064.ValorFijo = ""
Me.CnEdicion064.HayValorFijoCreacion = False
Me.CnEdicion064.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion064.ValorFijoCreacion = ""
Me.CnEdicion064.Location = New System.Drawing.Point(880,54)
Me.CnEdicion064.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion064.MascaraEspecial = ""
Me.CnEdicion064.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion064.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion064.MaximoNumero = 999999999999999.0R
Me.CnEdicion064.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion064.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion064.MinimoNumero = -999999999999999.0R
Me.CnEdicion064.Name = "CnEdicion064"
Me.CnEdicion064.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion064.TabIndex = 9999
Me.CnEdicion064.Tabla = "calibres_salida"
'
'CnEdicion065
'
Me.CnEdicion065.AceptaEspacios = True
Me.CnEdicion065.AceptaMayusculas = True
Me.CnEdicion065.AceptaMayusculasAcentuadas = False
Me.CnEdicion065.AceptaMinusculas = False
Me.CnEdicion065.AceptaMinusculasAcentuadas = False
Me.CnEdicion065.AceptaNumeros = True
Me.CnEdicion065.AceptaSimbolos = True
Me.CnEdicion065.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion065.ConvierteAMayusculas = True
Me.CnEdicion065.ConvierteAMinusculas = False
Me.CnEdicion065.EsFechaHoraCreacion = False
Me.CnEdicion065.EsFechaHoraModificacion = False
Me.CnEdicion065.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion065.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion065.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion065.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion065.Campo = "ejercicio"
Me.CnEdicion065.CampoEnlacesLookup1 = Nothing
Me.CnEdicion065.CampoEnlacesLookup2 = Nothing
Me.CnEdicion065.CampoEnlacesLookup3 = Nothing
Me.CnEdicion065.EdicionEnGrid = True
Me.CnEdicion065.TituloParaGrid = "Ejercicio"
Me.CnEdicion065.AnchoColumnaGrid = 55
Me.CnEdicion065.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion065.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion065.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion065.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion065.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion065.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion065.EnCreacionSoloLectura = False
Me.CnEdicion065.EnCreacionOculto = False
Me.CnEdicion065.SiempreSoloLectura = False
Me.CnEdicion065.SiempreOculto = False
Me.CnEdicion065.EnlacesLookup1 = 0
Me.CnEdicion065.EnlacesLookup2 = 0
Me.CnEdicion065.EnlacesLookup3 = 0
Me.CnEdicion065.EnModificacionSoloLectura = False
Me.CnEdicion065.EnModificacionOculto = False
Me.CnEdicion065.Fuente = Nothing
Me.CnEdicion065.HayMascaraEspecial = False
Me.CnEdicion065.HayValorDefecto = False
Me.CnEdicion065.NumeroParametroValorDefecto = 0
Me.CnEdicion065.ValorDefecto = ""
Me.CnEdicion065.HayValorFijo = True
Me.CnEdicion065.NumeroParametroValorFijo = 3
Me.CnEdicion065.ValorFijo = ""
Me.CnEdicion065.HayValorFijoCreacion = False
Me.CnEdicion065.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion065.ValorFijoCreacion = ""
Me.CnEdicion065.Location = New System.Drawing.Point(930,54)
Me.CnEdicion065.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion065.MascaraEspecial = ""
Me.CnEdicion065.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion065.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion065.MaximoNumero = 999999999999999.0R
Me.CnEdicion065.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion065.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion065.MinimoNumero = -999999999999999.0R
Me.CnEdicion065.Name = "CnEdicion065"
Me.CnEdicion065.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion065.TabIndex = 9999
Me.CnEdicion065.Tabla = "calibres_salida"
'
'CnEdicion066
'
Me.CnEdicion066.AceptaEspacios = True
Me.CnEdicion066.AceptaMayusculas = True
Me.CnEdicion066.AceptaMayusculasAcentuadas = False
Me.CnEdicion066.AceptaMinusculas = False
Me.CnEdicion066.AceptaMinusculasAcentuadas = False
Me.CnEdicion066.AceptaNumeros = True
Me.CnEdicion066.AceptaSimbolos = True
Me.CnEdicion066.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion066.ConvierteAMayusculas = True
Me.CnEdicion066.ConvierteAMinusculas = False
Me.CnEdicion066.EsFechaHoraCreacion = False
Me.CnEdicion066.EsFechaHoraModificacion = False
Me.CnEdicion066.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion066.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion066.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion066.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion066.Campo = "serie"
Me.CnEdicion066.CampoEnlacesLookup1 = Nothing
Me.CnEdicion066.CampoEnlacesLookup2 = Nothing
Me.CnEdicion066.CampoEnlacesLookup3 = Nothing
Me.CnEdicion066.EdicionEnGrid = True
Me.CnEdicion066.TituloParaGrid = "Serie"
Me.CnEdicion066.AnchoColumnaGrid = 40
Me.CnEdicion066.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion066.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion066.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion066.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion066.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion066.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion066.EnCreacionSoloLectura = False
Me.CnEdicion066.EnCreacionOculto = False
Me.CnEdicion066.SiempreSoloLectura = False
Me.CnEdicion066.SiempreOculto = False
Me.CnEdicion066.EnlacesLookup1 = 0
Me.CnEdicion066.EnlacesLookup2 = 0
Me.CnEdicion066.EnlacesLookup3 = 0
Me.CnEdicion066.EnModificacionSoloLectura = False
Me.CnEdicion066.EnModificacionOculto = False
Me.CnEdicion066.Fuente = Nothing
Me.CnEdicion066.HayMascaraEspecial = False
Me.CnEdicion066.HayValorDefecto = False
Me.CnEdicion066.NumeroParametroValorDefecto = 0
Me.CnEdicion066.ValorDefecto = ""
Me.CnEdicion066.HayValorFijo = False
Me.CnEdicion066.NumeroParametroValorFijo = 0
Me.CnEdicion066.ValorFijo = ""
Me.CnEdicion066.HayValorFijoCreacion = False
Me.CnEdicion066.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion066.ValorFijoCreacion = ""
Me.CnEdicion066.Location = New System.Drawing.Point(980,54)
Me.CnEdicion066.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion066.MascaraEspecial = ""
Me.CnEdicion066.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion066.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion066.MaximoNumero = 999999999999999.0R
Me.CnEdicion066.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion066.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion066.MinimoNumero = -999999999999999.0R
Me.CnEdicion066.Name = "CnEdicion066"
Me.CnEdicion066.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion066.TabIndex = 9999
Me.CnEdicion066.Tabla = "calibres_salida"
'
'CnEdicion067
'
Me.CnEdicion067.AceptaEspacios = True
Me.CnEdicion067.AceptaMayusculas = True
Me.CnEdicion067.AceptaMayusculasAcentuadas = False
Me.CnEdicion067.AceptaMinusculas = False
Me.CnEdicion067.AceptaMinusculasAcentuadas = False
Me.CnEdicion067.AceptaNumeros = True
Me.CnEdicion067.AceptaSimbolos = True
Me.CnEdicion067.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion067.ConvierteAMayusculas = True
Me.CnEdicion067.ConvierteAMinusculas = False
Me.CnEdicion067.EsFechaHoraCreacion = False
Me.CnEdicion067.EsFechaHoraModificacion = False
Me.CnEdicion067.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion067.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion067.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion067.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion067.Campo = "tipo_documento"
Me.CnEdicion067.CampoEnlacesLookup1 = Nothing
Me.CnEdicion067.CampoEnlacesLookup2 = Nothing
Me.CnEdicion067.CampoEnlacesLookup3 = Nothing
Me.CnEdicion067.EdicionEnGrid = True
Me.CnEdicion067.TituloParaGrid = "Tipo de documento"
Me.CnEdicion067.AnchoColumnaGrid = 118
Me.CnEdicion067.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion067.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion067.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion067.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion067.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion067.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion067.EnCreacionSoloLectura = False
Me.CnEdicion067.EnCreacionOculto = False
Me.CnEdicion067.SiempreSoloLectura = False
Me.CnEdicion067.SiempreOculto = False
Me.CnEdicion067.EnlacesLookup1 = 0
Me.CnEdicion067.EnlacesLookup2 = 0
Me.CnEdicion067.EnlacesLookup3 = 0
Me.CnEdicion067.EnModificacionSoloLectura = False
Me.CnEdicion067.EnModificacionOculto = False
Me.CnEdicion067.Fuente = Nothing
Me.CnEdicion067.HayMascaraEspecial = False
Me.CnEdicion067.HayValorDefecto = False
Me.CnEdicion067.NumeroParametroValorDefecto = 0
Me.CnEdicion067.ValorDefecto = ""
Me.CnEdicion067.HayValorFijo = False
Me.CnEdicion067.NumeroParametroValorFijo = 0
Me.CnEdicion067.ValorFijo = ""
Me.CnEdicion067.HayValorFijoCreacion = False
Me.CnEdicion067.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion067.ValorFijoCreacion = ""
Me.CnEdicion067.Location = New System.Drawing.Point(1030,54)
Me.CnEdicion067.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion067.MascaraEspecial = ""
Me.CnEdicion067.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion067.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion067.MaximoNumero = 999999999999999.0R
Me.CnEdicion067.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion067.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion067.MinimoNumero = -999999999999999.0R
Me.CnEdicion067.Name = "CnEdicion067"
Me.CnEdicion067.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion067.TabIndex = 9999
Me.CnEdicion067.Tabla = "calibres_salida"
'
'CnEdicion068
'
Me.CnEdicion068.AceptaEspacios = True
Me.CnEdicion068.AceptaMayusculas = True
Me.CnEdicion068.AceptaMayusculasAcentuadas = False
Me.CnEdicion068.AceptaMinusculas = False
Me.CnEdicion068.AceptaMinusculasAcentuadas = False
Me.CnEdicion068.AceptaNumeros = True
Me.CnEdicion068.AceptaSimbolos = True
Me.CnEdicion068.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion068.ConvierteAMayusculas = True
Me.CnEdicion068.ConvierteAMinusculas = False
Me.CnEdicion068.EsFechaHoraCreacion = False
Me.CnEdicion068.EsFechaHoraModificacion = False
Me.CnEdicion068.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion068.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion068.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion068.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion068.Campo = "numero_documento"
Me.CnEdicion068.CampoEnlacesLookup1 = Nothing
Me.CnEdicion068.CampoEnlacesLookup2 = Nothing
Me.CnEdicion068.CampoEnlacesLookup3 = Nothing
Me.CnEdicion068.EdicionEnGrid = True
Me.CnEdicion068.TituloParaGrid = "Núm.documento"
Me.CnEdicion068.AnchoColumnaGrid = 102
Me.CnEdicion068.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion068.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion068.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion068.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion068.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion068.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion068.EnCreacionSoloLectura = False
Me.CnEdicion068.EnCreacionOculto = False
Me.CnEdicion068.SiempreSoloLectura = False
Me.CnEdicion068.SiempreOculto = False
Me.CnEdicion068.EnlacesLookup1 = 0
Me.CnEdicion068.EnlacesLookup2 = 0
Me.CnEdicion068.EnlacesLookup3 = 0
Me.CnEdicion068.EnModificacionSoloLectura = False
Me.CnEdicion068.EnModificacionOculto = False
Me.CnEdicion068.Fuente = Nothing
Me.CnEdicion068.HayMascaraEspecial = False
Me.CnEdicion068.HayValorDefecto = False
Me.CnEdicion068.NumeroParametroValorDefecto = 0
Me.CnEdicion068.ValorDefecto = ""
Me.CnEdicion068.HayValorFijo = False
Me.CnEdicion068.NumeroParametroValorFijo = 0
Me.CnEdicion068.ValorFijo = ""
Me.CnEdicion068.HayValorFijoCreacion = False
Me.CnEdicion068.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion068.ValorFijoCreacion = ""
Me.CnEdicion068.Location = New System.Drawing.Point(1080,54)
Me.CnEdicion068.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion068.MascaraEspecial = ""
Me.CnEdicion068.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion068.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion068.MaximoNumero = 999999999999999.0R
Me.CnEdicion068.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion068.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion068.MinimoNumero = -999999999999999.0R
Me.CnEdicion068.Name = "CnEdicion068"
Me.CnEdicion068.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion068.TabIndex = 9999
Me.CnEdicion068.Tabla = "calibres_salida"
'
'CnEdicion069
'
Me.CnEdicion069.AceptaEspacios = True
Me.CnEdicion069.AceptaMayusculas = True
Me.CnEdicion069.AceptaMayusculasAcentuadas = True
Me.CnEdicion069.AceptaMinusculas = True
Me.CnEdicion069.AceptaMinusculasAcentuadas = True
Me.CnEdicion069.AceptaNumeros = True
Me.CnEdicion069.AceptaSimbolos = False
Me.CnEdicion069.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion069.ConvierteAMayusculas = False
Me.CnEdicion069.ConvierteAMinusculas = False
Me.CnEdicion069.EsFechaHoraCreacion = False
Me.CnEdicion069.EsFechaHoraModificacion = False
Me.CnEdicion069.ColorFondoControl = System.Drawing.Color.Blue
Me.CnEdicion069.ColorFondo = System.Drawing.Color.SkyBlue
Me.CnEdicion069.ColorFondoRequerido = System.Drawing.Color.SkyBlue
Me.CnEdicion069.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion069.Campo = "numero_linea"
Me.CnEdicion069.CampoEnlacesLookup1 = Nothing
Me.CnEdicion069.CampoEnlacesLookup2 = Nothing
Me.CnEdicion069.CampoEnlacesLookup3 = Nothing
Me.CnEdicion069.EdicionEnGrid = True
Me.CnEdicion069.TituloParaGrid = "Línea"
Me.CnEdicion069.AnchoColumnaGrid = 40
Me.CnEdicion069.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion069.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion069.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion069.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion069.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion069.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion069.EnCreacionSoloLectura = False
Me.CnEdicion069.EnCreacionOculto = False
Me.CnEdicion069.SiempreSoloLectura = False
Me.CnEdicion069.SiempreOculto = False
Me.CnEdicion069.EnlacesLookup1 = 0
Me.CnEdicion069.EnlacesLookup2 = 0
Me.CnEdicion069.EnlacesLookup3 = 0
Me.CnEdicion069.EnModificacionSoloLectura = False
Me.CnEdicion069.EnModificacionOculto = False
Me.CnEdicion069.Fuente = Nothing
Me.CnEdicion069.HayMascaraEspecial = False
Me.CnEdicion069.HayValorDefecto = False
Me.CnEdicion069.NumeroParametroValorDefecto = 0
Me.CnEdicion069.ValorDefecto = ""
Me.CnEdicion069.HayValorFijo = False
Me.CnEdicion069.NumeroParametroValorFijo = 0
Me.CnEdicion069.ValorFijo = ""
Me.CnEdicion069.HayValorFijoCreacion = False
Me.CnEdicion069.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion069.ValorFijoCreacion = ""
Me.CnEdicion069.Location = New System.Drawing.Point(1130,54)
Me.CnEdicion069.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion069.MascaraEspecial = ""
Me.CnEdicion069.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion069.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion069.MaximoNumero = 999999999999999.0R
Me.CnEdicion069.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion069.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion069.MinimoNumero = -999999999999999.0R
Me.CnEdicion069.Name = "CnEdicion069"
Me.CnEdicion069.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion069.TabIndex = 9999
Me.CnEdicion069.Tabla = "calibres_salida"
'
'CnEdicion070
'
Me.CnEdicion070.AceptaEspacios = True
Me.CnEdicion070.AceptaMayusculas = True
Me.CnEdicion070.AceptaMayusculasAcentuadas = False
Me.CnEdicion070.AceptaMinusculas = False
Me.CnEdicion070.AceptaMinusculasAcentuadas = False
Me.CnEdicion070.AceptaNumeros = True
Me.CnEdicion070.AceptaSimbolos = True
Me.CnEdicion070.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ -_,.:;<>{}!¡?¿@#$%&/\()[]=+*"
Me.CnEdicion070.ConvierteAMayusculas = True
Me.CnEdicion070.ConvierteAMinusculas = False
Me.CnEdicion070.EsFechaHoraCreacion = False
Me.CnEdicion070.EsFechaHoraModificacion = False
Me.CnEdicion070.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion070.ColorFondo = System.Drawing.Color.White
Me.CnEdicion070.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion070.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion070.Campo = "calibre"
Me.CnEdicion070.CampoEnlacesLookup1 = "descripcion"
Me.CnEdicion070.CampoEnlacesLookup2 = Nothing
Me.CnEdicion070.CampoEnlacesLookup3 = Nothing
Me.CnEdicion070.EdicionEnGrid = True
Me.CnEdicion070.TituloParaGrid = "Calibre"
Me.CnEdicion070.AnchoColumnaGrid = 104
Me.CnEdicion070.TituloGridEnlaceLookup1 = "Descripción"
Me.CnEdicion070.AnchoColumnaGridEnlaceLookup1 = 250
Me.CnEdicion070.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion070.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion070.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion070.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion070.EnCreacionSoloLectura = False
Me.CnEdicion070.EnCreacionOculto = False
Me.CnEdicion070.SiempreSoloLectura = False
Me.CnEdicion070.SiempreOculto = False
Me.CnEdicion070.EnlacesLookup1 = 31334
Me.CnEdicion070.EnlacesLookup2 = 0
Me.CnEdicion070.EnlacesLookup3 = 0
Me.CnEdicion070.EnModificacionSoloLectura = False
Me.CnEdicion070.EnModificacionOculto = False
Me.CnEdicion070.Fuente = Nothing
Me.CnEdicion070.HayMascaraEspecial = False
Me.CnEdicion070.HayValorDefecto = False
Me.CnEdicion070.NumeroParametroValorDefecto = 0
Me.CnEdicion070.ValorDefecto = ""
Me.CnEdicion070.HayValorFijo = False
Me.CnEdicion070.NumeroParametroValorFijo = 0
Me.CnEdicion070.ValorFijo = ""
Me.CnEdicion070.HayValorFijoCreacion = False
Me.CnEdicion070.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion070.ValorFijoCreacion = ""
Me.CnEdicion070.Location = New System.Drawing.Point(5,98)
Me.CnEdicion070.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion070.MascaraEspecial = ""
Me.CnEdicion070.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion070.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion070.MaximoNumero = 999999999999999.0R
Me.CnEdicion070.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion070.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion070.MinimoNumero = -999999999999999.0R
Me.CnEdicion070.Name = "CnEdicion070"
Me.CnEdicion070.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion070.TabIndex = 9999
Me.CnEdicion070.Tabla = "calibres_salida"
'
'CnEdicion071
'
Me.CnEdicion071.AceptaEspacios = True
Me.CnEdicion071.AceptaMayusculas = True
Me.CnEdicion071.AceptaMayusculasAcentuadas = True
Me.CnEdicion071.AceptaMinusculas = True
Me.CnEdicion071.AceptaMinusculasAcentuadas = True
Me.CnEdicion071.AceptaNumeros = True
Me.CnEdicion071.AceptaSimbolos = False
Me.CnEdicion071.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion071.ConvierteAMayusculas = False
Me.CnEdicion071.ConvierteAMinusculas = False
Me.CnEdicion071.EsFechaHoraCreacion = False
Me.CnEdicion071.EsFechaHoraModificacion = False
Me.CnEdicion071.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion071.ColorFondo = System.Drawing.Color.White
Me.CnEdicion071.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion071.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion071.Campo = "bultos"
Me.CnEdicion071.CampoEnlacesLookup1 = Nothing
Me.CnEdicion071.CampoEnlacesLookup2 = Nothing
Me.CnEdicion071.CampoEnlacesLookup3 = Nothing
Me.CnEdicion071.EdicionEnGrid = True
Me.CnEdicion071.TituloParaGrid = "Número de bultos"
Me.CnEdicion071.AnchoColumnaGrid = 154
Me.CnEdicion071.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion071.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion071.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion071.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion071.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion071.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion071.EnCreacionSoloLectura = False
Me.CnEdicion071.EnCreacionOculto = False
Me.CnEdicion071.SiempreSoloLectura = False
Me.CnEdicion071.SiempreOculto = False
Me.CnEdicion071.EnlacesLookup1 = 0
Me.CnEdicion071.EnlacesLookup2 = 0
Me.CnEdicion071.EnlacesLookup3 = 0
Me.CnEdicion071.EnModificacionSoloLectura = False
Me.CnEdicion071.EnModificacionOculto = False
Me.CnEdicion071.Fuente = Nothing
Me.CnEdicion071.HayMascaraEspecial = False
Me.CnEdicion071.HayValorDefecto = False
Me.CnEdicion071.NumeroParametroValorDefecto = 0
Me.CnEdicion071.ValorDefecto = ""
Me.CnEdicion071.HayValorFijo = False
Me.CnEdicion071.NumeroParametroValorFijo = 0
Me.CnEdicion071.ValorFijo = ""
Me.CnEdicion071.HayValorFijoCreacion = False
Me.CnEdicion071.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion071.ValorFijoCreacion = ""
Me.CnEdicion071.Location = New System.Drawing.Point(40,98)
Me.CnEdicion071.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion071.MascaraEspecial = ""
Me.CnEdicion071.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion071.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion071.MaximoNumero = 999999999999999.0R
Me.CnEdicion071.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion071.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion071.MinimoNumero = -999999999999999.0R
Me.CnEdicion071.Name = "CnEdicion071"
Me.CnEdicion071.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion071.TabIndex = 9999
Me.CnEdicion071.Tabla = "calibres_salida"
'
'CnEdicion072
'
Me.CnEdicion072.AceptaEspacios = True
Me.CnEdicion072.AceptaMayusculas = True
Me.CnEdicion072.AceptaMayusculasAcentuadas = True
Me.CnEdicion072.AceptaMinusculas = True
Me.CnEdicion072.AceptaMinusculasAcentuadas = True
Me.CnEdicion072.AceptaNumeros = True
Me.CnEdicion072.AceptaSimbolos = False
Me.CnEdicion072.CaracteresAceptables = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZabcdefghijklmnñopqrstuvwxyz áéíóúÁÉÍÓÚ"
Me.CnEdicion072.ConvierteAMayusculas = False
Me.CnEdicion072.ConvierteAMinusculas = False
Me.CnEdicion072.EsFechaHoraCreacion = False
Me.CnEdicion072.EsFechaHoraModificacion = False
Me.CnEdicion072.ColorFondoControl = System.Drawing.Color.Yellow
Me.CnEdicion072.ColorFondo = System.Drawing.Color.White
Me.CnEdicion072.ColorFondoRequerido = System.Drawing.Color.LemonChiffon
Me.CnEdicion072.BackColor = System.Drawing.Color.LemonChiffon
Me.CnEdicion072.Campo = "kilos"
Me.CnEdicion072.CampoEnlacesLookup1 = Nothing
Me.CnEdicion072.CampoEnlacesLookup2 = Nothing
Me.CnEdicion072.CampoEnlacesLookup3 = Nothing
Me.CnEdicion072.EdicionEnGrid = True
Me.CnEdicion072.TituloParaGrid = "Kilos"
Me.CnEdicion072.AnchoColumnaGrid = 100
Me.CnEdicion072.TituloGridEnlaceLookup1 = Nothing
Me.CnEdicion072.AnchoColumnaGridEnlaceLookup1 = 0
Me.CnEdicion072.TituloGridEnlaceLookup2 = Nothing
Me.CnEdicion072.AnchoColumnaGridEnlaceLookup2 = 0
Me.CnEdicion072.TituloGridEnlaceLookup3 = Nothing
Me.CnEdicion072.AnchoColumnaGridEnlaceLookup3 = 0
Me.CnEdicion072.EnCreacionSoloLectura = False
Me.CnEdicion072.EnCreacionOculto = False
Me.CnEdicion072.SiempreSoloLectura = False
Me.CnEdicion072.SiempreOculto = False
Me.CnEdicion072.EnlacesLookup1 = 0
Me.CnEdicion072.EnlacesLookup2 = 0
Me.CnEdicion072.EnlacesLookup3 = 0
Me.CnEdicion072.EnModificacionSoloLectura = False
Me.CnEdicion072.EnModificacionOculto = False
Me.CnEdicion072.Fuente = Nothing
Me.CnEdicion072.HayMascaraEspecial = False
Me.CnEdicion072.HayValorDefecto = False
Me.CnEdicion072.NumeroParametroValorDefecto = 0
Me.CnEdicion072.ValorDefecto = ""
Me.CnEdicion072.HayValorFijo = False
Me.CnEdicion072.NumeroParametroValorFijo = 0
Me.CnEdicion072.ValorFijo = ""
Me.CnEdicion072.HayValorFijoCreacion = False
Me.CnEdicion072.NumeroParametroValorFijoCreacion = 0
Me.CnEdicion072.ValorFijoCreacion = ""
Me.CnEdicion072.Location = New System.Drawing.Point(75,98)
Me.CnEdicion072.Margin = New System.Windows.Forms.Padding(0)
Me.CnEdicion072.MascaraEspecial = ""
Me.CnEdicion072.MaximaFecha = New Date(2050, 12, 31, 0, 0, 0, 0)
Me.CnEdicion072.MaximaFechaHora = New Date(2050, 12, 31, 23, 59, 59, 0)
Me.CnEdicion072.MaximoNumero = 999999999999999.0R
Me.CnEdicion072.MinimaFecha = New Date(1900, 1, 1, 0, 0, 0, 0)
Me.CnEdicion072.MinimaFechaHora = New Date(1900, 1, 1, 0, 0, 1, 0)
Me.CnEdicion072.MinimoNumero = -999999999999999.0R
Me.CnEdicion072.Name = "CnEdicion072"
Me.CnEdicion072.Size = New System.Drawing.Size(30, 20)
Me.CnEdicion072.TabIndex = 9999
Me.CnEdicion072.Tabla = "calibres_salida"
Me.TabPage02.Text = "calibres_salida"
'
'TabPage03
'
Me.TabPage03.Location = New System.Drawing.Point(4, 4)
Me.TabPage03.Name = "TabPage03"
Me.TabPage03.Size = New System.Drawing.Size(1172, 765)
Me.TabPage03.TabIndex = 2
Me.TabPage03.Text = "3"
Me.TabPage03.UseVisualStyleBackColor = True
Me.Tabpage03.CausesValidation = False
'
'TabPage04
'
Me.TabPage04.Location = New System.Drawing.Point(4, 4)
Me.TabPage04.Name = "TabPage04"
Me.TabPage04.Size = New System.Drawing.Size(1172, 765)
Me.TabPage04.TabIndex = 3
Me.TabPage04.Text = "4"
Me.TabPage04.UseVisualStyleBackColor = True
Me.Tabpage04.CausesValidation = False
'
'TabPage05
'
Me.TabPage05.Location = New System.Drawing.Point(4, 4)
Me.TabPage05.Name = "TabPage05"
Me.TabPage05.Size = New System.Drawing.Size(1172, 765)
Me.TabPage05.TabIndex = 4
Me.TabPage05.Text = "5"
Me.TabPage05.UseVisualStyleBackColor = True
Me.Tabpage05.CausesValidation = False
'
'TabPage06
'
Me.TabPage06.Location = New System.Drawing.Point(4, 4)
Me.TabPage06.Name = "TabPage06"
Me.TabPage06.Size = New System.Drawing.Size(1172, 765)
Me.TabPage06.TabIndex = 5
Me.TabPage06.Text = "6"
Me.TabPage06.UseVisualStyleBackColor = True
Me.Tabpage06.CausesValidation = False
'
'TabPage07
'
Me.TabPage07.Location = New System.Drawing.Point(4, 4)
Me.TabPage07.Name = "TabPage07"
Me.TabPage07.Size = New System.Drawing.Size(1172, 765)
Me.TabPage07.TabIndex = 6
Me.TabPage07.Text = "7"
Me.TabPage07.UseVisualStyleBackColor = True
Me.Tabpage07.CausesValidation = False
'
'TabPage08
'
Me.TabPage08.Location = New System.Drawing.Point(4, 4)
Me.TabPage08.Name = "TabPage08"
Me.TabPage08.Size = New System.Drawing.Size(1172, 765)
Me.TabPage08.TabIndex = 7
Me.TabPage08.Text = "8"
Me.TabPage08.UseVisualStyleBackColor = True
Me.Tabpage08.CausesValidation = False
'
'TabPage09
'
Me.TabPage09.Location = New System.Drawing.Point(4, 4)
Me.TabPage09.Name = "TabPage09"
Me.TabPage09.Size = New System.Drawing.Size(1172, 765)
Me.TabPage09.TabIndex = 8
Me.TabPage09.Text = "9"
Me.TabPage09.UseVisualStyleBackColor = True
Me.Tabpage09.CausesValidation = False
'
'PanelInferior
'
Me.PanelInferior.BackColor = System.Drawing.SystemColors.Control
Me.PanelInferior.Dock = System.Windows.Forms.DockStyle.Bottom
Me.PanelInferior.Location = New System.Drawing.Point(0, 933)
Me.PanelInferior.Name = "PanelInferior"
Me.PanelInferior.Size = New System.Drawing.Size(1184, 28)
Me.PanelInferior.TabIndex = 9999
Me.PanelInferior.CausesValidation = False
'
'frmsalidas
'
Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
Me.CausesValidation = False
Me.ClientSize = New System.Drawing.Size(1184, 961)
Me.Controls.Add(Me.PanelSuperior)
Me.Controls.Add(Me.PanelCentral)
Me.Controls.Add(Me.PanelInferior)
Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.Name = "frmsalidas"
Me.Text = "frmsalidas"
Me.PanelSuperior.ResumeLayout(False)
Me.PanelSuperior.PerformLayout()
Me.PanelCentral.ResumeLayout(False)
Me.TabCabecera.ResumeLayout(False)
Me.TabGeneral.ResumeLayout(False)
Me.TP01.ResumeLayout(False)
Me.TP01.PerformLayout()
Me.TabPage02.ResumeLayout(False)
Me.TabPage02.PerformLayout()
Me.TabPage01.ResumeLayout(False)
Me.TabPage01.PerformLayout()
Me.TP00.ResumeLayout(False)
Me.TP00.PerformLayout()
Me.TabPage00.ResumeLayout(False)
Me.TabPage00.PerformLayout()
Me.ResumeLayout(False)
End Sub

Friend WithEvents PanelSuperior As Panel
Friend WithEvents CmdSalir As Button
Friend WithEvents PanelCentral As Panel
Friend WithEvents PanelInferior As Panel
Friend WithEvents TabCabecera As TabControl
Friend WithEvents TP00 As TabPage
Friend WithEvents TP01 As TabPage
Friend WithEvents TP02 As TabPage
Friend WithEvents TP03 As TabPage
Friend WithEvents TP04 As TabPage
Friend WithEvents TP05 As TabPage
Friend WithEvents TP06 As TabPage
Friend WithEvents TP07 As TabPage
Friend WithEvents TP08 As TabPage
Friend WithEvents TP09 As TabPage
Friend WithEvents TabGeneral As TabControl
Friend WithEvents TabPage00 As TabPage
Friend WithEvents TabPage01 As TabPage
Friend WithEvents TabPage02 As TabPage
Friend WithEvents TabPage03 As TabPage
Friend WithEvents TabPage04 As TabPage
Friend WithEvents TabPage05 As TabPage
Friend WithEvents TabPage06 As TabPage
Friend WithEvents TabPage07 As TabPage
Friend WithEvents TabPage08 As TabPage
Friend WithEvents TabPage09 As TabPage
Friend WithEvents CnTabla01 As CnTabla.CnTabla
Friend WithEvents CnTabla02 As CnTabla.CnTabla
Friend WithEvents CnTabla03 As CnTabla.CnTabla
Friend WithEvents GridTabla02 As DataGridView
Friend WithEvents GridTabla03 As DataGridView
Friend WithEvents Lbl001 As Label
Friend WithEvents TxtDatos001 As TextBox
Friend WithEvents CnEdicion001 As CnEdicion.CnEdicion
Friend WithEvents Lbl002 As Label
Friend WithEvents TxtDatos002 As TextBox
Friend WithEvents CnEdicion002 As CnEdicion.CnEdicion
Friend WithEvents Lbl003 As Label
Friend WithEvents TxtDatos003 As TextBox
Friend WithEvents CnEdicion003 As CnEdicion.CnEdicion
Friend WithEvents Lbl004 As Label
Friend WithEvents TxtDatos004 As TextBox
Friend WithEvents CnEdicion004 As CnEdicion.CnEdicion
Friend WithEvents Lbl005 As Label
Friend WithEvents TxtDatos005 As TextBox
Friend WithEvents CnEdicion005 As CnEdicion.CnEdicion
Friend WithEvents Lbl006 As Label
Friend WithEvents TxtDatos006 As TextBox
Friend WithEvents CnEdicion006 As CnEdicion.CnEdicion
Friend WithEvents Lbl007 As Label
Friend WithEvents TxtDatos007 As TextBox
Friend WithEvents CnEdicion007 As CnEdicion.CnEdicion
Friend WithEvents Lbl008 As Label
Friend WithEvents TxtDatos008 As TextBox
Friend WithEvents CnEdicion008 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid008 As Button
Friend WithEvents TxtLookup0081 As TextBox
Friend WithEvents Lbl009 As Label
Friend WithEvents TxtDatos009 As TextBox
Friend WithEvents CnEdicion009 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid009 As Button
Friend WithEvents TxtLookup0091 As TextBox
Friend WithEvents Lbl010 As Label
Friend WithEvents TxtDatos010 As TextBox
Friend WithEvents CnEdicion010 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid010 As Button
Friend WithEvents TxtLookup0101 As TextBox
Friend WithEvents Lbl011 As Label
Friend WithEvents TxtDatos011 As TextBox
Friend WithEvents CnEdicion011 As CnEdicion.CnEdicion
Friend WithEvents CmdCombo011 As Button
Friend WithEvents Lbl012 As Label
Friend WithEvents TxtDatos012 As TextBox
Friend WithEvents CnEdicion012 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid012 As Button
Friend WithEvents TxtLookup0121 As TextBox
Friend WithEvents Lbl013 As Label
Friend WithEvents TxtDatos013 As TextBox
Friend WithEvents CnEdicion013 As CnEdicion.CnEdicion
Friend WithEvents Lbl014 As Label
Friend WithEvents TxtDatos014 As TextBox
Friend WithEvents CnEdicion014 As CnEdicion.CnEdicion
Friend WithEvents Lbl015 As Label
Friend WithEvents TxtDatos015 As TextBox
Friend WithEvents CnEdicion015 As CnEdicion.CnEdicion
Friend WithEvents Lbl016 As Label
Friend WithEvents TxtDatos016 As TextBox
Friend WithEvents CnEdicion016 As CnEdicion.CnEdicion
Friend WithEvents Lbl017 As Label
Friend WithEvents TxtDatos017 As TextBox
Friend WithEvents CnEdicion017 As CnEdicion.CnEdicion
Friend WithEvents Lbl018 As Label
Friend WithEvents TxtDatos018 As TextBox
Friend WithEvents CnEdicion018 As CnEdicion.CnEdicion
Friend WithEvents Lbl019 As Label
Friend WithEvents TxtDatos019 As TextBox
Friend WithEvents CnEdicion019 As CnEdicion.CnEdicion
Friend WithEvents Lbl020 As Label
Friend WithEvents TxtDatos020 As TextBox
Friend WithEvents CnEdicion020 As CnEdicion.CnEdicion
Friend WithEvents Lbl021 As Label
Friend WithEvents TxtDatos021 As TextBox
Friend WithEvents CnEdicion021 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid021 As Button
Friend WithEvents TxtLookup0211 As TextBox
Friend WithEvents Lbl022 As Label
Friend WithEvents TxtDatos022 As TextBox
Friend WithEvents CnEdicion022 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid022 As Button
Friend WithEvents TxtLookup0221 As TextBox
Friend WithEvents Lbl023 As Label
Friend WithEvents TxtDatos023 As TextBox
Friend WithEvents CnEdicion023 As CnEdicion.CnEdicion
Friend WithEvents Lbl024 As Label
Friend WithEvents TxtDatos024 As TextBox
Friend WithEvents CnEdicion024 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid024 As Button
Friend WithEvents TxtLookup0241 As TextBox
Friend WithEvents TxtLookup0242 As TextBox
Friend WithEvents Lbl025 As Label
Friend WithEvents TxtDatos025 As TextBox
Friend WithEvents CnEdicion025 As CnEdicion.CnEdicion
Friend WithEvents Lbl026 As Label
Friend WithEvents TxtDatos026 As TextBox
Friend WithEvents CnEdicion026 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid026 As Button
Friend WithEvents TxtLookup0261 As TextBox
Friend WithEvents Lbl027 As Label
Friend WithEvents TxtDatos027 As TextBox
Friend WithEvents CnEdicion027 As CnEdicion.CnEdicion
Friend WithEvents Lbl028 As Label
Friend WithEvents TxtDatos028 As TextBox
Friend WithEvents CnEdicion028 As CnEdicion.CnEdicion
Friend WithEvents Lbl029 As Label
Friend WithEvents TxtDatos029 As TextBox
Friend WithEvents CnEdicion029 As CnEdicion.CnEdicion
Friend WithEvents Lbl030 As Label
Friend WithEvents TxtDatos030 As TextBox
Friend WithEvents CnEdicion030 As CnEdicion.CnEdicion
Friend WithEvents Lbl031 As Label
Friend WithEvents TxtDatos031 As TextBox
Friend WithEvents CnEdicion031 As CnEdicion.CnEdicion
Friend WithEvents Lbl032 As Label
Friend WithEvents TxtDatos032 As TextBox
Friend WithEvents CnEdicion032 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid032 As Button
Friend WithEvents TxtLookup0321 As TextBox
Friend WithEvents Lbl033 As Label
Friend WithEvents TxtDatos033 As TextBox
Friend WithEvents CnEdicion033 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid033 As Button
Friend WithEvents TxtLookup0331 As TextBox
Friend WithEvents Lbl034 As Label
Friend WithEvents TxtDatos034 As TextBox
Friend WithEvents CnEdicion034 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid034 As Button
Friend WithEvents TxtLookup0341 As TextBox
Friend WithEvents Lbl035 As Label
Friend WithEvents TxtDatos035 As TextBox
Friend WithEvents CnEdicion035 As CnEdicion.CnEdicion
Friend WithEvents CmdCombo035 As Button
Friend WithEvents CmdGrid035 As Button
Friend WithEvents TxtLookup0351 As TextBox
Friend WithEvents Lbl036 As Label
Friend WithEvents TxtDatos036 As TextBox
Friend WithEvents CnEdicion036 As CnEdicion.CnEdicion
Friend WithEvents Lbl037 As Label
Friend WithEvents TxtDatos037 As TextBox
Friend WithEvents CnEdicion037 As CnEdicion.CnEdicion
Friend WithEvents CmdFecha037 As Button
Friend WithEvents Lbl038 As Label
Friend WithEvents TxtDatos038 As TextBox
Friend WithEvents CnEdicion038 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid038 As Button
Friend WithEvents TxtLookup0381 As TextBox
Friend WithEvents Lbl039 As Label
Friend WithEvents TxtDatos039 As TextBox
Friend WithEvents CnEdicion039 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid039 As Button
Friend WithEvents TxtLookup0391 As TextBox
Friend WithEvents Lbl040 As Label
Friend WithEvents TxtDatos040 As TextBox
Friend WithEvents CnEdicion040 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid040 As Button
Friend WithEvents TxtLookup0401 As TextBox
Friend WithEvents Lbl041 As Label
Friend WithEvents TxtDatos041 As TextBox
Friend WithEvents CnEdicion041 As CnEdicion.CnEdicion
Friend WithEvents Lbl042 As Label
Friend WithEvents TxtDatos042 As TextBox
Friend WithEvents CnEdicion042 As CnEdicion.CnEdicion
Friend WithEvents Lbl043 As Label
Friend WithEvents TxtDatos043 As TextBox
Friend WithEvents CnEdicion043 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion044 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion045 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion046 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion047 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion048 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion049 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion050 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion051 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion052 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion053 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion054 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion055 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion056 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion057 As CnEdicion.CnEdicion
Friend WithEvents Lbl058 As Label
Friend WithEvents TxtDatos058 As TextBox
Friend WithEvents CnEdicion058 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid058 As Button
Friend WithEvents TxtLookup0581 As TextBox
Friend WithEvents Lbl059 As Label
Friend WithEvents TxtDatos059 As TextBox
Friend WithEvents CnEdicion059 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid059 As Button
Friend WithEvents TxtLookup0591 As TextBox
Friend WithEvents Lbl060 As Label
Friend WithEvents TxtDatos060 As TextBox
Friend WithEvents CnEdicion060 As CnEdicion.CnEdicion
Friend WithEvents CmdGrid060 As Button
Friend WithEvents TxtLookup0601 As TextBox
Friend WithEvents Lbl061 As Label
Friend WithEvents TxtDatos061 As TextBox
Friend WithEvents CnEdicion061 As CnEdicion.CnEdicion
Friend WithEvents CmdCombo061 As Button
Friend WithEvents Lbl062 As Label
Friend WithEvents TxtDatos062 As TextBox
Friend WithEvents CnEdicion062 As CnEdicion.CnEdicion
Friend WithEvents Lbl063 As Label
Friend WithEvents TxtDatos063 As TextBox
Friend WithEvents CnEdicion063 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion064 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion065 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion066 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion067 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion068 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion069 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion070 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion071 As CnEdicion.CnEdicion
Friend WithEvents CnEdicion072 As CnEdicion.CnEdicion
Friend WithEvents LblDuplicado0441 As Label
Friend WithEvents TxtDuplicado0441 As TextBox
 Friend WithEvents Timer1 As Timer
End Class
