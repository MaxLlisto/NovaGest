Imports System.ComponentModel

Public Class frmbienes
    Inherits LibreriaModeloMantenimiento.ModeloMantenimiento

End Class
